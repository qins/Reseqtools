#ifndef Fq2Fa_H_
#define Fq2Fa_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include <algorithm>
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/DataClass.h"

using namespace std;

int  print_Fq2Fa()
{
	cout <<""
		"\n"
		"\tUsage: Fq2Fa -InFq <in.fq> -OutPut <out.fa>\n"
		"\n"
		"\t\t-InFq      <str>   Input Fastq File\n"
		"\t\t-OutPut    <str>   Output Fasta file\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int usageFq2Fa(int argc, char **argv , In3str1v * para )
{
	if (argc <=2 ) {print_Fq2Fa();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFq" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_Fq2Fa();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para->InStr1).empty()  ||  (para->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para->InStr2)=add_Asuffix(para->InStr2) ;
	return 1 ;
}

int Form_Fq2Fa_main(int argc, char *argv[])
{
	In3str1v * para = new In3str1v;
	if( usageFq2Fa(argc, argv, para )==0)
	{
		delete  para ;
		return 0;
	}

	ogzstream OUT((para->InStr2).c_str()) ;
	if (!OUT.good())
	{
		cerr<<"Can't open OutFile "<<(para->InStr2)<<endl;
		return 0;
	}
	igzstream INFQ ((para->InStr1).c_str(),ifstream::in);
	if(!INFQ.good())
	{
		cerr << "open InputFQ  error: "<<(para->InStr1)<<endl;
		return 0;
	}

	while(!INFQ.eof())
	{
		string  ID,seq ;
		getline(INFQ,ID);
		if (ID.length()<=0)  { continue  ; }
		ID=ID.substr(1);
		getline(INFQ,seq);
		OUT<<">"<<ID<<"\n"<<seq<<endl;
		getline(INFQ,ID);
		getline(INFQ,seq);
	}
	OUT.close();
	INFQ.close();
	delete para ;
	return 0;
}
#endif /// Fq2Fa_H_ 
///////// swimming in the sky and flying in the sea ////////////


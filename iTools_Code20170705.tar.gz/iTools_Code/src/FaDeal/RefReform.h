#ifndef RefReform_H_
#define RefReform_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

//KSEQ_AINIT(gzFile, gzread)

using namespace std;

int  print_AusageFA06()
{
	cout <<""
		"\n"
		"\tUsage: reform -InPut <in.fa> \n"
		"\n"
		"\t\t-InPut       <str>   Input fa for upper/lower case\n"
		"\n"
		"\t\t-OutPut      <str>   OutPut file [STDOUT]\n"
		"\t\t-NOcomment           remove the comment of each seq\n"
		"\t\t-Case        <str>   upper/lower the seq base (upper/lower)\n"
		"\t\t-Reverse             reverse the sequence\n"
		"\t\t-Complement          complement the sequence\n"
		"\t\t-oneline             one lines one seq to stored\n"
		"\t\t-cutline    <int>    How X bp to cut end one line seq\n"
		"\n"
		"\t\t-help                show this help\n"
		"\n";
	return 1;
}


int parse_AcmdFA06(int argc, char **argv , In3str1v  * paraFA06 , int & cutline )
{
	if (argc <=2 ) {print_AusageFA06();return 0;}

	for(int i = 1; i < argc ;  i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA06->InStr1=argv[i];
		}
		else if (flag  == "cutline")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			cutline=atoi(argv[i]);
		}
		else if (flag  == "Case" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA06->InStr3=argv[i];
			if ( ( (paraFA06->InStr3) != "upper"  )   &&   ( (paraFA06->InStr3) != "lower"  ) )
			{
				cerr<<"-Case shoule be  [upper]  or  [lower]" <<endl;
				return 0;
			}
			//			paraFA06->TF=false;
		}
		else if (flag  ==  "NOcomment")
		{
			
			paraFA06->InInt=(paraFA06->InInt) | 0x4;
		}
		else if (flag  ==  "Reverse")
		{
			paraFA06->InInt=(paraFA06->InInt) | 0x1;
		}
		else if (flag  ==  "Complement")
		{
			paraFA06->InInt=(paraFA06->InInt) | 0x2;
		}
		else if (flag  ==  "oneline" )
		{
			paraFA06->InInt=(paraFA06->InInt) | 0x8;
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA06->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_AusageFA06();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	if  ((paraFA06->InStr1).empty())
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	if (!(paraFA06->InStr2).empty() )
	{
		(paraFA06->InStr2)=add_Asuffix(paraFA06->InStr2) ;
	}
	return 1 ;
}

int FA_Reform_main(int argc, char *argv[])
	//int main(int argc, char *argv[])
{
	In3str1v  * paraFA06 = new In3str1v ;
	int cutline=-1 ;
	if( parse_AcmdFA06(argc, argv, paraFA06 , cutline)==0)
	{
		delete  paraFA06 ;
		return 0 ;
	}

	map <char ,char >  Complement;
	Complement['A']='T'; Complement['C']='G';  Complement['T']='A'; Complement['G']='C'; Complement['N']='N';
	Complement['a']='t'; Complement['c']='g';  Complement['t']='a'; Complement['g']='c'; Complement['n']='n';
	Complement['M']='K'; Complement['R']='Y';  Complement['W']='W'; Complement['S']='S'; Complement['Y']='R';
	Complement['K']='M';
	Complement['m']='k'; Complement['r']='y';  Complement['w']='w'; Complement['s']='s'; Complement['y']='r';
	Complement['k']='m';

	
	
	int linecut=cutline;
	if (cutline<0)
	{
		linecut	= FaCutLine ((paraFA06->InStr1));
	}

	gzFile fp;
	kseq_t *seq;
	int l;
	fp = gzopen((paraFA06->InStr1).c_str(), "r");
	seq = kseq_init(fp);
	ogzstream  OUT ;
	if (!(paraFA06->InStr2).empty())
	{
		OUT.open((paraFA06->InStr2).c_str());
	}

	while ((l = kseq_read(seq)) >= 0)
	{
		string Ref=(seq->seq.s) ;
		string chr=(seq->name.s);
		string ID=chr ;
		if (seq->comment.l)
		{
			string comment=(seq->comment.s);
			ID+="\t"+comment;
		}

		if  ((paraFA06->InInt) & 0x4)
		{
			ID=chr ;
		}

		if ((paraFA06->InStr3)== "upper"  ||  (paraFA06->InStr3)== "Upper" )
		{
			transform(Ref.begin(),Ref.end(),Ref.begin(),::toupper) ;
		}
		else if ((paraFA06->InStr3)== "lower"  ||  (paraFA06->InStr3)== "Lower" )
		{
			transform(Ref.begin(),Ref.end(),Ref.begin(), ::tolower) ;
		}

		if ( (paraFA06->InInt) & 0x1 )
		{
			reverse(Ref.begin(), Ref.end());
		}

		int Refleng=Ref.length();

		if  ( (paraFA06->InInt) & 0x2 )
		{
			for (int i=0 ; i<Refleng ; i++)
			{
				if (Complement.find(Ref[i])!=Complement.end())
				{
					Ref[i]=Complement[Ref[i]];
				}
			}
		}

		if  ((paraFA06->InInt) & 0x8)
		{
			if ((paraFA06->InStr2).empty())
			{
				cout<<">"<<ID<<endl;
				cout<<Ref<<endl;
			}
			else
			{
				OUT<<">"<<ID<<endl;
				OUT<<Ref<<endl;
			}
		}
		else
		{
			int Endline=int(Refleng/linecut);
			if ((paraFA06->InStr2).empty())
			{
				cout<<">"<<ID<<endl;

				for (int i=0 ; i< Endline ; i++)
				{
					cout<<Ref.substr(i*linecut,linecut)<<endl;
				}
				long  AA=Endline*linecut ;

				if (Refleng > AA)
				{
					cout<<Ref.substr(AA)<<endl;
				}
			}
			else
			{
				Display( Ref , ID ,  OUT , linecut  ) ;
			}
		}
	}

	if (!(paraFA06->InStr2).empty())
	{
		OUT.close();
	}

	kseq_destroy(seq);
	gzclose(fp);
	delete paraFA06 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
#endif // RefReform_H_

//include file : findSV.h
#ifndef _FINDSV_H_
#define _FINDSV_H_

#include "include.h"
#include "common.h"
#include "main.h"

///////////////////////////////// struct ///////////////////////////////////
/* pair end struct */
struct _pair_end
{
	_pair_end(){nclst = -1; nsd = 0; nInsert = 0;}
	
	_pair_end(const _pair_end& pe)
	{
		ch		= pe.ch;
		nStart	= pe.nStart;
		nEnd	= pe.nEnd;
		nclst	= pe.nclst;
		nsd		= pe.nsd;
		nInsert = pe.nInsert;
		peid    = pe.peid;
	}
	char    ch;// type FF:0, FR:1, RF:2, RR:3    Indicate paired ends' strand.
	string  peid;
	int     nStart;// Start position
	int     nEnd;//End position
	int     nclst;//cluster paired ends belong to.
	int		nInsert;
	__int16	nsd;
	
	int     size(){return nEnd - nStart + 1;}
	int     mid(){return int((nEnd + nStart)*0.5);}
};

typedef vector<_pair_end>       VPAIREND;
typedef VPAIREND::iterator      VPAIRENDIT;
typedef map<int, VPAIREND>		MVPAIREND;

/*map of cluster*/
typedef map<int, VPAIREND>	MCLUSTER;
typedef MCLUSTER::value_type	MCLUSTER_VT;
typedef MCLUSTER::iterator	MCLUSTERIT;
static  MCLUSTER			g_mclst;

////////////////declare functions//////////////////////////////////////////
/*Multithread functions*/
void* __findsv_process(void*);
/*Multithread functions*/
/*Traditional functions*/

class CFindSVEx;
class CFindSV
{
public:// Function
	CFindSV()
	{
		m_mcc['0'] = "FF";
		m_mcc['1'] = "FR";
		m_mcc['2'] = "RF";
		m_mcc['3'] = "RR";
		m_mcc['4'] = "FR";
		m_mcc['5'] = "FR";
	}
	~CFindSV(){}
	void	Closeofstream(ofstream* ofiles);
	void	cluster(MCLUSTER& mclst, ofstream& ofile);
	int		CombSimCluster(MCLUSTER &mclst);// 
	
	void	Formatofstream(ofstream* ofiles, const char* pfn, VString& vstr);
	bool	Rearrange(_table_t& table, MVPAIREND& MVPE, VPAIREND& vpenorm, const char *pfn);
	void	_sort(VPAIREND& VPE);
protected:// Function
//	virtual void		findcluster2(VPAIREND& VPE, MCLUSTER& mclst) = 0;
private:// Function
/*********************************************************************/
	/////////////////// Draw some clusters //////////////////////////
	void drawcluster(MCLUSTER& mclst, vector<int>& vnclst, const char* pfn);
public:// Attribute
	map<char, const char*>		m_mcc;
	map<char, char>				m_mc;
	string						m_strchr;
	
protected:// Attribute
private:// Attribute
};
/////////////////////////////////////////////////////////////////
/*Multithread parameter struct*/
struct findsv_thread_param
{
	int 		threadcount;
	string		sname;
	VString*	pVstr;
};

/* #define */
const char  FF	= '0';
const char  FR	= '1';
const char  RF	= '2';
const char  RR	= '3';
const char	NOM = '5';

#define X(a, b)  (((a-'0')<<4)|(b-'0'))
#define XX(a,b,c,d) (a<b && b<c && c<d)
//FR is the normal direction
///////////////////////////////////////////////////////////////////////////
#endif //_FINDSV_H_
// header file : findSV2.h
#ifndef _FINDSV2_H_
#define _FINDSV2_H_

/************************************************************************/
/* struct                                                               */
struct	PE_SCORE
{
	PE_SCORE(){buse = false;sc = 255;}
	int			nid;
	__uint8		sc;
	bool		buse;
};

typedef vector<PE_SCORE>			VPE_SCORE;
typedef map<int, VPE_SCORE>			MPE_SCORE;// id, vector<id, score>
//////////////////////////////////////////////////////////////////////////
typedef map<int, int>				MPETIMES;
//////////////////////////////////////////////////////////////////////////
struct  PE_POSINFO 
{// record pe which has the most relationships and its location in a vector
	int			npos;
	int			nmax;
};
//////////////////////////////////////////////////////////////////////////
struct CLUSTER_INFO 
{
	int		nminEnd;
	int		nmaxEnd;
};
typedef map<int, CLUSTER_INFO>		MCLUSTERINFO;	
//////////////////////////////////////////////////////////////////////////
typedef MPETIMES					MPECLUSTER;// avg pe start, cluster id
typedef MPECLUSTER::iterator		MPECLUSTERIT;
/************************************************************************/
/************************************************************************/
/* common functions                                                     */
class CFindSVEx : public CFindSV
{
public:
	CFindSVEx():CFindSV()
	{
		m_nclst = 0;
		m_nclstCount = 0;
		m_nsvCount = 0;
	}
	~CFindSVEx(){}
	void			DetectSV(MCLUSTER& mclst, ofstream& ofile);
	void			findcluster2(VPAIREND& VPE, MCLUSTER& mclst);

	/***********************************************************/
	// This function is used for future replacement of findcluster2().
	void			findcluster3(VPAIREND& VPE, MCLUSTER& mclst);
	/***********************************************************/

	void			sortcluster(MCLUSTER& mclst);
private:
	void			FindBy4(MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile);
	void			FindByFF(MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile);
	void			FindByFR(MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile);
	void			FindByRF(MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile);
	void			FindByRR(MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile);
	void			_findcluster2(VPAIREND& VPE, MCLUSTER& mclst);
	void			Readjust(MPE_SCORE& mpesc, vector<int>& vi);
	void			seeksimilar(VPAIREND& vpe, MPE_SCORE& mpesc, MCLUSTER& mclst, MPETIMES& mpeti);
	void			scorepe2pe(VPAIREND& vpe, MPE_SCORE& mpesc, MPETIMES& mpeti);
	bool			recursion(MPE_SCORE& mpesc, vector<int>& vi, int &ni, MPETIMES& mpeti, PE_POSINFO& ppi);
	__uint8	score(_pair_end& pe1, _pair_end& pe2, int lim)
	{
		int			dist = int(sqrt((__P2((__int64)abs(pe1.nStart - pe2.nStart)) + __P2((__int64)abs(pe1.nEnd - pe2.nEnd)))/2));
		__uint8		sc = (dist<lim) ? __uint8(dist*10/lim+0.5) : 10;
		
		return sc;
	}


public:
	int				m_nclst;
	int				m_nclstCount;
	
	int				m_nsvCount;


	MCLUSTERINFO	m_mci;
	MPECLUSTER		m_mpc;
};
//////////////////////////////////////////////////////////////////////////
//inline functions
struct FBID
{
	FBID(int npe):m_npe(npe){}
	
	bool operator()(PE_SCORE ps)
	{
		return (ps.nid == m_npe);
	}
	
	int	m_npe;
};

inline bool CFindSVEx::recursion(MPE_SCORE& mpesc, vector<int>& vi, int &ni, MPETIMES& mpeti, PE_POSINFO& ppi)
{// recursively find for pe.
	for (int i=ppi.npos; i<(int)vi.size(); i++)
	{
		if (find_if(mpesc[vi[i]].begin(), mpesc[vi[i]].end(), FBID(ni)) == mpesc[vi[i]].end())
		{
			return false;
		}
	}
	vi.push_back(ni);

//cout << ni << "-";

	if (mpesc.find(ni) != mpesc.end())
	{
		ni = mpesc[ni][0].nid;
		if(mpeti[ni]>ppi.nmax)
		{
			ppi.nmax = mpeti[ni];
			ppi.npos = (int)vi.size()-1;
		}
		if (mpesc[ni][0].buse)
			return false;
	}


	else
	{
		return false;
	}


//cout << ni <<"-" <<  ppi.nmax <<":" << ppi.npos <<" ";
	
	return true;
}
/************************************************************************/
////////////////  global variable /////////////////
enum	{CLUSTER=0, SV, SORT, COUNT};
pthread_mutex_t				mutex_c = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t				mutex_p = PTHREAD_MUTEX_INITIALIZER;
//////////////////////////////////////////////////
////////////// implement functions ///////////////

void getfromlist(VString &vstr)
{
	if (vstr.size() != 0)
		return;

	Getnamefromlist(AfxGetValue("-i"), vstr);
}

int main_findsv(int argc, char* argv[], void* pVoid )
{
#ifdef MODULE
	AfxGetOptions(argc, argv);
#endif
	if (AfxGetValue("-4")!=NULL)
		return 1;
	cout<< endl << "findsv......"<<endl;
	
	//////////////////////////////////////////////////////////////////////////
	VString*	pVstr = &(((global_param*)pVoid)->vstr);
	VString		vstrin;
	VString		vstrout;
	char *		pName = NULL;

	getfromlist(*pVstr);
	vstrin.insert(vstrin.begin(), pVstr->begin(), pVstr->end());

	char*   pcpu = AfxGetValue("-cpu");
	int		cpu = (pcpu==NULL) ? 4 : atoi(pcpu);

	CThreadManager		threadMgr(cpu);
	vector<findsv_thread_param>		vtp(pVstr->size());
	for (int i=0; i<(int)pVstr->size(); i++)
	{
		vtp[i].sname		= vstrin[i];
		vtp[i].pVstr		= &vstrout;
		threadMgr.AddThread( __findsv_process, (void*)&vtp[i]);
	}
	threadMgr.Run();

	pVstr->clear();
	pVstr->insert(pVstr->begin(), vstrout.begin(), vstrout.end());

	return 1;
}

/*********** Multithread functions**********/
void* __findsv_process(void* param)
{// Main process function.
	/*Read file and format table*/
	findsv_thread_param *pParam = (findsv_thread_param*)param;
	CFindSVEx		findsv;
	MVPAIREND		MVPE;
	VPAIREND		vpenorm;
	//---------------------------------------//
	_table_t        table;
	ofstream	ofiles[COUNT];
	findsv.Formatofstream(ofiles, pParam->sname.c_str(), *(pParam->pVstr));
	if(!findsv.Rearrange(table, MVPE, vpenorm, pParam->sname.c_str()))
	{
		findsv.Closeofstream(ofiles);
		return NULL;
	}
	//---------------------------------------//
	
	MCLUSTER        mclst;
	for (MVPAIREND::iterator it=MVPE.begin(); it!=MVPE.end(); ++it)
	{
cout <<endl << endl <<  "---- findsv_process "<< "MVPAIREND key: " << it->first << endl;

		VPAIREND&		VPE = it->second;
		findsv._sort(VPE);
		findsv.findcluster2(VPE, mclst);// Find and classify clusters
	}
	findsv.CombSimCluster(mclst);
	//////////////////////////////////////////////////////////////////////////
	//----------report cluster relation----//
	findsv.cluster(mclst, ofiles[CLUSTER]);//output clusters
	findsv.DetectSV(mclst, ofiles[SV]);

	findsv.Closeofstream(ofiles);
}
/********************End of thread functions*****************/
/************************************************************/
bool CFindSV::Rearrange(_table_t& table, MVPAIREND& MVPE, VPAIREND& vpenorm, const char* pfn)
{//make paired ends. Parse table into wanted format data.

	igzstream	ifile(pfn);
	if (!ifile.good())
	{
		cout<<"Not open:"<<pfn<<endl;
		return false;
	}
	
	string		str;
	int			npe = 0;

	while(getline(ifile, str))
	{
		_pair_end	pe;
		npe++;
		VString		vstr;
		split(str, vstr, "\t ");
		pe.ch = vstr[0][0];
		if (pe.ch == NOM)
		{
			continue;
		}
		if(vstr.size()>=10)
		{
			pe.peid = vstr[8];
		}
		pe.nStart	= atoi(vstr[2].c_str());
		pe.nEnd		= atoi(vstr[3].c_str());
		if(pe.nEnd - pe.nStart > 100000)continue;
		int     n = vstr[6].find('-');
		string  s1 = vstr[6].substr(0, n);
		string  s2 = vstr[6].substr(n+1, vstr[6].length()-n-1);
		pe.nInsert	= atoi(s1.c_str());
		pe.nsd	= atoi(s2.c_str());
		//pe.nsd		= s2;	
		m_strchr = vstr[vstr.size()-1];

		MVPE[pe.nInsert].push_back(pe);
	}
	
	ifile.close();

	return (npe>2) ? true : false;
}

bool Ascend(_pair_end a, _pair_end b)
{//Ascending
	return a.nStart < b.nStart || ((a.nStart == b.nStart) && (a.nEnd-a.nStart < b.nEnd-b.nStart));
}

bool Descend(_pair_end a, _pair_end b)
{//Descending
	return a.nStart > b.nStart;
}

void CFindSV::_sort(VPAIREND& VPE)
{
	sort(VPE.begin(), VPE.end(), Ascend);
}

void CFindSV::cluster(MCLUSTER& mclst, ofstream& ofile)
{//output cluster
	int 	npos = 0;
	if(!ofile.good())return;

	char*	peclst = AfxGetValue("--cl");
	int 	npeinclst = (peclst == "" || peclst == NULL)? 10 : atoi(peclst);
	
	for(MCLUSTERIT it = mclst.begin(); it != mclst.end(); ++it)
	{
		ofile <<it->second.size()-1;
		for(size_t i = 0; i < it->second.size() - 1; i++)
		{
			ofile<<'\t'<<it->second[i].ch<<'\t'<<it->second[i].nclst<<'\t'<<it->second[i].nStart<<'\t'<<it->second[i].nEnd;
			ofile<<'\t'<<it->second[i].nEnd-it->second[i].nStart<<'\t'<<it->second[i].nStart-(it->second.end()-1)->nStart<<'\t'<<it->second[i].nEnd-(it->second.end()-1)->nEnd<<'\t';
			ofile<<it->second[i].nInsert<<'\t'<<it->second[i].peid<<endl;
		}
		ofile<<"avg:";
		ofile<<'\t'<<(it->second.end()-1)->ch<<'\t'<<(it->second.end()-1)->nclst<<'\t'<<(it->second.end()-1)->nStart<<'\t'<<(it->second.end()-1)->nEnd;
		ofile<<'\t'<<(it->second.end()-1)->nEnd-(it->second.end()-1)->nStart<<'\t'<<"0"<<'\t'<<"0"<<'\n';
	}	

}

int CFindSV::CombSimCluster(MCLUSTER &mclst)
{//This step will add an average pair end into vector of the map's each vector at the end. 
	for(MCLUSTERIT it = mclst.begin(); it != mclst.end(); ++it)
	{
		for(MCLUSTERIT it1 = it; it1 != mclst.end(); ++it1)
		{
			if(it->first == it1->first)
				continue;
			if(abs((it1->second.end()-1)->nStart-(it->second.end()-1)->nStart ) > 10)// in last there are avg nstart and avg nend
				continue;
			else
			{
				if(abs((it1->second.end()-1)->nEnd-(it->second.end()-1)->nEnd ) <= 10 && (it1->second.end()-1)->ch == (it->second.end()-1)->ch)
				{
					float   f = (it->second.size()-1)/(it->second.size()-1 + it1->second.size() -1);
					it->second.insert(it->second.end()-1, it1->second.begin(), it1->second.end()-1);
					(it->second.end()-1)->nStart=int((it->second.end()-1)->nStart*f+(it1->second.end()-1)->nStart*(1-f));
					(it->second.end()-1)->nEnd=int((it->second.end()-1)->nEnd*f+(it1->second.end()-1)->nEnd*(1-f));
					mclst.erase(it1++);
				}
			}
		}
	}
}
//////////////////////////Find SVs/////////////////////////////
/************************************* Find by type ***********************************/
/**************************************************************************************/
void CFindSV::Formatofstream( ofstream* ofiles, const char* pfn, VString& vstr )
{
	char* 	pdo = AfxGetValue("--o");
	string 	strdo(pfn);
	if(pdo != NULL && pdo != "")
	{
		strdo.assign(strdo, strdo.rfind('/')+1, strdo.length()-strdo.rfind('/')-1);
		strdo.insert(0, "/");
		strdo.insert(0, pdo);
	}
	
	if(AfxGetValue("-cluster") != NULL)
	{
		string	str = strdo;
		str.insert(str.length(), ".cluster");
		ofiles[CLUSTER].open(str.c_str());
	}
	
	string	str1 = strdo;
	str1.insert(str1.length(), ".sv");
	ofiles[SV].open(str1.c_str());
	pthread_mutex_lock(&mutex_c);
	vstr.push_back(str1);
	pthread_mutex_unlock(&mutex_c);
	
}

void CFindSV::Closeofstream( ofstream* ofiles )
{
	for (int i=0; i<COUNT; i++)
	{
		if(ofiles[i].good())
			ofiles[i].close();
	}
}
void CFindSVEx::findcluster2(VPAIREND& VPE, MCLUSTER& mclst)
{//cluster pe

// in VPE there are pair ends of same insertsize

	map<char, VPAIREND >	mcvpe;


cout << "------------ in findcluster2 VPE.size: "<< VPE.size() << endl;
//printf ("------------ in findcluster2 VPE.size: %s\n", VPE.size());  //<< VPE.size() << endl;

	for (size_t i=0; i<VPE.size(); i++) // note .this "VPE.size()" not equal "VPE[i].size()"
	{


//cout << "-------------- VPE[i].ch: " << VPE[i].ch << endl;
//printf("-------------- VPE[i].ch: %s\n",VPE[i].ch);

		mcvpe[VPE[i].ch].push_back(VPE[i]); // classify by ch for pair ends :same ch ,same insertsize
	}
	for (map<char, VPAIREND >::iterator it1=mcvpe.begin(); it1!=mcvpe.end(); ++it1)
	{




		VPAIREND&	vpe = it1->second; // get voctor of pair ends
cout << endl;

cout << "-**----------- mcvpe: " << it1->first <<" size: " << vpe.size() <<endl;
cout << endl;
/*
for (int k =0; k<vpe.size();++k)
{
	cout << k<<">"<<vpe[k].nStart <<":" <<vpe[k].size()<<"-" << vpe[k].mid() <<" ";
}
cout << endl;

*/



		_findcluster2(vpe, mclst);
		while (m_nclstCount != 0)	// initialize in "CFindSVEX():CFindSV()	m_nclstCount = 0
		{
			m_nclstCount = 0;
			for (VPAIRENDIT it=vpe.begin(); it!=vpe.end(); ++it)
			{
				if (it->nclst != -1)
				{
					vpe.erase(it);
					if (it != vpe.begin())
					{
						it--;
					}
				}
			}

			_findcluster2(vpe, mclst);
		}
	}
}

bool AscendD(PE_SCORE a, PE_SCORE b)
{
	return (a.sc<b.sc) ;
}


void CFindSVEx::_findcluster2( VPAIREND& VPE, MCLUSTER& mclst )
{
	MPE_SCORE	mpesc;
	MPETIMES	mpeti;
	scorepe2pe(VPE, mpesc, mpeti); // record every point of PE_SCORE information in mpesc
////	
/*cout <<"--- mpeti" << endl;
for (MPETIMES::iterator it=mpeti.begin();it!=mpeti.end();++it)
{
cout << " "<< it->first <<":"<< it->second;
}
cout << endl;
*/
///


	for (MPE_SCORE::iterator it=mpesc.begin(); it!=mpesc.end(); ++it)
	{
		sort(it->second.begin(), it->second.end(), AscendD);//sort mpec by PE_SCORE.sc
	}

///
cout <<"--- mpesc size: "<< mpesc.size() ;

/*

 for (MPE_SCORE::iterator it=mpesc.begin(); it!=mpesc.end(); ++it)
        {
		cout <<" ["<< it->first <<"]" ;//<< it->second.sc <<" ";
		for (int k = 0; k < it->second.size();++k)
		cout <<it->second[k].nid <<"-"<<int(it->second[k].sc) <<" ";
	

	}
*/
//cout << endl;

////

	seeksimilar(VPE, mpesc, mclst, mpeti);
}

void CFindSVEx::seeksimilar( VPAIREND& vpe, MPE_SCORE& mpesc, MCLUSTER& mclst, MPETIMES& mpeti )
{
	char*	pcl = AfxGetValue("--cl");
	int		ncl = (pcl == NULL || pcl == "") ? 3 : atoi(pcl);

	for (MPE_SCORE::iterator it=mpesc.begin(); it!= mpesc.end(); ++it)
	{
		if (it->second[0].buse)
		{
			continue;
		}
		vector<int>		vi;
		PE_POSINFO		ppi;
		vi.push_back(it->first);		
 		vi.push_back(it->second[0].nid);
////////////////
		if(mpeti[it->first]>mpeti[it->second[0].nid])	// note: the mpesc is sort by ascend
		{
			ppi.nmax = mpeti[it->first];
			ppi.npos = 0;
		}
		else
		{
			ppi.nmax = mpeti[it->second[0].nid];
			ppi.npos = 1;
		}
////////////////
		if (mpesc.find(it->second[0].nid) != mpesc.end())
		{
			if (mpesc[it->second[0].nid][0].buse)
			{
				continue;
			}
			int	ni = mpesc[it->second[0].nid][0].nid;
/*
cout << endl;
cout << "mpesc-key:" << it->first <<":"<< it->second[0].nid <<":"<<ni <<" ppi:" << ppi.nmax <<":" << ppi.npos << endl;
cout << "before recursion vi: ";
for (int t=0; t<vi.size();++t)
{
	cout <<"." << vi[t] ;
}
cout << endl;
cout << "== in recursion: ";

*/
			while(recursion(mpesc, vi, ni, mpeti, ppi)){};
		}


/*
cout << endl;
cout << "after recursion vi :  ";
for (int t=0; t<vi.size();++t)
{
        cout <<"." << vi[t] ;
}
cout << endl;
cout << endl;


cout <<"-------cluster ";

*/
////////////////
	    int		nn = vi.size();
		if (nn >= ncl)
		{
			__int64	s = 0;
			__int64 e = 0;
			CLUSTER_INFO	ci;
            int vpe_size=vpe.size();
			if(vi[0]>=vpe_size)continue;
			ci.nmaxEnd = ci.nminEnd = vpe[vi[0]].nEnd;
			for (int i=0; i<nn ; i++)
			{
				if(vi[i]>=vpe_size)continue;
				vpe[vi[i]].nclst = m_nclst;
				mclst[m_nclst].push_back(vpe[vi[i]]);
				s += vpe[vi[i]].nStart;
				e += vpe[vi[i]].nEnd;
				ci.nmaxEnd = MAX(ci.nmaxEnd, vpe[vi[i]].nEnd);
				ci.nminEnd = MIN(ci.nminEnd, vpe[vi[i]].nEnd);
				mpesc[vi[i]][0].buse = true;

/*
cout << "[" <<m_nclst<<" "<< vi[i] <<"-" <<  vpe[vi[i]].ch <<":" <<  vpe[vi[i]].nInsert <<":"<<  vpe[vi[i]].nStart <<":" << vpe[vi[i]].nEnd <<"] ";
*/

			}
//cout << endl;


			_pair_end	pe(vpe[vi[0]]);
			pe.nStart = int(s/nn);
			pe.nEnd	  = int(e/nn);
			mclst[m_nclst].push_back(pe);//cluster detail

/*
cout << "Avg start:end:dis "<<pe.nStart <<":" << pe.nEnd<<":"<< pe.nEnd - pe.nStart;
cout << endl;
cout << endl;
*/
			m_mci[m_nclst] = ci;//cluster info
			m_nclst++;
			m_nclstCount++;
			if (it == mpesc.end())
			{
				break;
			}
		}
		vi.clear();
	}

	for (MPE_SCORE::iterator it=mpesc.begin(); it!= mpesc.end(); ++it)
	{
		it->second.clear();
	}
	mpesc.clear();
	mpeti.clear();
}

void CFindSVEx::scorepe2pe( VPAIREND& vpe, MPE_SCORE& mpesc, MPETIMES& mpeti )
{
	char*	pSpan	= AfxGetValue("--mI");
	int		minspan	= (pSpan==NULL || pSpan=="") ? 0 : atoi(pSpan);
	char*	pLim	= AfxGetValue("--cd");
	int		lim		= (pLim==NULL || pLim=="") ? 200 : atoi(pLim);
	char*	pCR		= AfxGetValue("--cr");
	__uint8	nCR		= (pCR==NULL || pCR=="") ? 8 : (__int8)atoi(pCR);

	for (int i=0; i<(int)vpe.size(); i++)
	{
		if (vpe[i].size() < minspan) // in vpe[i].size() is the "nEnd - nStart"
			continue;
		if (vpe[i].size() > 10000)
			lim = int(0.05*vpe[i].size());
		else if (vpe[i].size() > 1000)
			lim = 200;//vpe[i].nInsert;
		else if(vpe[i].size() > 500)
			lim = int(0.1*(float)vpe[i].size());//int(vpe[i].nInsert/2);
		else if (vpe[i].size() < 100)
			lim = int(0.1*(float)vpe[i].size());//int(vpe[i].nInsert/5);
		else
			lim = int(float(vpe[i].size())*0.1);

//cout << "--- scorepe2pe: "<< i << " minspan " << minspan ;

		for(int j=i+1; j<(int)vpe.size(); j++)
		{
			if ((vpe[j].size()<minspan) || (vpe[j].ch!=vpe[i].ch))
				continue;
			if (vpe[j].nStart >= vpe[i].mid() || vpe[j].nStart < vpe[i].nStart)
				break;
			
			PE_SCORE	ps;
			ps.nid = j;
			ps.sc  = score(vpe[i], vpe[j], lim);	
//cout << " " << ps.nid << "-" <<(int) ps.sc << "-" << vpe[j].nStart <<":" << vpe[i].mid();
//cout <<" " << i <<":" << j;

			if (ps.sc <= nCR)
			{
				mpesc[i].push_back(ps);
			int ti = mpeti[i]++;			//this part record the repeats of every pe
			int tj = mpeti[j]++;

//cout <<"-"<< ti <<":"<< tj;
			}
		}
//cout << endl;
//cout <<" mpesc_size "<< mpesc.size() << endl;

	}
}

void CFindSVEx::Readjust( MPE_SCORE& mpesc, vector<int>& vi )
{
	for (int i=0; i<(int)vi.size(); i++)
	{
		mpesc[vi[i]][0].buse = true;
	}
}

struct SS 
{
	int		p;
	int		c;
};

bool comp(SS a, SS b)
{
	return a.p < b.p;
}

void CFindSVEx::sortcluster( MCLUSTER& mclst )
{
	vector<SS>	vss;
	for (MCLUSTERIT it=mclst.begin(); it!=mclst.end(); ++it)
	{
		SS ss;
		ss.p = (it->second.end()-1)->nStart;
		ss.c = it->first;
		vss.push_back(ss);
	}
	sort(vss.begin(), vss.end(), comp);
	for (size_t i=0;i < vss.size(); i++)
	{
		m_mpc[i] = vss[i].c;
	}
}

void CFindSVEx::DetectSV( MCLUSTER& mclst, ofstream& ofile )
{
	if(mclst.size()==0)return;
	sortcluster( mclst );
	for (MPECLUSTERIT it=m_mpc.begin(); it!=m_mpc.end(); ++it)
	{
		switch (mclst[it->second][0].ch)
		{
		case FF:
			FindByFF(it, mclst, ofile);
			break;
		case FR:
			FindByFR(it, mclst, ofile);
			break;
		case RF:
			FindByRF(it, mclst, ofile);
			break;
		case RR:
			FindByRR(it, mclst, ofile);
			break;
		case '4':
			FindBy4(it, mclst, ofile);
			break;
		default:
			break;
		}
	}
}

inline void CFindSVEx::FindByFF( MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile )
{
	int		maxIns = 500;
	int		CL = 500;
	char	ch1= mclst[it->second][0].ch;
	int		avgs0 = (mclst[it->second].end()-1)->nStart;
	int		avge0 = (mclst[it->second].end()-1)->nEnd;
	int		mins0 = (mclst[it->second].begin())->nStart;
	int		mine0 = m_mci[it->second].nminEnd;
	int		maxs0 = (mclst[it->second].end()-2)->nStart;
	int		maxe0 = m_mci[it->second].nmaxEnd;
	for (MPECLUSTERIT it1=it; it1!=m_mpc.end(); ++it1)
	{
		if (it1==it)
			continue;
		if ((mclst[it1->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nEnd)
			break;
		int		avgs = (mclst[it1->second].end()-1)->nStart;
		int		avge = (mclst[it1->second].end()-1)->nEnd;
		int		mins = (mclst[it1->second].begin())->nStart;
		int		mine = m_mci[it1->second].nminEnd;
		int		maxs = (mclst[it1->second].end()-2)->nStart;
		int		maxe = m_mci[it1->second].nmaxEnd;
		char	ch2  = mclst[it1->second][0].ch;
		
		if(XX((mclst[it->second].end()-1)->nStart, (mclst[it1->second].end()-1)->nStart, 
			  (mclst[it->second].end()-1)->nEnd, (mclst[it1->second].end()-1)->nEnd) && ch2==RR)
		{
			if ((mclst[it1->second].end()-1)->size()+CL>(mclst[it->second].end()-1)->size() &&
				(mclst[it->second].end()-1)->size()+CL>(mclst[it1->second].end()-1)->size())
			{
				ofile<<m_strchr<<'\t';
				ofile<<"Inversion\t"<<m_nsvCount++<<'\t'<<(mclst[it->second].end()-1)->nStart<<'\t'<<(mclst[it1->second].end()-1)->nEnd<<'\t';
				ofile<<"Inversion-Loc\t"<<(mins+(mclst[it->second].end()-2)->nStart)/2<<'\t'<<(mine+m_mci[it->second].nmaxEnd)/2<<'\t';
				ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\t';
				ofile<<m_mcc[ch2]<<'-'<<avgs<<'\t'<<mclst[it1->second].size()-1<<'\n';
			}
			else if ((mclst[it1->second].end()-1)->size()+CL<(mclst[it->second].end()-1)->size())
			{
				ofile<<m_strchr<<'\t';
				ofile<<"Deletion+Inversion\t"<<m_nsvCount++<<'\t'<<"Deletion:\t"<<(mclst[it->second].end()-1)->nStart<<'\t'<<(mclst[it1->second].end()-1)->nStart<<'\t';
				ofile<<"Inversion:\t"<<(mclst[it1->second].end()-1)->nStart<<'\t'<<(mclst[it1->second].end()-1)->nEnd<<'\t';
				ofile<<"Deletion-Loc\t"<<(mclst[it->second].end()-2)->nStart<<'\t'<<(mclst[it1->second].begin())->nStart<<'\t';
				ofile<<"Inversion-Loc\t"<<mins<<'\t'<<(mine+m_mci[it->second].nmaxEnd)/2<<'\t';
				ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\t';
				ofile<<m_mcc[ch2]<<'-'<<avgs<<'\t'<<mclst[it1->second].size()-1<<'\n';
			}
			else if ((mclst[it->second].end()-1)->size()+CL<(mclst[it1->second].end()-1)->size())
			{
				ofile<<m_strchr<<'\t';
				ofile<<"Inversion+Deletion\t"<<m_nsvCount++<<'\t'<<"Inversion:\t"<<(mclst[it->second].end()-1)->nStart<<'\t'<<(mclst[it->second].end()-1)->nEnd<<'\t';
				ofile<<"Deletion:\t"<<(mclst[it->second].end()-1)->nEnd<<'\t'<<(mclst[it1->second].end()-1)->nEnd<<'\t';
				ofile<<"Inversion-Loc\t"<<((mclst[it->second].end()-2)->nStart+mclst[it1->second][0].nStart)/2<<'\t'<<m_mci[it->second].nmaxEnd<<'\t';
				ofile<<"Deletion-Loc\t"<<m_mci[it->second].nmaxEnd<<'\t'<<m_mci[it1->second].nminEnd<<'\t';
				ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\t';
				ofile<<m_mcc[ch2]<<'-'<<avgs<<'\t'<<mclst[it1->second].size()-1<<'\n';
			}
		}
		else if ((mclst[it->second].end()-1)->nEnd>(mclst[it1->second].end()-1)->nEnd && ch2==RR)
		{
			int		invbreakpoint = (mins - maxs0 < maxIns) ? (mins+maxs0)/2 : maxs0;
			ofile<<m_strchr<<'\t';
			ofile<<"Duplication+Inversion_upstream\t"<<m_nsvCount++<<'\t'<<avgs0<<'\t'<<avge0<<'\t';
			ofile<<"InversionBreakpoint\t"<<invbreakpoint<<'\t';
			ofile<<"Duplication-Loc\t"<<mine<<'\t'<<maxe0<<'\t';
			ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\t';
			ofile<<m_mcc[ch2]<<'-'<<avgs<<'\t'<<mclst[it1->second].size()-1<<'\n';

			for (MPECLUSTERIT it2 = it1; it2!=m_mpc.end(); ++it2)
			{
				if (it1==it2)
					continue;
				if((mclst[it2->second].end()-1)->nStart>=avge)
					break;
				int		avgs1 = (mclst[it2->second].end()-1)->nStart;
				int		avge1 = (mclst[it2->second].end()-1)->nEnd;
				int		mins1 = (mclst[it2->second].begin())->nStart;
				int		mine1 = m_mci[it2->second].nminEnd;
				int		maxs1 = (mclst[it2->second].end()-2)->nStart;
				int		maxe1 = m_mci[it2->second].nmaxEnd;
				char	ch3  = mclst[it2->second][0].ch;
				if (ch3==FR && avge1 > avge0)
				{
					ofile<<m_strchr<<'\t';
					ofile<<"Translocation+Inversion_upstream\t"<<m_nsvCount++<<'\t'<<avgs0<<'\t'<<avge1<<'\t';
					ofile<<"InversionBreakpoint\t"<<invbreakpoint<<'\t';
					ofile<<"Translcation-Loc\t"<<(maxs1+mine)/2<<'\t'<<(mine1+maxe0)/2<<'\t';
					ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\t';
					ofile<<m_mcc[ch2]<<'-'<<avgs<<'\t'<<mclst[it1->second].size()-1<<'\t';
					ofile<<m_mcc[ch3]<<'-'<<avgs1<<'\t'<<mclst[it2->second].size()-1<<'\n';
				}
			}
		}
	}
}

inline void CFindSVEx::FindByFR( MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile )
{
	int		maxIns = 500;
	int		CL = 500;
	char	ch1= mclst[it->second][0].ch;
	int		avgs = (mclst[it->second].end()-1)->nStart;
	int		avge = (mclst[it->second].end()-1)->nEnd;
	int		mins = (mclst[it->second].begin())->nStart;
	int		mine = m_mci[it->second].nminEnd;
	int		maxs = (mclst[it->second].end()-2)->nStart;
	int		maxe = m_mci[it->second].nmaxEnd;

	ofile<<m_strchr<<'\t';
	ofile<<"Deletion\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge<<'\t';
	ofile<<"Deletion-Loc\t"<<maxs<<'\t'<<mine<<'\t';
	ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\n';

	for (MPECLUSTERIT it1=it; it1!=m_mpc.end(); ++it1)
	{
		if (it1==it)
			continue;
		if ((mclst[it1->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nStart)
			break;
		int		avgs1 = (mclst[it1->second].end()-1)->nStart;
		int		avge1 = (mclst[it1->second].end()-1)->nEnd;
		int		mins1 = (mclst[it1->second].begin())->nStart;
		int		mine1 = m_mci[it1->second].nminEnd;
		int		maxs1 = (mclst[it1->second].end()-2)->nStart;
		int		maxe1 = m_mci[it1->second].nmaxEnd;
		char	ch2  = mclst[it1->second][0].ch;
		
		if (ch2==RR && avge1>avge)
		{
			for (MPECLUSTERIT it2=it1; it2!=m_mpc.end(); ++it2)
			{
				if (it2==it1)
					continue;
				if ((mclst[it2->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nEnd)
					break;
				int		avgs2 = (mclst[it2->second].end()-1)->nStart;
				int		avge2 = (mclst[it2->second].end()-1)->nEnd;
				int		mins2 = (mclst[it2->second].begin())->nStart;
				int		mine2 = m_mci[it2->second].nminEnd;
				int		maxs2 = (mclst[it2->second].end()-2)->nStart;
				int		maxe2 = m_mci[it2->second].nmaxEnd;
				char	ch3  = mclst[it2->second][0].ch;
				
				if (ch3==FF && avge2>avge && avge2<avge1)
				{
					int		invbreakpoint = (maxe2-mine1<maxIns) ? (maxe2+mine1)/2 : maxe2;
					ofile<<m_strchr<<'\t';
					ofile<<"Translocation+Inversion_downstream\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge2<<'\t';
					ofile<<"Translocation-Loc\t"<<(maxs+mins1)/2<<'\t'<<(maxs2+mine)/2<<'\t';
					ofile<<"InversionBreakpoint\t"<<invbreakpoint<<'\t';
					ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\t';
					ofile<<m_mcc[ch2]<<'-'<<avgs1<<'\t'<<mclst[it1->second].size()-1<<'\t';
					ofile<<m_mcc[ch3]<<'-'<<avgs2<<'\t'<<mclst[it2->second].size()-1<<'\n';
				}
			}
		}

		if (ch2==RF && avge1>avge)
		{
			int		insertbreakpoint = (mins1-maxs<maxIns) ? (mins1+maxs)/2 : maxs;
			ofile<<m_strchr<<'\t';
			ofile<<"DispersedDuplication_upstream\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge1<<'\t';
			ofile<<"InsertBreakpoint\t"<<insertbreakpoint<<'\t';
			ofile<<"Duplication-Loc\t"<<mine<<'\t'<<maxe1<<'\t';
			ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\t';
			ofile<<m_mcc[ch2]<<'-'<<avgs1<<'\t'<<mclst[it1->second].size()-1<<'\n';

			for (MPECLUSTERIT it2=it1; it2!=m_mpc.end(); ++it2)
			{
				if (it2==it1)
					continue;
				if ((mclst[it2->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nEnd)
					break;
				int		avgs2 = (mclst[it2->second].end()-1)->nStart;
				int		avge2 = (mclst[it2->second].end()-1)->nEnd;
				int		mins2 = (mclst[it2->second].begin())->nStart;
				int		mine2 = m_mci[it2->second].nminEnd;
				int		maxs2 = (mclst[it2->second].end()-2)->nStart;
				int		maxe2 = m_mci[it2->second].nmaxEnd;
				char	ch3  = mclst[it2->second][0].ch;

				if (ch3==FR && (mclst[it->second].end()-1)->size()>(mclst[it2->second].end()-1)->size())
				{
					insertbreakpoint = (mins1-maxs<maxIns) ? (mins1+maxs)/2 : maxs;
					ofile<<m_strchr<<'\t';
					ofile<<"Translocation_upstream\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge2<<'\t';
					ofile<<"InsertBreakpoint\t"<<insertbreakpoint<<'\t';
					ofile<<"Translocation-Loc\t"<<(maxs2+mine)/2<<'\t'<<(maxe1+mine2)/2<<'\t';
					ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\t';
					ofile<<m_mcc[ch2]<<'-'<<avgs1<<'\t'<<mclst[it1->second].size()-1<<'\t';
					ofile<<m_mcc[ch3]<<'-'<<avgs2<<'\t'<<mclst[it2->second].size()-1<<'\n';
				}
				else if (ch3==FR && (mclst[it->second].end()-1)->size()<(mclst[it2->second].end()-1)->size())
				{
					insertbreakpoint = (mine2-maxe1<maxIns) ? (mine2+maxe1)/2 : maxe1;
					ofile<<m_strchr<<'\t';
					ofile<<"Translocation_downstream\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge2<<'\n';
					ofile<<"InsertBreakpoint\t"<<insertbreakpoint<<'\t';
					ofile<<"Translocation-Loc\t"<<(maxs+maxs1)/2<<'\t'<<(maxs2+mine)/2<<'\t';
					ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\t';
					ofile<<m_mcc[ch2]<<'-'<<avgs1<<'\t'<<mclst[it1->second].size()-1<<'\t';
					ofile<<m_mcc[ch3]<<'-'<<avgs2<<'\t'<<mclst[it2->second].size()-1<<'\n';
				}
			}
		}
	}
}

inline void CFindSVEx::FindByRF( MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile )
{
	int		maxIns = 500;
	int		CL = 500;
	char	ch1= mclst[it->second][0].ch;
	int		avgs = (mclst[it->second].end()-1)->nStart;
	int		avge = (mclst[it->second].end()-1)->nEnd;
	int		mins = (mclst[it->second].begin())->nStart;
	int		mine = m_mci[it->second].nminEnd;
	int		maxs = (mclst[it->second].end()-2)->nStart;
	int		maxe = m_mci[it->second].nmaxEnd;

	ofile<<m_strchr<<'\t';
	ofile<<"TandemDuplication\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge<<'\t';
	ofile<<"Duplication-Loc\t"<<maxs<<'\t'<<mine<<'\t';
	ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\n';

	for (MPECLUSTERIT it1=it; it1!=m_mpc.end(); ++it1)
	{
		if (it1==it)
			continue;
		if ((mclst[it1->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nEnd)
			break;
		int		avgs1 = (mclst[it1->second].end()-1)->nStart;
		int		avge1 = (mclst[it1->second].end()-1)->nEnd;
		int		mins1 = (mclst[it1->second].begin())->nStart;
		int		mine1 = m_mci[it1->second].nminEnd;
		int		maxs1 = (mclst[it1->second].end()-2)->nStart;
		int		maxe1 = m_mci[it1->second].nmaxEnd;
		char	ch2  = mclst[it1->second][0].ch;

		if (ch2==FR && avge1>avge)
		{
			int		insertbreakpoint = (mine1-maxe<maxIns) ? (mine1+maxe)/2 : mine1;
			ofile<<m_strchr<<'\t';
			ofile<<"DispersedDuplication_downstream\t"<<m_nsvCount++<<'\t'<<avgs<<'\t'<<avge1<<'\t';
			ofile<<"Duplication-Loc\t"<<mins<<'\t'<<maxs1<<'\t';
			ofile<<"InsertBreakpoint\t"<<insertbreakpoint<<'\t';
			ofile<<m_mcc[ch1]<<'-'<<avgs<<'\t'<<mclst[it->second].size()-1<<'\t';
			ofile<<m_mcc[ch2]<<'-'<<avgs1<<'\t'<<mclst[it1->second].size()-1<<'\n';
		}
	}
}

inline void CFindSVEx::FindByRR( MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile )
{
	int		maxIns = 500;
	int		CL = 500;
	char	ch1= mclst[it->second][0].ch;
	int		avgs0 = (mclst[it->second].end()-1)->nStart;
	int		avge0 = (mclst[it->second].end()-1)->nEnd;
	int		mins0 = (mclst[it->second].begin())->nStart;
	int		mine0 = m_mci[it->second].nminEnd;
	int		maxs0 = (mclst[it->second].end()-2)->nStart;
	int		maxe0 = m_mci[it->second].nmaxEnd;
	for (MPECLUSTERIT it1=it; it1!=m_mpc.end(); ++it1)
	{
		if (it1==it)
			continue;
		if ((mclst[it1->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nEnd)
			break;
		int		avgs = (mclst[it1->second].end()-1)->nStart;
		int		avge = (mclst[it1->second].end()-1)->nEnd;
		int		mins = (mclst[it1->second].begin())->nStart;
		int		mine = m_mci[it1->second].nminEnd;
		int		maxs = (mclst[it1->second].end()-2)->nStart;
		int		maxe = m_mci[it1->second].nmaxEnd;
		char	ch2  = mclst[it1->second][0].ch;
		
		if (ch2==FF && (mclst[it->second].end()-1)->nEnd>(mclst[it1->second].end()-1)->nEnd)
		{
			int		invbreakpoint = (mine0-maxe<maxIns) ? (mine0+maxe)/2 : mine0;
			ofile<<m_strchr<<'\t';
			ofile<<"Duplication+Inversion_downstream\t"<<m_nsvCount++<<'\t'<<avgs0<<'\t'<<avge0<<'\t';
			ofile<<"Duplication-Loc\t"<<mins0<<'\t'<<maxs<<'\t';
			ofile<<"InversionBreakpoint\t"<<invbreakpoint<<'\t';
			ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\t';
			ofile<<m_mcc[ch2]<<'-'<<avgs<<'\t'<<mclst[it1->second].size()-1<<'\n';
		}
	}
}

inline void CFindSVEx::FindBy4( MPECLUSTERIT& it, MCLUSTER& mclst, ofstream& ofile )
{
	int		maxIns = 500;
	int		CL = 500;
	char	ch1= mclst[it->second][0].ch;
	int		avgs0 = (mclst[it->second].end()-1)->nStart;
	int		avge0 = (mclst[it->second].end()-1)->nEnd;
	int		mins0 = (mclst[it->second].begin())->nStart;
	int		mine0 = m_mci[it->second].nminEnd;
	int		maxs0 = (mclst[it->second].end()-2)->nStart;
	int		maxe0 = m_mci[it->second].nmaxEnd;
	map<char, int>	mci;
	for (MPECLUSTERIT it1=it; it1!=m_mpc.end(); ++it1)
	{
		if (it1==it)
			continue;
		if ((mclst[it1->second].end()-1)->nStart >= (mclst[it->second].end()-1)->nEnd)
			break;
		mci[mclst[it1->second][0].ch]++;
	}
	if (mci.size() == 0)
	{// insertion1
		ofile<<m_strchr<<'\t';
		ofile<<"Insertion\t"<<m_nsvCount++<<'\t';
		ofile<<(mclst[it->second].end()-1)->nStart<<'\t'<<(mclst[it->second].end()-1)->nEnd<<'\t';
		ofile<<"Insertion-Loc\t"<<(mclst[it->second].end()-2)->nStart<<'\t'<<m_mci[it->second].nminEnd<<'\t';
		ofile<<"InsertBreakPoint\t"<<(m_mci[it->second].nminEnd+(mclst[it->second].end()-2)->nStart)/2<<'\t';
		ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\n';
	}
	else if (mci.size()==1 && mci.find('4')!=mci.end())
	{// insertion2
		ofile<<m_strchr<<'\t';
		ofile<<"Insertion\t"<<m_nsvCount++<<'\t';
		ofile<<(mclst[it->second].end()-1)->nStart<<'\t'<<(mclst[it->second].end()-1)->nEnd<<'\t';
		ofile<<"Insertion-Loc\t"<<(mclst[it->second].end()-2)->nStart<<'\t'<<m_mci[it->second].nminEnd<<'\t';
		ofile<<"InsertBreakPoint\t"<<(m_mci[it->second].nminEnd+(mclst[it->second].end()-2)->nStart)/2<<'\t';
		ofile<<m_mcc[ch1]<<'-'<<avgs0<<'\t'<<mclst[it->second].size()-1<<'\n';
	}
}

#endif //_FINDSV2_H_

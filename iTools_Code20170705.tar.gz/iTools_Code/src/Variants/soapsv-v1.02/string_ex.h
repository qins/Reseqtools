#ifndef _STRING_EX_H_
#define _STRING_EX_H_

//basic_string

#include "include.h"


#ifndef VString
typedef vector<string>		VString;
typedef VString::iterator	VStringIT;
#endif

#ifndef VVString
typedef vector<VString>		VVString;
typedef VVString::iterator	VVStringIT;
#endif

class string_ex : public string
{
public:
	string_ex();
	string_ex(const string& s);
	string_ex(const string_ex& s);
	string_ex(const char* s);
	string_ex& operator=(const string_ex& s);
	string_ex& operator=(const string& s);

#ifndef vstring_ex
	typedef vector<string_ex>		vstring_ex;
	typedef vstring_ex::iterator	vstring_exit;
#endif
	
#ifndef vvstring_ex
	typedef vector<vstring_ex>		vvstring_ex;
	typedef vvstring_ex::iterator	vvstring_exit;
#endif

	string_ex&	erase(char ch);
	string_ex&	erase(const char* pch);
	string_ex&	to_upper();
	string_ex&	to_lower();
	string_ex&	trim();//trim all space ' ', '\t', '\n'
	string_ex&	trimright(char ch);
	string_ex&	trimright(const char* pch);
	string_ex&	trimleft(char ch);
	string_ex&	trimleft(const char* pch);
	int			split(vstring_ex& vstr);// split by space ' ' and '\t'
	int			split(vstring_ex& vstr, char ch);// for given character
	int			split(vstring_ex& vstr, const char* pch); // split by given string.  Return count of items after splitting.
	
private:
	bool		_split(string_ex str, vstring_ex& vstr, char ch);
};

string_ex::string_ex() : string()
{
}

string_ex::string_ex(const string_ex& str) : string(str)
{
}

string_ex::string_ex( const char* s ) : string(s)
{
}

string_ex::string_ex( const string& s ) : string(s)
{
}

string_ex& string_ex::operator=( const string_ex& s )
{	
	assign(s.c_str());
	return *this;
}

string_ex& string_ex::operator=( const string& s )
{
	assign(s.c_str());
	return *this;
}

string_ex& string_ex::erase( char ch )
{
	string tmp = *this;
	tmp.erase(remove_if(tmp.begin(), tmp.end(), bind2nd(equal_to<char>(), ch)), tmp.end());
	*this = tmp;
	return *this;
}

string_ex& string_ex::erase( const char* pch )
{
	return *this;
}

string_ex& string_ex::to_upper()
{
	transform(begin(), end(), begin(), (int(*)(int))toupper);
	return *this;
}

string_ex& string_ex::to_lower()
{
	transform(begin(), end(), begin(), (int(*)(int))tolower);
	return *this;
}

string_ex& string_ex::trim()
{
	this->erase(this->find_last_not_of('\n') + 1);
	this->erase(this->find_last_not_of(' ') + 1);
	this->erase(this->find_last_not_of('\t') + 1);
	this->erase(this->find_first_not_of(' ') + 1);
	this->erase(this->find_first_not_of('\t') + 1);
	return *this;
}

string_ex& string_ex::trimright( char ch )
{
	this->erase(this->find_last_not_of(ch) + 1);
	return *this;
}

string_ex& string_ex::trimright( const char* pch )
{
	this->erase(this->find_last_not_of(pch) + 1);
	return *this;
}

string_ex& string_ex::trimleft( char ch )
{
	this->erase(this->find_first_not_of(ch) + 1);
	return *this;
}

string_ex& string_ex::trimleft( const char* pch )
{
	this->erase(this->find_first_not_of(pch) + 1);
	return *this;
}

int string_ex::split( vstring_ex& vstr )
{
	trimright('\n');
	string_ex	temp = *this;
	replace_if(temp.begin(), temp.end(), bind2nd(equal_to<char>(), ' '), '\t');
	_split(temp, vstr, '\t');
	return vstr.size();
}

int string_ex::split( vstring_ex& vstr, char ch )
{
	trimright('\n');
	_split(*this, vstr, ch);
	return vstr.size();
}

int string_ex::split( vstring_ex& vstr, const char* pch )
{
	trimright('\n');
	string_ex	temp = *this;
	int npos = -1;
	while((npos=temp.find(pch)) != -1)
		temp.replace(npos, strlen(pch), "\t");    
	_split(temp, vstr, '\t');
	return vstr.size();
}

bool string_ex::_split( string_ex str, vstring_ex& vstr, char ch )
{
	if (str.empty())
	{
		return false;
	}
	
	int npos = str.find(ch, 0);
	int nposlast = 0;
	while(npos != -1)
	{
		string_ex  word;
		if (npos == 0)
		{
			npos = str.find(ch, 1);
			if(npos != -1)
			{
				word = str.substr(1, npos - 1);
				vstr.push_back(word);
			}
		}
		else
		{
			word = str.substr(nposlast, npos - nposlast);
			vstr.push_back(word);
			nposlast = npos;
			
			while(str[nposlast] == ch)
			{nposlast++;}
			
			npos = str.find(ch, nposlast);
		}
	}
	vstr.push_back(str.substr(nposlast, str.length() - nposlast));
	
	return true;
}
#endif //_STRING_EX_H_

// table.h
#ifndef _TABLE_H_
#define	_TABLE_H_

//table.cpp
#include "include.h"
#include "table.h"

#ifndef VString
typedef vector<string>		VString;
typedef VString::iterator	VStringIT;
#endif

#ifndef VString
typedef vector<VString>		VVString;
typedef VVString::iterator	VVStringIT;
#endif

class _table_t
{
public: _table_t(){}
	~_table_t(){m_vvstring.clear();}
private:
	VVString 	m_vvstring;
public:
	bool 		write(const char* pfn);
//	bool 		sort(int _index);
	VString&	read(int _index);
	string  	operator[](int _i1);
	int			size();
	void		Release();

/*///
public:
	static bool	Split(string str, VString &vstr);// For ' ', '\t', '\n' 
	static bool	Split(string str, VString &vstr, char ch);
	static bool	split(string str, VString &vstr, char ch);
	static int      split2(string str, VString &vstr, char ch);
///*///
};
//#include <boost/tokenizer.hpp>
//using namespace boost;

//#ifndef Tokenizer
//typedef tokenizer<boost::char_separator<char> > Tokenizer;
//typedef char_separator<char> Separator;
//#endif

bool _table_t::write(const char* pfn)
{
	if(pfn == NULL)
		return false;
	igzstream	ifile(pfn);
	if(!ifile.good())
	{
		cout<<"No such file !"<<endl;
		return false;
	}
	
	string 		strline;
	
	while(getline(ifile, strline))
	{
		VString 	vstr;
		if (strline.empty())
		{
			 continue;
		}
//		if(!Split(strline, vstr, '\t'))
//			continue;
		split(strline, vstr, "\t \n");
		if ( vstr.size()<2)
		{
			 continue;
		}
		m_vvstring.push_back(vstr);
	}
	ifile.close();
	return true;
}

//bool _table_t::sort(int _index)
//{
	//	sort(m_vvstring.begin(), m_vvstring.end());
//}

VString& _table_t::read(int _index)
{
	return m_vvstring[_index];
}

string _table_t::operator[](int _i1)
{
	return string("aa");//m_vvstring[_i1];
}

//bool _table_t::Split(string str, VString &vstr, char ch)
//{
/*	if (str.empty())
	{
		return false;
	}
	char	cha[2];
	cha[0] = ch;cha[1]='\0';
	Separator		sep(cha);
	Tokenizer		token(str, sep);
	
	vstr.insert(vstr.end(), token.begin(), token.end());
	
*/
//	return true;
//}

//bool _table_t::Split( string str, VString &vstr )
//{
/*	if (str.empty())
	{
		return false;
	}

	Separator		sep(" \t\n");
	Tokenizer		token(str, sep);

	vstr.insert(vstr.end(), token.begin(), token.end());
	
*/	
//	return true;
//}

int _table_t::size()
{
	return m_vvstring.size();
}

void _table_t::Release()
{
	for (int i=0; i<(int)m_vvstring.size(); i++)
	{
		m_vvstring[i].clear();
	}
	m_vvstring.clear();
}
/*///
bool _table_t::split(string str, VString &vstr, char ch)
{
	if (str.empty())
	{
		return false;
	}
	
	int npos = str.find(ch, 0);
	int nposlast = 0;
	while(npos != -1)
	{
		if (npos == nposlast)
		{
			vstr.push_back("");
			nposlast++;
			npos = str.find(ch, nposlast);
			continue;
		}

		vstr.push_back(str.substr(nposlast, npos - nposlast));
		nposlast = npos;
		nposlast++;
		npos = str.find(ch, nposlast);
	}
	vstr.push_back(str.substr(nposlast, str.length() - nposlast));
	return true;
}

int _table_t::split2(string str, VString &vstr, char ch) // no used
{
	int nu = 0;
	
	if (str.empty())
	{
		return -1;
	}
	
	int npos = str.find(ch, 0);
	int nposlast = 0;
	while(npos != -1)
	{
		if (npos == nposlast)
		{
			vstr.push_back("");
			nposlast++;
			npos = str.find(ch, nposlast);
			continue;
		}

		vstr.push_back(str.substr(nposlast, npos - nposlast));
		nu++;
		
		nposlast = npos;
		nposlast++;
		npos = str.find(ch, nposlast);
	}
	vstr.push_back(str.substr(nposlast, str.length() - nposlast));
	return nu;
}

////*///
#endif

#include "include.h"
#include "common.h"
#include "main.h"

#include "Bamalign2pe.h"
#include "len2chrome.h"
#include "findSV.h"
#include "filtersv.h"
#include "simplify.h"


//Maintained	by Haikuan Zhang
//Modified		Date:	Wed Dec 15 10:10:37 CST 2010
/////////////// Readme /////////////////////////////
int  print_BamSVusage ()
{
cout <<""	
"This program is used to find structural variations(SV). \n"
"This program has four modules, and each module can execute independently if given right input parameters."
"In default, all modules executes orderly. In Bam.l includes all file names to be processed, and Bam data is"
"arranged by len--the raw Bam output. If commond -2 exist, all input file must have been rearranged by chromosome,"
"while -3: pair end files, -4: *.sv files.\n\n"
"Usage:\n"
"	[Options]        [Functions]\n"
"	-h --help -help  Call help.\n"
"	-i <str>	 *.l or *.lst or *.list. Include all filename,  If not, it will be considered as a single source file.\n"
"	-cl <int>	 Indicate the minimum count of pair ends in one cluster. Default is [3]\n"
"	-o <str>	 Output directory to include the result.Default (./)\n"
"	-insert <str>    File of insert size information:\n"
"			 	Format1 : len_id  insert_size  left_sd  right_sd.\n"
"			 	Format2 : len_id  insert_size  sd.\t( old [before Bamsv1.01] Format : id_len  insert_size  sd ).\n"
"			 Dierect Value:(just for single len)\n"
"				Format1 : insert_size  left_sd  right_sd.\n"
"				Format2 : insert_size  sd.\n"	
"	-gap <str>	 gap file. Format : chromeid   start   end \n"
"	-cpu <int>	 cpu for work. Default [4]\n"
"	-Q <int>	 quality limit. Default [20], mappingQ>=20 .\n"
"	-cluster	 Output cluster information into .cluster files.\n"
"	-image		 Draw SV image in png format.\n"
"	-normal		 Output normal PE\n"
"	-sim		 Do mixed chromosome Bam result,  designed for thousands of reference and each reference is short than 10M. \n"
"	-2		 Execute from align2pe, if Bam result have been split by chromosome.\n"
"	-3		 Execute from findsv, if input files are *.PE format.\n"
"	-4		 Execute from filtersv, if *.sv exists.\n"
"example:\n"
"	./Bamsv -i Bam.l -o result/ -insert 209-12 -gap file.gap -cl 5     //For a series of file,but one len\n"
"	./Bamsv -i Bam.l -o result/ -insert insertsize_info -gap file.gap -cl 5 //For a series of file. With insert_info file\n"
"	./Bamsv -i file.Bam -o result/ -insert 209-12-10 -gap file.gap -cl 5 -c2      //For a single file, Execute from align2pe.\n"
"\n" ;
return 1;
}

//VString		g_module;

int main_BamSV(int argc, char* argv[])
//int main(int argc, char* argv[])
{
	START_TIMER;
	if (argc == 1)
	{
		print_BamSVusage();
		return 0;
	}
	else
	{
		for (int i=1; i<argc; i++)
		{
			if(strcmp(argv[i], "-h")==0 || strcmp(argv[i], "--help")==0 || strcmp(argv[i], "-help")==0)
			{
				print_BamSVusage();
				return 0;
			}
		}
	}
	AfxGetOptions(argc, argv);
	string flag(AfxGetValue("-insert"));
	string suffix(".re");
	string name=flag+suffix;
	if(AfxGetValue("-sim") != NULL)
	{//new version
		main_simplify(argc, argv);
		END_TIMER;
		return 0;
	}
	
	// old version
	global_param	gp;
	if(main_len2chrome(argc, argv, (void*)&gp) == 0){cerr<<"len2chrome failed!"<<endl;return 0;}
	if(main_Bamalign2pe(argc, argv, (void*)&gp) == 0){cerr<<"align2pe failed!"<<endl;return 0;}
	if(main_findsv(argc, argv, (void*)&gp) == 0){cerr<<"findsv failed!"<<endl;return 0;}
	if(main_filtersv(argc, argv, (void*)&gp) == 0){cerr<<"filtersv failed!"<<endl;return 0;}
	
	ofstream outfile(name.c_str());
	outfile << "ok, is done!" << endl;
	outfile.close();

	END_TIMER;
	return 0;
	////////////////////////////////
}





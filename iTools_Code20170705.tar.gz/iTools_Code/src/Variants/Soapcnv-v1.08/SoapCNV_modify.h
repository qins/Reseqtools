#ifndef _CALC_CNV_H_ 
#define _CALC_CNV_H_ 

#include <string>
#include <vector>
#include <list>
#include <map>


#include <iostream>
#include <fstream>
#include <sstream>
#include <exception>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <iomanip>

#include <pthread.h>
#include <unistd.h>

#include "parse_cnv.h"
#include "../soapInDel-v1.09/math_fun.h"
#include "../soapInDel-v1.09/threadmgr.h"
#include "../../include/gzstream/gzstream.h"

using namespace std;

struct bkp_t {
	size_t pos;
	size_t win;
	float depth;
	float var;
	float pval;
	float pgc;
	float fval;
	bool isN;

	bkp_t():pos(0), win(0), depth(0), var(0), pval(0), pgc(0), isN(false){}
};


struct rc_bkp_t {
	size_t pos;
	size_t len;
	int type;
};


//struct bkp_comp {     bool operator() (bkp_t a,bkp_t b) { return a.pval < b.pval; } };



class stat_thread_t: public thread_base
{
	private:
		size_t index;               ///< the field is used for distinguish between threads 

	public:

		map<string, vector<record_t> > &bpstat_map;     ///< store the statistics information of indels of every base-pair
		vector<string> &file_list;                           ///< list of files to get statistics information

		stat_thread_t(map<string, vector<record_t> > &bpstat_vec1, vector<string> &file_list1): bpstat_map(bpstat_vec1), file_list(file_list1) {}

		void set_index(size_t i) {index = i;}

		int soap_file_stat(const char *file_name, map<string, vector<record_t> > &bpstat_map);      

		int depthbin_file_stat(const char *file_name, map<string, vector<record_t> > &bpstat_map);      

		//int alloc_rc();

		virtual void* task();                      

		virtual ~stat_thread_t(){}

};


class stat_t_CNV
{
	private:
		//map<string, vector<record_t> > bpstat_map;         ///< store the statistics information of indels of every base-pair
		map<string, long> chr_count;            //store the information about length of chromosomes 
		vector<string> file_list; 

		//int base_count(const char *file_name, map<string, long> &chr_count);  //get the length of chromosomes from the reference 

		//int read_file_list(vector<string> &file_list, char *file_list_file)
		int read_file_list(vector<string> &file_list, const char *file_list_file); //get the list of soap result files

		//int read_chrinfo(const char *file_name, map<string, long> &chr_count);                ///< get length of chromosomes from a given file

		//int alloc_rc(map<string, vector<record_t> > &bpstat_map, map<string, long> &chr_count);                                         ///< allocate memory resource


	public:
		int run_stat();                                         ///< statistics module entry
};

class calc_cnv_thread_t: public thread_base
{
	//list<bkp_t> bkp_list;
	float p_init_cutoff;
	float p_final_cutoff;
	//map<string, vector<record_t> > &bpstat_map;
	//vector<string> &chr_vec;
	//vector<string> &seq_vec;
	size_t index;


	int merge_bkp(list<bkp_t>::iterator biter,list<bkp_t> &bkp_list, float p_cutoff);
	void update_pval(list<bkp_t> &bkp_list);

	void update_pval(list<bkp_t> &bkp_list, vector<record_t> &bpstat_vec, string &seq);

	int init_bkp(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list); 


	public:
	void merge_loop(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list);

	bool merge_check(list<bkp_t>::iterator iter1, list<bkp_t>::iterator iter_curr, float thr, size_t Ncnt);

	void calc_fval(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list, size_t &notN_cnt);

	virtual void* task();

	public:
	//calc_cnv_thread_t(map<string, vector<record_t> > &bpstat_vec1, vector<string> &chr_vec1,
	//      vector<string> &seq_vec1):bpstat_map(bpstat_vec1),chr_vec1(chr_vec), seq_vec1(seq_vec){}
	calc_cnv_thread_t() {}

	void set_index(size_t i) {index = i;}
	virtual ~calc_cnv_thread_t(){}

};


float get_mean_depth(const vector<record_t> &bpstat_vec)
{
	unsigned long depth_sum = 0;
	size_t bp_count = 0;
	size_t i = 0;
	size_t vec_sz = bpstat_vec.size();

	while (i < vec_sz) {
		if (bpstat_vec[i]) {
			bp_count++;
			depth_sum += bpstat_vec[i];
		}

		i++;
	}

	return bp_count ? depth_sum / (float)bp_count : 0;
}

float get_mean_depth(vector<record_t> &bpstat_vec, string &seq, size_t &bp_count)
{
	size_t depth_sum = 0;
	bp_count = 0;

	size_t i = 0;
	size_t vec_sz = seq.length();

	while (i < vec_sz) {
		if ( seq[i] != 'N' && seq[i] != 'n' && bpstat_vec[i] != ((1U << (sizeof(record_t) << 3)) - 1)) {
			bp_count++;
			depth_sum += bpstat_vec[i];
		}

		if ( seq[i] == 'N' || seq[i] == 'n') bpstat_vec[i] = ((1U << (sizeof(record_t) << 3)) - 1);
		i++;
	}

	cout << "in the get_mean_depth : " <<  depth_sum << '\t' << bp_count << endl;
	return bp_count ? (depth_sum / (float)bp_count) : 0;
}




class calc_cnv_t
{
	private:
		//vector<string> chr_vec;
		//vector<string> seq_vec;
		//map<string, vector<record_t> > &bpstat_map;

		//int read_chr(ifstream &ifs, map<string, vector<record_t> > &bpstat_map, string &chr, string &seq)

		int read_chr(const char *ref_file, map<string, string> &chr_map);
		int read_chr(char *ref_file,  vector<string> &chr_vec, vector<string> &seq_vec);
		//int read_chr(char *ref_file, vector<string> &chr_vec, vector<string> &seq_vec);
		int depthsingle_process(const char*, const char*);
		int depthbin_process(const char *file_name, const char *ref_file);
		int soap_process();

		void write_cnv(vector<list<bkp_t> > &bkp_list);

	public:
		calc_cnv_t(){}
		int run_calc_cnv();
		void write_depth_distr();
};

class eval_t_cnv
{
	private:
		vector<rc_bkp_t> &rc_bkp_vec;
		list<bkp_t> bkp_list;

		int read_rc(char *file, vector<rc_bkp_t> &rc_bkp_vec);

		int algo_eval(vector<rc_bkp_t> &rc_bkp_vec, list<bkp_t> &bkp_list, float mean_depth);

	public:

		void run_eval();
};


int write_bkp_list(char *list_file, list<bkp_t> &bkp_list, float mean_depth)
{
	ofstream ofs(list_file, ofstream::out);

	if (!ofs.good()) {
		cerr << "can not open the breakpoint file :" << list_file << endl;
		exit(1);
	}

	ofs << mean_depth << endl;
	for (list<bkp_t>::iterator iter = bkp_list.begin(); iter != bkp_list.end(); iter++) {
		ofs << iter->pos << '\t' << iter->win << '\t' << iter->depth << '\t' << iter->pval << endl;
	}

	return 0;
}

int read_bkp_list(char *list_file, list<bkp_t> &bkp_list, float &mean_depth)
{
	igzstream ifs(list_file, ifstream::in);
	if (!ifs.good()) {
		cerr << "can not open the breakpoint file :" << list_file << endl;
		exit(1);
	}

	ifs >> mean_depth;
	while (!ifs.eof()) {
		bkp_t tmp_bkp;
		ifs >> tmp_bkp.pos >> tmp_bkp.win >> tmp_bkp.depth >> tmp_bkp.pval;
		bkp_list.push_back(tmp_bkp);
	}

	return 0;
}




static char g_soap_file[1024] = "";
static char g_chrinfo_file[1024] = "";
static char g_ref_file[1024] = "";
static char g_rc_file[1024] = "";
static char g_bkp_list_file[1024] = "";
static char g_result_file[1024] = "./cnv-result.list";
static char g_list_outfile[1024] = "";
static char g_depth_file[1024] = "./depth-distrib.res";
static char g_depthbin_file[1024] = "";
static char g_depthsingle_file[1024] = "";

static map<string, vector<record_t> > bpstat_map;
static vector<string> file_list;
static pthread_mutex_t stat_mutex_CNV;
static pthread_mutex_t io_mutex;
static pthread_mutex_t cnt_mutex;
static size_t ncpu_cnv = 1;
vector<pthread_t> tid_vec;
vector<string> chr_vec;
vector<string> seq_vec;
vector<float>  mean_depth_vec;
vector<list<bkp_t> > bkp_list_vec;


static double genome_depth_sum = 0;
static size_t genome_bp_sum = 0;
static size_t cnv_found_cnt = 0;
static size_t dropped_cnt = 0;

static int min_cnv = 500;
static size_t min_merge_win = 2000;

static float p_cutoff = 0.4;
static float max_cutoff = 0.6;
static bool bmerge_zero = false;
static bool bglobal = false;
static float mean_depth_specified = 0;
const float NERELY_ZERO = 0.00001;
static bool g_isN_masked = false;








void print_usage_cnv()
{
	cout << ""
		"Program:SOAPcnv\n"
		"Author:  BGI shenzhen\n"
		"Version: 1.08\n"
		"Contact: licai@genomics.org.cn\n"
		"\n"
		"Usage:  SOAPcnv [options]\n"
		"    -f      <str>   file name of the reference file(required)\n"
		"    -s      <str>   file name of .soap/.single [gz] list\n"
		"    -D      <str>   file name of the depth file generated by soap.coverage\n"
		"    -B      <str>   file name of the binary depth file generated by soap.coverage\n"
		"    -p      <float> initial minimum probability to merge the adjacent breakpoint[0.4]\n"
		"    -P      <float> final minimum probability to merge the adjacent breakpoint[0.6]\n"
		"    -i      <str>   file name of the reference's chromosome information\n"
		"    -o      <str>   file name of CNV-calling result[./cnv-result.list]\n"
		"    -m      <int>   minimum CNV length[2000]\n"
		"    -u      <int>   number of CPUs to use[1]\n"
		"    -M              set for the masked depth file\n"
		"    -z              set for merging 0-depth windows\n"
		"    -g              call CNV with the mean depth of the whole genome, default with the mean depth of chromosomes\n"
		"    -e      <float> specify the mean depth of the whole genome, working with '-g' option\n"
		"    -d      <str>   specify the output file for depth information[./depth-distrib.res]\n"
		"    options for testing:\n"
		"    -r      <str>   file name of record file\n"
		"    -w      <str>   file to save the initial breakpoints\n"
		"    -l      <str>   file to read the initial breakpoints\n\n"
    	"    Author:licai@genomics.cn\tCode Main licai&hewm@genomics.cn\n" ;

	return ;
}

int parse_cmd_cnv(int argc, char **argv)
{
	if (argc == 1) {print_usage_cnv();exit(1);}

	int err_flag = 0;

	for(int i = 1; i < argc || err_flag; i++)
	{
		if(argv[i][0] != '-' && strlen(argv[i]) != 2){cerr << "command option error! please check." << endl;exit(1);}
		switch (argv[i][1])
		{
			case 's':
				{
					if(i + 1 == argc){cerr << "lack argument for '-s'" <<endl;err_flag = 1; break;}
					memset(g_soap_file, 0, sizeof(g_soap_file));
					memcpy(g_soap_file, argv[++i], sizeof(g_soap_file) - 1);
					break;
				}
			case 'i':
				{
					if(i + 1 == argc)cerr<< "lack argument for '-i'" << endl;
					memset(g_chrinfo_file, 0, sizeof(g_chrinfo_file));
					memcpy(g_chrinfo_file, argv[++i], sizeof(g_chrinfo_file) - 1);
					break;
				}
			case 'p':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-p'" <<endl;err_flag = 1; break;}
					p_cutoff = atof(argv[++i]);
					if(p_cutoff <= 0 ){cerr << "the '-p' argument less than 0" << endl;err_flag = 1; break;}
					break;
				}
			case 'P':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-p'" <<endl;err_flag = 1; break;}
					max_cutoff = atof(argv[++i]);
					if(max_cutoff <= 0 ){cerr << "the '-p' argument less than 0" << endl;err_flag = 1; break;}
					break;
				}	
			case 'f':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-f'" <<endl;err_flag = 1; break;}
					memset(g_ref_file, 0, sizeof(g_ref_file));
					memcpy(g_ref_file, argv[++i],sizeof(g_ref_file) - 1);
					break;
				}
			case 'o':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-o'" <<endl;err_flag = 1; break;}
					memset(g_result_file, 0, sizeof(g_result_file));
					memcpy(g_result_file, argv[++i],sizeof(g_result_file) - 1);
					break;
				}
			case 'B':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-B'" <<endl;err_flag = 1; break;}
					memset(g_depthbin_file, 0, sizeof(g_depthbin_file));
					memcpy(g_depthbin_file, argv[++i],sizeof(g_depthbin_file) - 1);
					break;
				}
			case 'D':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-D'" <<endl;err_flag = 1; break;}
					memset(g_depthsingle_file, 0, sizeof(g_depthsingle_file));
					memcpy(g_depthsingle_file, argv[++i],sizeof(g_depthsingle_file) - 1);
					break;
				}

			case 'm':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-m'" <<endl;err_flag = 1; break;}
					min_cnv = atoi(argv[++i]);
					if(min_cnv <= 0 ){cout << "the '-m' argument less than 0" << endl;err_flag = 1; break;}
					break;
				}
			case 'u':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-u'" <<endl;err_flag = 1; break;}
					ncpu_cnv = (size_t)atoi(argv[++i]);
					break;
				}
			case 'z':
				{
					bmerge_zero = true;
					break;
				}
			case 'M':
				{
					g_isN_masked = true;
					break;
				}

			case 'g':
				{
					bglobal = true;
					break;
				}
			case 'd':
				{
					if(i + 1 == argc){cerr << "lack argument for '-d'" <<endl;err_flag = 1; break;}
					memset(g_depth_file, 0, sizeof(g_depth_file));
					memcpy(g_depth_file, argv[++i], sizeof(g_depth_file) - 1);
					break;
				}
			case 'e':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-e'" <<endl;err_flag = 1; break;}
					mean_depth_specified = atof(argv[++i]);
					if(mean_depth_specified <= 0 ){cerr << "the '-e' argument less than 0" << endl;err_flag = 1; break;}
					break;
				}
			case 'r':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-c'" <<endl;err_flag = 1; break;}
					memset(g_rc_file, 0, sizeof(g_rc_file));
					memcpy(g_rc_file, argv[++i],sizeof(g_rc_file) - 1);
					break;
				}
			case 'l':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-l'" <<endl;err_flag = 1; break;}
					memset(g_bkp_list_file, 0, sizeof(g_bkp_list_file));
					memcpy(g_bkp_list_file, argv[++i],sizeof(g_bkp_list_file) - 1);
					break;
				}
			case 'w':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-w'" <<endl;err_flag = 1; break;}
					memset(g_list_outfile, 0, sizeof(g_list_outfile));
					memcpy(g_list_outfile, argv[++i],sizeof(g_list_outfile) - 1);
					break;
				}

		}
	}

	if (argc == 1 ) {
		err_flag = 1;
	}

	if (err_flag) {
		print_usage_cnv();
		cerr << endl << "command argument error! please check." << endl;
		exit(1);
	}
	cout << "the soap file is : " << g_soap_file << endl;

	return 0;

}


int calc_cnv_thread_t::init_bkp(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list) 
{
	cout << "init bkp..." << endl;
	//cout << " bpstat_vec[0]" << (int)bpstat_vec[0] << endl; 

	size_t i = 1;
	size_t vec_sz = bpstat_vec.size();
	if (vec_sz ==0) return -1;

	bkp_t tmp_bkp;
	tmp_bkp.depth = bpstat_vec[0];
	tmp_bkp.win = 1;
	tmp_bkp.pos = i;

	size_t bkp_cnt = 0;
	list<bkp_t>::iterator iter_curr;
	int flag = 1;

	size_t n_mark = ((1U << (sizeof(record_t) << 3)) - 1);
	while ((++i) < vec_sz) {

		if (bpstat_vec[i] == n_mark || bpstat_vec[i - 1] == n_mark) {

			if (bpstat_vec[i -1] != n_mark) {
				bkp_list.push_back(tmp_bkp);
				bkp_cnt++;
				tmp_bkp.pos = i;
				//tmp_bkp.depth = 0;
				//tmp_bkp.isN = false;
			}

			tmp_bkp.isN = true;
			tmp_bkp.depth = 0;
			tmp_bkp.win = 1;
			if (bpstat_vec[i -1] == n_mark) tmp_bkp.win++;
			//if (i > 1) tmp_bkp.pos = i;
			++i;
			while (i < vec_sz) { if (bpstat_vec[i] != n_mark) break; tmp_bkp.win++; i++;}
			tmp_bkp.depth = 0;
			bkp_list.push_back(tmp_bkp);
			bkp_cnt++;
			if (i == vec_sz) return 0;

			tmp_bkp.pos = i;
			tmp_bkp.win = 1;
			tmp_bkp.isN = false;
			tmp_bkp.depth = bpstat_vec[i];

			continue;
		}

		float curr_depth = bpstat_vec[i];
		if (curr_depth - tmp_bkp.depth < 0.01 && curr_depth - tmp_bkp.depth > -0.01) { tmp_bkp.win++;  continue;}
		else {
			bkp_list.push_back(tmp_bkp);
			bkp_cnt++;
			if (bkp_cnt >= 10 * 1024 * 1024) {
				flag = 0;
				//cout << "merging : " << bkp_list.size() << endl; 
				if (bkp_list.size() <= 10 * 1024 * 1024 + (bkp_cnt - 10 * 1024 * 1024)) iter_curr = bkp_list.begin();
				merge_bkp(iter_curr, bkp_list, p_cutoff);
				bkp_cnt = 0;
				iter_curr = bkp_list.end();
				iter_curr--;
				cout << "iter_curr\t" << iter_curr->depth << '\t' << iter_curr->win << endl;
			}

			tmp_bkp.pos = i;
			tmp_bkp.win = 1;
			tmp_bkp.isN = false;
			tmp_bkp.depth = curr_depth;
			tmp_bkp.pgc = 0;
			///////////////
			float lval = curr_depth > tmp_bkp.depth ? curr_depth : tmp_bkp.depth;
			float rval = curr_depth > tmp_bkp.depth ? tmp_bkp.depth : curr_depth;
			double pval = 0;
			for (int j = 0; j <= (int)(rval * 10 / lval + 0.5); j++ )pval += (float)p_poisson(10.0, j);
			//cout << "pval1: " << pval << endl;
			//boost::math::poisson_distribution<> pdis(10);
			//cout << lval << '\t' << rval << endl;
			//cout << "boost::math::cdf: " << rval * 10 / lval + 0.5 << endl;
			//pval = boost::math::cdf(pdis, (rval * 10 / (lval + 0.01) + 0.5));
			//cout << "pval2: " << pval << endl;

			//////
			pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;
			tmp_bkp.pval = pval;
		}
	}
	bkp_list.push_back(tmp_bkp);

	if (flag) iter_curr = bkp_list.begin();
	merge_bkp(iter_curr, bkp_list, p_cutoff);
	update_pval(bkp_list);

	return 0;
}


void calc_cnv_thread_t::update_pval(list<bkp_t> &bkp_list)
{
	list<bkp_t>::iterator iter = bkp_list.begin();
	list<bkp_t>::iterator iter1, iter2; 

	while (iter != bkp_list.end()) {
		iter1 = iter;
		iter2 = ++iter;

		if (iter2->isN) {iter2->pval = 1; continue;}
		float lval = iter2->depth > iter1->depth ? iter2->depth : iter1->depth;
		float rval = iter2->depth > iter1->depth ? iter1->depth : iter2->depth;

		if (iter2 != bkp_list.end()) {
			float pval = 0;
			for (int j = 0; j <= (int)(rval * 10/ lval + 0.5); j++ ) pval += (float)p_poisson(10.0, j);
			//boost::math::poisson_distribution<> pdis(10);
			//pval = boost::math::cdf(pdis, (int)(rval * 10/ lval + 0.5));
			iter2->pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;
		}
	}

	return;
}


bool calc_cnv_thread_t::merge_check(list<bkp_t>::iterator iter1, list<bkp_t>::iterator iter_curr, float thr, size_t Ncnt)
{

	if (iter1->isN) return true;

	if (!bmerge_zero && ((iter_curr->depth < NERELY_ZERO && iter1->depth > NERELY_ZERO) || (iter_curr->depth > NERELY_ZERO && iter1->depth < NERELY_ZERO))) return false;


	float depth = 0;
	if (iter_curr->win - Ncnt > 0) depth = iter_curr->depth / (iter_curr->win - Ncnt);

	float lval = depth > iter1->depth ? depth : iter1->depth;
	float rval = depth > iter1->depth ? iter1->depth : depth;

	float pval = 0;
	for (int j = 0; j <= (int)(rval * 10 /lval + 0.5); j++ )pval += (float)p_poisson(10, j);
	//boost::math::poisson_distribution<> pdis(10);
	//pval = boost::math::cdf(pdis, (int)(rval * 10 /lval + 0.5));
	pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;

	if (pval > thr) return true;

	return false;
}

int calc_cnv_thread_t::merge_bkp(list<bkp_t>::iterator biter,list<bkp_t> &bkp_list, float p_cutoff)
{
	list<bkp_t>::iterator iter1, iter2, iter_curr;

	iter_curr = biter;
	iter_curr->depth = iter_curr->depth * iter_curr->win;
	iter1 = iter_curr;
	iter2 = ++iter1;
	iter2++;
	size_t curr_Ncnt = 0;

	//cout << "in the merge" << endl;
	for (; iter1 != bkp_list.end() && iter2 != bkp_list.end(); ) {
		if (!merge_check(iter1, iter_curr, p_cutoff, curr_Ncnt)) {
			if (iter_curr->win - curr_Ncnt > 0) iter_curr->depth /= (iter_curr->win - curr_Ncnt);
			else iter_curr->depth = 0;

			if (iter_curr->win < curr_Ncnt) {cerr << iter_curr->win << '\t' << curr_Ncnt << endl; exit(1);}
			curr_Ncnt = 0;
			iter_curr = iter1;
			iter_curr->depth = iter_curr->depth * iter_curr->win;
			if (iter1->isN) curr_Ncnt += iter1->win;

			iter1++;
			iter2++;

			if (!merge_check(iter1, iter_curr, p_cutoff, curr_Ncnt) && iter1->win > min_merge_win && iter1 != bkp_list.end() && iter2 != bkp_list.end()) {
				if (iter_curr->win - curr_Ncnt > 0) iter_curr->depth /= (iter_curr->win - curr_Ncnt);
				else iter_curr->depth = 0;
				curr_Ncnt = 0;
				iter_curr = iter1;
				iter_curr->depth = iter_curr->depth * iter_curr->win;
				if (iter1->isN) curr_Ncnt += iter1->win;

				iter1++;
				iter2++;
				while (!merge_check(iter1, iter_curr, p_cutoff, curr_Ncnt) && iter1->win > min_merge_win && iter1 != bkp_list.end() && iter2 != bkp_list.end()) {
					iter_curr->depth /= iter_curr->win;
					iter_curr = iter1;
					curr_Ncnt = 0;
					iter_curr->depth = iter_curr->depth * iter_curr->win;

					iter1++;
					iter2++;
				}
			}

			while (iter1->pval < p_cutoff  && iter1->win < min_merge_win && iter1 != bkp_list.end() && iter2 != bkp_list.end()
					&& !iter1->isN && !iter_curr->isN) {
				iter_curr->depth += iter1->depth * iter1->win;
				iter_curr->win += iter1->win;
				if (iter1->isN) curr_Ncnt += iter1->win;

				bkp_list.erase(iter1);	
				iter1 = iter2;
				iter2++;
			}

			continue ;
		}

		iter_curr->depth += iter1->depth * iter1->win;
		iter_curr->win += iter1->win;
		if (iter1->isN) curr_Ncnt += iter1->win;

		bkp_list.erase(iter1);
		iter1 = iter2;
		iter2++;
	}

	iter_curr->depth /= (iter_curr->win - curr_Ncnt);	

	return 0;
}

//get the statistical information of every file
int stat_thread_t::soap_file_stat(const char *file_name, map<string, vector<record_t> > &bpstat_map)
{
	igzstream  ifs ( file_name, ifstream::in );
	if (!ifs)
	{
		cerr << "open soap file error: " << file_name << endl;
		exit(1);
	}

	//cout << "bpstat_map size: " << bpstat_map.size() << endl;

	int i = 0;
	while (!ifs.eof())
	{
		i++;
		soap_t_cnv soapvar1;
		if (soapvar1.parse_line(ifs) < 0) 
		{
			dropped_cnt++;
			continue;
		}

		pthread_mutex_lock (&stat_mutex_CNV);
		soapvar1.hits_stat(bpstat_map);
		pthread_mutex_unlock(&stat_mutex_CNV);

	}

	ifs.close();
	return 0;
}

float get_mean_depth(vector<record_t> &bpstat_vec, size_t &bp_count)
{
	size_t depth_sum = 0;
	bp_count = 0;

	for (size_t i = 0; i < bpstat_vec.size(); ++i) {
		if (  bpstat_vec[i] != (unsigned short)(-1)) {
			bp_count++;
			depth_sum += bpstat_vec[i];
		}
	}

	cout << "in the get_mean_depth : " <<  depth_sum << '\t' << bp_count << endl;
	return bp_count ? (depth_sum / (float)bp_count) : 0;
}



void read_depth(const char *depth_file, map< string, vector<unsigned short> > &depth_map)
{
	igzstream ifs(depth_file, ifstream::in);
	if (!ifs.good()) {
		cerr << "Can not open the depth file: " << depth_file << endl;
		exit(1);
	}

	string line;
	getline(ifs, line);

	string curr_chr = line.substr(1);

	vector<unsigned short> &depth_vec = depth_map[curr_chr];

	while (!ifs.eof()) {
		for (size_t i = 0; i < depth_vec.size(); ++i) {
			ifs >> depth_vec[i];

		}

		getline(ifs, line);
		while (line.find(">") == line.npos && !ifs.eof()) getline(ifs, line);
		if (ifs.eof()) break;

		curr_chr = line.substr(1);
		depth_vec =  depth_map[curr_chr];
	}

	ifs.close();

	return ;
}

int calc_cnv_t::read_chr(const char *ref_file, map<string, string> &chr_map) 
{
	igzstream ifs (ref_file, ifstream::in);
	if (!ifs) {
		cerr << "open file error: " << ref_file << endl;
		exit(1);
	}

	string tmpstrA;
	getline(ifs, tmpstrA,'>');
	while (!ifs.eof())
	{
		string tmpstr;
		getline(ifs, tmpstr,'\n');

		istringstream iss(tmpstr.substr(tmpstr.find(">") + 1), istringstream::in);
		string chr;
		iss >> chr;
		chr_map[chr] = string();
		string &seq = chr_map[chr];

		size_t curr_chr_pos = ifs.tellg();
		size_t chr_bp_count = 0;

		getline(ifs, tmpstr,'>');

		for (size_t i = 0; i < tmpstr.size(); i++) 			
		{
			if (tmpstr[i]!='\n')
			{
				chr_bp_count++;
			}
		}


		seq.resize(chr_bp_count, 0);
		chr_bp_count = 0;

		for (size_t i = 0; i < tmpstr.size(); i++) 			
		{
			if (tmpstr[i]!='\n')
			{
				seq[chr_bp_count] = tmpstr[i];
				chr_bp_count++;
			}
		}

	}

	ifs.close();
	return 0;
}






int calc_cnv_t::depthsingle_process(const char *depthsingle_file, const char *ref_file)
{

	map<string, long> chr_count;
	base_count(ref_file, chr_count);

	//read_chr(ref_file, chr_vec, seq_vec);
	map<string, string> chr_map;

	//if (!g_isN_masked) {
	//	if (strlen(ref_file) == 0) {
	//		cerr << "Error: Need the reference file for masking information!" << endl;
	//		exit(1);
	//	}
	read_chr(ref_file, chr_map);
	//}

	mean_depth_vec.resize(chr_map.size(), 0);
	chr_vec.resize(chr_map.size(), string());
	bkp_list_vec.resize(chr_map.size());


	igzstream ifs (depthsingle_file, ifstream::in );
	if (!ifs) {
		cerr << "open file error: " << depthsingle_file << endl;
		exit(1);
	}

	string line;
	getline(ifs, line);
	while (line.find(">") == line.npos && !ifs.eof()) getline(ifs, line);
	if (ifs.eof()) {
		cerr << "Warning: There isn't any chromosome in the  reference file" << endl;
		ifs.close();
		return -1;
	}
	string curr_chr = line.substr(1);

	size_t chr_cnt = 0;
	while (!ifs.eof()) {
		size_t curr_chr_len = chr_count[curr_chr];

		cout << "curr_chr: " << curr_chr << endl;
		cout << "curr_chr_len: " << curr_chr_len << endl;

		vector<record_t> bpstat_vec(curr_chr_len, 0);    

		//exit(1);

		for (size_t i = 0; i < bpstat_vec.size() && !ifs.eof(); ++i) {
			ifs >> bpstat_vec[i];
			//cout << ifs.tellg() << endl;
		}
		//exit(1);
		if (ifs.fail() && !ifs.eof()) {
			cerr << "Warning: the size of " << curr_chr << " in the depth file is not consistent with that in the reference file" << endl;              
			ifs.clear();
		}
		//////////////
		size_t notN_cnt = 0;
		float mean_depth = 0;

		if (g_isN_masked) {
			mean_depth = get_mean_depth(bpstat_vec, notN_cnt);
		}
		else {
			string &seq = chr_map[curr_chr];
			mean_depth = get_mean_depth(bpstat_vec, seq, notN_cnt);   
		}
		genome_depth_sum += notN_cnt * mean_depth;
		genome_bp_sum += notN_cnt;
		mean_depth_vec[chr_cnt] = mean_depth;

		list<bkp_t> bkp_list;

		calc_cnv_thread_t calc_cnv_thread_var;
		calc_cnv_thread_var.merge_loop(bpstat_vec, bkp_list);
		calc_cnv_thread_var.calc_fval(bpstat_vec, bkp_list, notN_cnt);

		//calc_cnv_t::write_cnv(bkp_list, ostream & os, float mean_depth)

		cout << "chr_cnt: " << chr_cnt << '\t' << chr_vec.size() << endl;
		chr_vec[chr_cnt] = curr_chr;
		bkp_list_vec[chr_cnt].assign(bkp_list.begin(), bkp_list.end());
		chr_cnt++;

		//////////////
		//line.clear();
		getline(ifs, line);
		//cout << "line1: " << line << endl;
		//int x;

		while (line.find(">") == line.npos && !ifs.eof()) {cout << "line2: " << line << '\t' << ifs.tellg() << endl; getline(ifs, line);} //ifs >> line >> x; }
		if (ifs.eof()) break;
		cout << "line: " << line << endl;

		curr_chr = line.substr(1);
		//depth_vec =  depth_map[curr_chr];
}

ifs.close();

return 0;
}

int calc_cnv_t::depthbin_process(const char *file_name, const char *ref_file)
{

	igzstream ifs ( file_name, ifstream::in | ifstream::binary);
	if (!ifs) {
		cerr << "open soap file error: " << file_name << endl;
		exit(1);
	}

	map<string, string> chr_map;
	if (!g_isN_masked) {
		if (strlen(ref_file) == 0) {
			cerr << "Error: Need the reference file for masking information!" << endl;
			exit(1);
		}
		read_chr(ref_file, chr_map);
	}
	//map<string, list<bkp_t> > bkp_list_map;
	//bkp_list_vec[i].assign(bkp_list.begin(), bkp_list.end());
	long chr_cnt = 0;
	long str_sz = 0;
	char curr_chr[256] = {0};
	long curr_chr_len = 0;
	ifs.read((char *)&chr_cnt, sizeof(long));

	bkp_list_vec.resize(chr_cnt, list<bkp_t>());
	mean_depth_vec.resize(chr_cnt, 0);
	chr_vec.resize(chr_cnt, string());

	for (long i = 0; i < chr_cnt; ++i) {

		memset(&curr_chr[0], 0, sizeof(curr_chr));

		ifs.read((char *)&str_sz, sizeof(long));
		ifs.read(&curr_chr[0], str_sz);
		ifs.read((char *)&curr_chr_len, sizeof(long));

		//bpstat_map[string(curr_chr)] = vector<record_t>();
		vector<record_t> bpstat_vec(curr_chr_len, 0);
		//bpstat_vec.resize(curr_chr_len, 0);

		ifs.read((char *)&bpstat_vec[0], curr_chr_len * sizeof(unsigned short));

		size_t notN_cnt = 0;
		float mean_depth = 0;
		//float mean_depth = get_mean_depth(bpstat_vec, notN_cnt);

		if (g_isN_masked) {
			mean_depth = get_mean_depth(bpstat_vec, notN_cnt);
		}
		else {
			string &seq = chr_map[curr_chr];
			mean_depth = get_mean_depth(bpstat_vec, seq, notN_cnt);   
		}

		genome_depth_sum += notN_cnt * mean_depth;
		genome_bp_sum += notN_cnt;
		mean_depth_vec[i] = mean_depth;

		list<bkp_t> bkp_list;

		calc_cnv_thread_t calc_cnv_thread_var;
		calc_cnv_thread_var.merge_loop(bpstat_vec, bkp_list);
		calc_cnv_thread_var.calc_fval(bpstat_vec, bkp_list, notN_cnt);

		//calc_cnv_t::write_cnv(bkp_list, ostream & os, float mean_depth)

		chr_vec[i] = curr_chr;
		bkp_list_vec[i].assign(bkp_list.begin(), bkp_list.end());
		//float mean_depth = 10;
		//ofs << '>' << curr_chr << endl;
	}

	ifs.close();

	return 0;
}


void *stat_thread_t::task()
{
	size_t len = file_list.size() / ncpu_cnv;
	size_t n = index;

	for (map<string, vector<record_t> >::iterator iter = bpstat_map.begin(); iter != bpstat_map.end(); ++iter) {
		cout << iter->first << '\t' << iter->second.size() << endl;
	}

	for (size_t i = n * len; i < (n + 1) * len; i++) {
		cout << "processing file : " << file_list[i].c_str() << endl;
		soap_file_stat(file_list[i].c_str(), bpstat_map);
	}

	if (n == ncpu_cnv -1) {
		for (size_t i = ncpu_cnv * len; i < file_list.size(); i++) {
			cout << "processing file : " << file_list[i].c_str() << endl;
			soap_file_stat(file_list[i].c_str(), bpstat_map);
		}
	}

	return NULL;
}
int stat_t_CNV::read_file_list(vector<string> &file_list, const char *file_list_file)
{
	igzstream ifs(file_list_file, ifstream::in);
	if (!ifs.good()) {
		cerr << "can not open the file: " << file_list_file << endl;
		exit(1);
	}

	while (!ifs.eof()) {
		string str;
		ifs >> str;
		if (str.length() >0) file_list.push_back(str);
	}

	ifs.close();

	return 0;
}

//statistics before evaluation, get information from .soap & .single files 
int stat_t_CNV::run_stat()
{

	//map<string, long> chr_count ;

	//get the chromosome base infomation
	if (strlen(g_chrinfo_file) == 0)base_count(g_ref_file, chr_count);
	else read_chrinfo(g_chrinfo_file, chr_count);

	cout << "reading chr info completed" << endl;
	//memory allocation
	alloc_rc(bpstat_map, chr_count);
	for (map<string, vector<record_t> >::iterator iter = bpstat_map.begin(); iter != bpstat_map.end(); ++iter) {
		cout << iter->first << '\t' << iter->second.size() << endl;
	}
	cout << "resource allocation completed" << endl;

	read_file_list(file_list, g_soap_file);
	if (file_list.size() == 0) {cerr << "no file to stat" << endl;exit(1);}
	else {
		cout << file_list.size() << " files to stat" << endl;
	}

	//tid_vec.resize(ncpu_cnv, 0);
	pthread_mutex_init (&stat_mutex_CNV,NULL);
	vector<size_t> num_vec(ncpu_cnv, 0);
	/*
	   ThreadMgr stat_threads(ncpu_cnv);
	   stat_threads.run(g_soap_file_stat_thread);
	   stat_threads.join();
	   */
	vector<stat_thread_t> thread_vec(ncpu_cnv, stat_thread_t(bpstat_map, file_list));

	for (size_t i = 0; i < thread_vec.size(); i++) {
		//thread_vec[i].alloc_rc();
		thread_vec[i].set_index(i);
		thread_vec[i].run();
	}

	for (size_t i = 0; i < thread_vec.size(); i++) {
		thread_vec[i].join(NULL);
	}

	cout << "statistics of soap files completed" << endl;
	cout << "bpstat_map size3 " << bpstat_map.size() << endl;
	for (map<string, vector<record_t> >::iterator iter = bpstat_map.begin(); iter != bpstat_map.end(); ++iter) {
		cout << iter->first << '\t' << iter->second.size() << endl;
	}

	return 0;
}
int calc_cnv_t::soap_process()
{

	stat_t_CNV stat_var;    
	stat_var.run_stat();
	read_chr(g_ref_file, chr_vec, seq_vec);
	bkp_list_vec.resize(chr_vec.size(), list<bkp_t>());
	mean_depth_vec.resize(chr_vec.size(), 0);

	cout << "bpstat_map size : " << bpstat_map.size() << " chr_vec size : " << chr_vec.size() << endl;
	for (size_t i = 0; i < chr_vec.size(); i++) {
		cout << "chr : " << chr_vec[i] << endl;
	}

	tid_vec.resize(ncpu_cnv, 0);
	pthread_mutex_init (&io_mutex,NULL);
	pthread_mutex_init (&cnt_mutex,NULL);
	/*
	   ofstream cnv_ofs1(g_result_file, ofstream::trunc);//discard old content
	   if (!cnv_ofs1.good()) {
	   cerr << "can not open file " << g_result_file << endl;
	   exit(1);
	   }
	   cnv_ofs1.close();	
	   */
	vector<calc_cnv_thread_t> thread_vec(ncpu_cnv, calc_cnv_thread_t());

	for (size_t i = 0; i < thread_vec.size(); i++) {
		//thread_vec[i].alloc_rc();
		thread_vec[i].set_index(i);
		thread_vec[i].run();
	}

	for (size_t i = 0; i < thread_vec.size(); i++) {
		thread_vec[i].join(NULL);
	}

	return 0;
}

int calc_cnv_t::run_calc_cnv() 
{

	chr_vec.clear();
	seq_vec.clear();
	bkp_list_vec.clear();
	////////////
	if (strlen(g_depthbin_file) > 0) {
		depthbin_process(g_depthbin_file, g_ref_file);        
	}
	else if (strlen(g_depthsingle_file) > 0) {
		depthsingle_process(g_depthsingle_file, g_ref_file);
	}
	else {
		soap_process();
	}
	///////////

	write_cnv(bkp_list_vec);

	return 0;
}
/*
   void  calc_cnv_thread_t::calc_fval(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list, size_t notN_cnt)
   {
////////10.27
vector<float> count_vec(65535, 0);

for (size_t j = 0; j < bpstat_vec.size(); j++) {
if (bpstat_vec[j] < 65535) count_vec[bpstat_vec[j]]++;
//else count_vec[254]++;
}
//count_vec[0] =  count_vec[0] - (bpstat.size() - notN_cnt);

for (size_t j = 0; j < count_vec.size(); j++) {
count_vec[j] /= (float)notN_cnt;
if (j > 0) count_vec[j] += count_vec[j - 1];
cout << j << '\t' << count_vec[j] << endl;
}

for (list<bkp_t>::iterator iter = bkp_list.begin(); iter != bkp_list.end(); iter++) {
//iter->fval = count_vec[size_t(iter->depth + 0.5)];
if (iter->depth < 254) iter->fval = count_vec[size_t(iter->depth)] + (count_vec[size_t(iter->depth) + 1] - count_vec[size_t(iter->depth)]) * (iter->depth - size_t(iter->depth));
else {
iter->fval = count_vec[size_t(iter->depth)];
}
if (iter->fval > 0.5) iter->fval = 1 - iter->fval;
iter->fval *= 2;
}

////////10.27
return;
}
*/

void calc_cnv_thread_t::merge_loop(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list)
{
	init_bkp(bpstat_vec, bkp_list);

	if (bkp_list.size() < 2) return;

	cout << "the size before merging: " << bkp_list.size() << endl;

	//if (strlen(g_list_outfile) > 0) write_bkp_list(g_list_outfile, bkp_list, mean_depth);

	size_t ncycle = 15;
	float p_cutoff1 = p_cutoff;

	for (size_t j = 0; j < ncycle ; j++) {
		size_t above_cnt = 0;
		for (list<bkp_t>::iterator iter1 = bkp_list.begin(); iter1 != bkp_list.end(); ++iter1) {
			//if (i > 10)cout << "merging "<< i + 1 << ": "<< iter1->pos << '\t' << iter1->win << '\t' << iter1->depth << '\t' << iter1->pgc << '\t' << iter1->pval << endl;	
			if (iter1->pval > p_cutoff1) above_cnt++;

		}

		float above_rate = above_cnt / (float) bkp_list.size();
		//p_cutoff1 += 0.08 * above_rate;
		p_cutoff1 = p_cutoff + (max_cutoff - p_cutoff) * exp( 0 - above_rate);
		cout << "above rate : " << above_cnt / (float) bkp_list.size() << '\t' << above_cnt << '\t' << p_cutoff1 << endl;
		merge_bkp(bkp_list.begin(), bkp_list, p_cutoff1);
		cout << "the size after merging: " << bkp_list.size() << endl;
		update_pval(bkp_list);
	}
}

void calc_cnv_thread_t::calc_fval(vector<record_t> &bpstat_vec, list<bkp_t> &bkp_list, size_t &notN_cnt)
{
	size_t count_sz = (1U << (sizeof(record_t) << 3)) - 1;
	vector<float> count_vec(count_sz, 0);

	for (size_t j = 0; j < bpstat_vec.size(); j++) {
		if (bpstat_vec[j] < count_sz) count_vec[bpstat_vec[j]]++;
		else count_vec[count_sz - 1]++;
	}
	//count_vec[0] =  count_vec[0] - (bpstat_vec.size() - notN_cnt);

	for (size_t j = 0; j < count_vec.size(); j++) {
		count_vec[j] /= (float)notN_cnt;
		if (j > 0) count_vec[j] += count_vec[j - 1];
		//cout << j << '\t' << count_vec[j] << endl;
	}

	for (list<bkp_t>::iterator iter = bkp_list.begin(); iter != bkp_list.end(); iter++) {
		//iter->fval = count_vec[size_t(iter->depth + 0.5)];
		if (iter->depth < (1U << (sizeof(record_t) << 3)) - 2) iter->fval = count_vec[size_t(iter->depth)] + (count_vec[size_t(iter->depth) + 1] - count_vec[size_t(iter->depth)]) * (iter->depth - size_t(iter->depth));
		else {
			iter->fval = count_vec[size_t(iter->depth)];
		}
		if (iter->fval > 0.5) iter->fval = 1 - iter->fval;
		iter->fval *= 2;
	}


}
void *calc_cnv_thread_t::task()
{
	size_t len = chr_vec.size() / ncpu_cnv;
	size_t n = index;
	size_t loop = (n + 1) * len;
	if (n == ncpu_cnv -1) loop = chr_vec.size();

	cout << "in the cnv_call_thread ..." << endl;

	cout << "bpstat_map : " << bpstat_map.size() << endl;
	cout << "chr_vec : " << chr_vec.size() << endl;
	cout << "seq_vec : " << seq_vec.size() << endl;

	for (size_t i = n * len; i < loop; i++) {
		string chr(chr_vec[i]);

		cout << "handling the chromosome : " << chr << endl;

		pthread_mutex_lock (&stat_mutex_CNV);
		map<string, vector<record_t> >::iterator it1 = bpstat_map.find(chr);
		if (it1 == bpstat_map.end()) continue;
		vector<record_t> &bpstat_vec = it1->second;
		string &seq = seq_vec[i];
		pthread_mutex_unlock (&stat_mutex_CNV);

		size_t notN_cnt = 0;
		float mean_depth = get_mean_depth(bpstat_vec, seq, notN_cnt);

		pthread_mutex_lock (&cnt_mutex);
		genome_depth_sum += notN_cnt * mean_depth;
		genome_bp_sum += notN_cnt;
		mean_depth_vec[i] = mean_depth;
		pthread_mutex_unlock (&cnt_mutex);

		list<bkp_t> bkp_list;
		if (bpstat_vec.size() < 2000) {
			bkp_t tmp_bkp;
			tmp_bkp.depth = mean_depth;
			tmp_bkp.win = notN_cnt;

			cout << tmp_bkp.depth << '\t' << tmp_bkp.win << endl; 

			bkp_list.push_back(tmp_bkp);
			pthread_mutex_lock (&io_mutex);
			bkp_list_vec[i].assign(bkp_list.begin(), bkp_list.end());
			pthread_mutex_unlock(&io_mutex);

			continue;
		}

		merge_loop(bpstat_vec, bkp_list);

		calc_fval(bpstat_vec, bkp_list, notN_cnt);
		/*
		   if (strlen(g_rc_file) > 0) {
		   vector<rc_bkp_t> rc_bkp_vec;
		   read_rc(g_rc_file, rc_bkp_vec); 
		   algo_eval(rc_bkp_vec, bkp_list, mean_depth);
		   }
		   */
		//pthread_mutex_lock()
		pthread_mutex_lock (&io_mutex);
		bkp_list_vec[i].assign(bkp_list.begin(), bkp_list.end());
		pthread_mutex_unlock (&io_mutex);

		seq.clear();
	}

	return NULL;
}

int Var_SoapCNV_main(int argc, char *argv[])
//programme entry
//int main(int argc, char **argv)
{
	parse_cmd_cnv(argc, argv);

	clock_t start_time = clock();
	clock_t end_time;


	//cout << "bpstat_map size2 : " << bpstat_map.size() << endl;

	calc_cnv_t calc_cnv_var;
	calc_cnv_var.run_calc_cnv();


	end_time = clock();
	cout << "time elapsed : " << (end_time - start_time) / (float)CLOCKS_PER_SEC << endl;

	cout << "completed!!" << endl;
	return 0;
}

void calc_cnv_t::write_depth_distr()
{
	size_t count_sz = ((1U << (sizeof(record_t) << 3)) - 1);
	vector<size_t> count_vec(count_sz, 0);

	for (map<string, vector<record_t> >::iterator iter = bpstat_map.begin(); iter != bpstat_map.end(); iter++) {
		for (vector<record_t>::iterator iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++) {
			if (*iter2 < count_sz) count_vec[*iter2]++;
			else count_vec[count_sz - 1]++;
		}
	}

	ofstream ofs(g_depth_file, ofstream::out);
	if (!ofs.good()) {
		cerr << "can not open the record file" << endl;
		exit(1);
	}

	for (size_t i = 0; i< count_vec.size(); i++){
		ofs << i << '\t' << count_vec[i] << endl;
	}

	ofs.close();

	return;
}
//algorithm evaluation
int eval_t_cnv::read_rc(char *file, vector<rc_bkp_t> &rc_bkp_vec) 
{
	igzstream ifs(file, ifstream::in);
	if (!ifs.good()) {
		cerr << "can not open the record file" << endl;
		exit(1);
	}

	while(!ifs.eof()) {
		rc_bkp_t tmp_bkp;
		ifs >> tmp_bkp.pos >> tmp_bkp.len >> tmp_bkp.type;

		rc_bkp_vec.push_back(tmp_bkp);
	}

	ifs.close();

	return 0;
}

int eval_t_cnv::algo_eval(vector<rc_bkp_t> &rc_bkp_vec, list<bkp_t> &bkp_list, float mean_depth)
{
	vector<rc_bkp_t>::iterator iter_rc = rc_bkp_vec.begin();

	list<bkp_t>::iterator iter_fd = bkp_list.begin();

	size_t cnv_cnt = 0;
	size_t err_cnt = 0;
	size_t sig_cnt = 0;
	float bias = 0;
	while (iter_rc != rc_bkp_vec.end() && iter_fd != bkp_list.end()) {
		while (iter_fd != bkp_list.end() &&  iter_fd->pos < iter_rc->pos) {
			float pval = 0;
			for (int j = 0; j <= (int)(iter_fd->depth * 10 / mean_depth + 0.5); j++ )pval += (float)p_poisson(10.0, j);
			//boost::math::poisson_distribution<> pdis(10);
			//pval = boost::math::cdf(pdis, (int)(iter_fd->depth * 10 / mean_depth + 0.5));
			pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;
			if (pval < 0.1 && iter_fd->win > 5000) err_cnt++;

			//cout << iter_fd->pos << '\t' << bkp_list.size() << endl;
			if (++iter_fd == bkp_list.end()) break;
		}

		list<bkp_t>::iterator iter_prev = --iter_fd;
		iter_fd++;


		cout << endl << iter_rc->pos << '\t' << iter_rc->len << '\t' << iter_rc->type << endl;
		if (iter_rc->pos - iter_prev->pos < iter_fd->pos - iter_rc->pos) {

			if (iter_rc->pos - iter_prev->pos < 5000) {
				//if (iter_rc->len == 5000) 
				float pval = 0;
				for (int j = 0; j <= (int)(iter_prev->depth * 10 / mean_depth + 0.5) ; j++ )pval += (float)p_poisson(10.0, j);
				//boost::math::poisson_distribution<> pdis(10);
				//pval = boost::math::cdf(pdis, (int)(iter_prev->depth * 10 / mean_depth + 0.5));
				pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;
				if (pval < 0.4) cnv_cnt++;
				err_cnt--;

				if (pval < 0.4) sig_cnt++;
				bias += abs((float)(iter_rc->pos - iter_prev->pos)) + abs((float)(iter_rc->pos + iter_rc->len - iter_prev->pos - iter_prev->win));

				cout << iter_prev->pos << '\t' << iter_prev->depth << '\t' << iter_prev->win << '\t' << iter_prev->pval << endl;
			}
		}
		else {
			if (iter_fd->pos - iter_rc->pos < 5000){
				float pval = 0;
				for (int j = 0; j <= (int)(iter_fd->depth * 10 / mean_depth + 0.5); j++ )pval += (float)p_poisson(10.0, j);
				//boost::math::poisson_distribution<> pdis(10);
				//pval = boost::math::cdf(pdis, (int)(iter_fd->depth * 10 / mean_depth + 0.5));
				pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;
				if (pval < 0.4) cnv_cnt++;

				if (pval < 0.4) sig_cnt++;
				bias += abs((float)(iter_rc->pos - iter_fd->pos)) + abs((float)(iter_rc->pos + iter_rc->len - iter_fd->pos - iter_fd->win));

				cout << iter_fd->pos << '\t' << iter_fd->depth << '\t' << iter_fd->win << '\t' << iter_fd->pval << endl;
			}
		}

		iter_rc++;
	}

	size_t tmp_cnt = 0;
	for (list<bkp_t>::iterator iter = bkp_list.begin(); iter != bkp_list.end(); iter++) {
		float pval = 0;
		for (int j = 0; j <= (int)(iter->depth * 10 / mean_depth + 0.5); j++ )pval += (float)p_poisson(10.0, j);
		//boost::math::poisson_distribution<> pdis(10);
		//pval = boost::math::cdf(pdis, iter->depth * 10 / mean_depth + 0.5);
		pval = (pval > 0.5) ? 2 * (1-pval) : 2 * pval;
		if (pval < 0.4) tmp_cnt++;
	}


	cout << "the cnv_cnt : " << cnv_cnt << endl;
	cout << "the sig_cnt : " << sig_cnt << endl;
	cout << "the err_cnt : " << err_cnt << endl;
	cout << "the bias cumulated is :" << bias / cnv_cnt << endl;
	cout << " tmp_cnt : " << tmp_cnt << endl;

	cout << "FP : " << (tmp_cnt - cnv_cnt) * 100 / (float)rc_bkp_vec.size() << endl;
	cout << "FN : " << (rc_bkp_vec.size() - cnv_cnt) * 100 / (float)rc_bkp_vec.size() << endl;
	return 0;
}

void write_cnv(string chr, list<bkp_t> &bkp_list, ostream & os, float mean_depth)
{
	if (mean_depth < NERELY_ZERO) return;

	//os << "<" << chr << endl;
	os << "#mean depth: " << chr << setprecision(4) << '\t' << mean_depth << endl;

	for (list<bkp_t>::iterator iter = bkp_list.begin(); iter != bkp_list.end(); iter++) {
		os << chr << '\t' << iter->pos << '\t'<< fixed << setprecision(2) << iter->win << '\t' << iter->depth << '\t' << (mean_depth ? (iter->depth / mean_depth) : 0) << '\t' << scientific << setprecision(4) << iter->fval << '\t' << iter->isN << endl;

		//float copy_num = iter->depth / mean_depth;
		//if (copy_num > 1.5 ) {
		//    cnv_found_cnt += size_t(copy_num + 0.5 - 1) * iter->win; 
		//}

	}

	return;
}

void calc_cnv_t::write_cnv(vector<list<bkp_t> > &bkp_list_vec)
{
	ofstream cnv_ofs(g_result_file, ofstream::out);
	if (!cnv_ofs.good()) {
		cerr << "can not open file " << g_result_file << endl;
		exit(1);
	}

	float global_mean_depth = genome_depth_sum / genome_bp_sum;
	if (mean_depth_specified > NERELY_ZERO) global_mean_depth = mean_depth_specified;
	cnv_ofs << "genome leval  mean depth : " << global_mean_depth << endl;

	for (size_t i = 0; i < bkp_list_vec.size(); i++) {
		float mean_depth = bglobal ? global_mean_depth : mean_depth_vec[i];
		if (mean_depth < NERELY_ZERO) continue;

		//cnv_ofs << ">" << chr_vec[i] << endl;
		cnv_ofs << "#mean depth: " << chr_vec[i] << '\t' << setprecision(4) <<  mean_depth_vec[i] << endl;

		for (list<bkp_t>::iterator iter = bkp_list_vec[i].begin(); iter != bkp_list_vec[i].end(); iter++) {
			cnv_ofs << chr_vec[i] << '\t' << iter->pos << '\t'<< fixed << setprecision(2) << iter->win << '\t' << iter->depth << '\t' << (mean_depth ? (iter->depth / mean_depth) : 0) << '\t' << scientific  << setprecision(4) << iter->fval << '\t' << iter->isN << endl;
			cnv_ofs.unsetf(ios_base::scientific);
			//cnv_ofs.unsetf(cnv_ofs.flags());

			//float copy_num = iter->depth / mean_depth;
			//if (copy_num > 1.5 ) {
			//    cnv_found_cnt += size_t(copy_num + 0.5 - 1) * iter->win; 
			//}
		}
		//write_cnv(bkp_list_vec[i], cnv_ofs, mean_depth);
	}

	cnv_ofs << "cnv bases found : " << cnv_found_cnt << endl;

	cnv_ofs.close();



	return;
}




int calc_cnv_t::read_chr(char *ref_file, vector<string> &chr_vec, vector<string> &seq_vec)
{
	//ifstream ifs (ref_file, ifstream::in);
	igzstream ifs (ref_file, ifstream::in);
	if (!ifs) {
		cerr << "open soap file error: " << ref_file << endl;
		exit(1);
	}

	string  tmpstrA;
	getline(ifs, tmpstrA,'>');

	while (!ifs.eof()) 
	{
		string tmpstr;
		string chr;
		getline(ifs, tmpstr,'\n');

		istringstream iss(tmpstr.substr(tmpstr.find(">") + 1), istringstream::in);
		//	string chr;
		iss >> chr;
		if (chr.length() > 0 && bpstat_map.find(chr) != bpstat_map.end()) 
		{
			chr_vec.push_back(chr);
			seq_vec.push_back(chr);
		}
		else
		{
			getline(ifs, tmpstr,'>');
			continue;
		}

		size_t len = bpstat_map[chr].size();
		string &seq = seq_vec[seq_vec.size() - 1];
		seq.resize(len, 0);

		size_t chr_bp_count = 0;
		getline(ifs, tmpstr,'>');
		for (size_t i = 0; i < tmpstr.size(); i++) 			
		{
			if (tmpstr[i]!='\n')
			{
				seq[chr_bp_count] = tmpstr[i];
				chr_bp_count++;
			}
		}
	}

	ifs.close();

	return 0;
}





#endif


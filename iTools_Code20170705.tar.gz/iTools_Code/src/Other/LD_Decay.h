#ifndef LDDecay_H_
#define LDDecay_H_
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

int  Gff_LDdecaySNP_help()
{
	cout <<""
		"\n"
		"\tThe newest LDDecay [PopLDdecay] can be dowloaded form This website\n"
		
		"\thttps://github.com/BGI-shenzhen/PopLDdecay\n"
		"\t\n    PopLDdecay    \n\n"
		"\temail: hewm2008@gmail.com / hewm2008@qq.com\n"
		"\tjoin the QQ Group : 125293663\n"

		"\n";

		return 1;
}


int LDdecaySNP_main(int argc, char *argv[])
//int main(int argc, char *argv[])
{
 Gff_LDdecaySNP_help();
}
#endif // LDDecay_H_ //
///////// swimming in the sky and flying in the sea ////////////


#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <math.h>
#include <cstdlib>
#include <algorithm>
#include <stdio.h>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"


using namespace std;


int  print_ColDecay()
{
	cout <<""
		"\n"
		"\tUsage: ColDecay  -crBegin  255,0,0  -crEnd  0,0,255  \n"
		"\n"
		"\t\t-crBegin         <str> In Start Color RGB (255,0,0)\n"
		"\t\t-crEnd           <str> In End Color RGB (0,0,255)\n"
		"\n"
		"\t\t-outFix          <str> OutPut File prefix[outFix]\n"
		"\t\t-cut             <int> Number of Color Gradien[60]\n"
		"\t\t-outGRB                OutPut the Decay Col RGB\n"
		"\t\t-display               Display the Col Decay svg File\n"
		"\n"
		"\t\t-help                  show this help\n" 
		"\n";
	return 1;
}


int parse_ColDecay(int argc, char **argv, ParaClass * Para_IN )
{
	if (argc <=1 ) {print_ColDecay();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "crBegin")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			Para_IN->InStr1=argv[i];
		}
		else if (flag  ==  "crEnd")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			Para_IN->InStr2=argv[i];
		}
		else if (flag  ==  "outFix")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			Para_IN->InStr3=argv[i];
		}
		else if (flag  == "cut"  )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			(Para_IN->InInt1)=atoi(argv[i]);
		}
		else if (flag  == "display"  )
		{
			(Para_IN->TF)=true;
		}
		else if (flag  == "outGRB"  )
		{
			(Para_IN->InUnInt1)=2;
		}
		else if (flag  == "help")
		{
			print_ColDecay();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	return 1 ;
}




hsv rgb2hsv(rgb in)
{
	hsv         out;
	double      min, max, delta;

	min = in.r < in.g ? in.r : in.g;
	min = min  < in.b ? min  : in.b;

	max = in.r > in.g ? in.r : in.g;
	max = max  > in.b ? max  : in.b;

	out.v = max;                                // v
	delta = max - min;
	if (delta < 0.00001)
	{
		out.s = 0;
		out.h = 0; // undefined, maybe nan?
		return out;
	}
	if( max > 0.0 ) { // NOTE: if Max is == 0, this divide would cause a crash
		out.s = (delta / max);                  // s
	} else {


		out.s = 0.0;     // if max is 0, then r = g = b = 0       // s = 0, v is undefined
		out.h = NAN;                            // its now undefined
		return out;
	}
	if( in.r >= max )                           // > is bogus, just keeps compilor happy
		out.h = ( in.g - in.b ) / delta;        // between yellow & magenta
	else
		if( in.g >= max )
			out.h = 2.0 + ( in.b - in.r ) / delta;  // between cyan & yellow
		else
			out.h = 4.0 + ( in.r - in.g ) / delta;  // between magenta & cyan

	out.h *= 60.0;                              // degrees

	if( out.h < 0.0 )
		out.h += 360.0;

	return out;
}


rgb hsv2rgb(hsv in)
{
	double      hh, p, q, t, ff;
	long        i;
	rgb         out;

	if(in.s <= 0.0) {       // < is bogus, just shuts up warnings
		out.r = in.v;
		out.g = in.v;
		out.b = in.v;
		return out;
	}
	hh = in.h;
	if(hh >= 360.0) hh = 0.0;
	hh /= 60.0;
	i = (long)hh;
	ff = hh - i;
	p = in.v * (1.0 - in.s);
	q = in.v * (1.0 - (in.s * ff));
	t = in.v * (1.0 - (in.s * (1.0 - ff)));

	switch(i) {
		case 0:
			out.r = in.v;
			out.g = t;
			out.b = p;
			break;
		case 1:
			out.r = q;
			out.g = in.v;
			out.b = p;
			break;
		case 2:
			out.r = p;
			out.g = in.v;
			out.b = t;
			break;

		case 3:
			out.r = p;
			out.g = q;
			out.b = in.v;
			break;
		case 4:
			out.r = t;
			out.g = p;
			out.b = in.v;
			break;
		case 5:
		default:
			out.r = in.v;
			out.g = p;
			out.b = q;
			break;
	}
	return out;     
}






void LDDecayColor( rgb crBegin, rgb crEnd,   ParaClass * Para_IN  )
{


	string SVGFile=Para_IN->InStr3+".svg";
	int cut=(Para_IN->InInt1)+1;
	ofstream OUT (SVGFile.c_str());
	if(!OUT.good())
	{
		cerr << "open OutFile error: "<<SVGFile<<endl;
		exit(1);
	}

	OUT<<"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"<<endl;
	OUT<<"<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\" \"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">"<<endl;
	OUT<<"<svg height=\"70\" width=\"420\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">"<<endl;

	hsv Start=rgb2hsv(crBegin);
	hsv End=rgb2hsv(crEnd);
	int Outwidth=400/(cut+1);

	if ((Para_IN->InUnInt1)!=2)
	{
		for (int ii=0 ; ii<=cut ; ii++ )
		{
			hsv  Now ;
			Now.h=abs(Start.h+(End.h-Start.h)*ii/cut) ;
			Now.s=abs(Start.s+(End.s-Start.s)*ii/cut) ;
			Now.v=abs(Start.v+(End.v-Start.v)*ii/cut) ;
			rgb  NowRGB=hsv2rgb(Now);
			int XSite=ii*Outwidth+10;
			OUT<<"\t<rect fill=\"rgb("<<int(NowRGB.r)<<","<<int(NowRGB.g)<<","<<int(NowRGB.b)<<")\" width=\""<<Outwidth<<"\" height=\"50\" stroke-width=\"0\" stroke=\"rgb("<<int(NowRGB.r)<<","<<int(NowRGB.g)<<","<<int(NowRGB.b)<<")\" x=\""<<XSite<<"\" y=\"10\" /> "<<endl;
		}	

	}
	else
	{
		string RGBFile=Para_IN->InStr3+".rgb";
		ofstream OUTRGB (RGBFile.c_str());
		if(!OUTRGB.good())
		{
			cerr << "open OutFile error: "<<RGBFile<<endl;
			exit(1);
		}

		for (int ii=0 ; ii<=cut ; ii++ )
		{
			hsv  Now ;
			Now.h=Start.h+(End.h-Start.h)*ii/cut ;
			Now.s=Start.s+(End.s-Start.s)*ii/cut ;
			Now.v=Start.v+(End.v-Start.v)*ii/cut ;
			rgb  NowRGB=hsv2rgb(Now);
			int XSite=ii*Outwidth+10;
			OUT<<"\t<rect fill=\"rgb("<<int(NowRGB.r)<<","<<int(NowRGB.g)<<","<<int(NowRGB.b)<<")\" width=\""<<Outwidth<<"\" height=\"50\" stroke-width=\"0\" stroke=\"rgb("<<int(NowRGB.r)<<","<<int(NowRGB.g)<<","<<int(NowRGB.b)<<")\" x=\""<<XSite<<"\" y=\"10\" /> "<<endl;
			OUTRGB<<"col"<<ii+1<<"\t=\t"<<int(NowRGB.r)<<","<<int(NowRGB.g)<<","<<int(NowRGB.b)<<endl;
		}	


		OUTRGB.close();
	}

	OUT<<"<!--  Love   hewm2008@qq.com   --></svg> "<<endl;
	OUT.close();


	if   (Para_IN->TF)
	{
		string  dislay ="display  "+SVGFile;
		std::system(dislay.c_str()) ;
	}



}



int O_ColDecay_main(int argc, char *argv[])
//int main(int argc, char *argv[])
{
	ParaClass * Para_IN = new ParaClass;
	Para_IN->InInt1=60;
	Para_IN->InStr3="outFix";
	(Para_IN->TF)=false;
	if (parse_ColDecay(argc, argv , Para_IN )==0)
	{
		delete Para_IN ;
		return 1;
	}


	rgb crBegin,crEnd;
	crBegin.r=255; crBegin.g=0; crBegin.b=0;
	crEnd.r=0; crEnd.g=0 ;  crEnd.b=255;

	if (!(Para_IN->InStr1).empty())
	{	
		vector<string> Temp;
		split(Para_IN->InStr1,Temp," \t,");
		crBegin.r=atof(Temp[0].c_str());
		crBegin.g=atof(Temp[1].c_str());
		crBegin.b=atof(Temp[2].c_str());
	}

	if (!(Para_IN->InStr2).empty())
	{	
		vector<string> Temp;
		split(Para_IN->InStr2,Temp," \t,");
		crEnd.r=atof(Temp[0].c_str());
		crEnd.g=atof(Temp[1].c_str());
		crEnd.b=atof(Temp[2].c_str());
	}

	LDDecayColor( crBegin, crEnd,  Para_IN );

	delete Para_IN ;
	return 0;

}

///////// swimming in the sky and flying in the sea ////////////

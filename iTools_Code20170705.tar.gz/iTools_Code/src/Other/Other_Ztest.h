#ifndef Other_Ztest_H_
#define Other_Ztest_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../include/gzstream/gzstream.h"
#include <iomanip>
#include "../ALL/comm.h"
#include "../ALL/Bmath/pnorm.c"
#include "../ALL/DataClass.h"
#include <algorithm>
#include <math.h>

using namespace std;
typedef long long  llong ;

int  print_usage_Z66()
{
	cout <<""
		"\n"
		"\tUsage: Ztest  -InPut <inFile>  -OutPut <out.z> [options]\n"
		"\n"
		"\t\t-InPut     <str> : Input file for Z-test\n"
		"\t\t-OutPut    <str> : OutPut file[add:Z-Score Pvalue Pvalue_sci]\n"
		"\n"
		"\t\t-Row       <int> : The row to count for Z-test [4]\n"
		"\t\t-Peak    <float> : Peak value for other to deviate[MeanData]\n"
		"\n"
		"\t\t-help            : Show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_Z66(int argc, char **argv, In3str1v * para_Z66)
{
	if (argc <=2  ) {print_usage_Z66();return 0 ;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0 ;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_Z66->InStr1=argv[i];
		}
		else if (flag  == "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_Z66->InStr2=argv[i];
		}
		else if (flag  ==  "Row")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_Z66->InInt=atoi(argv[i]);
		}
		else if (flag  ==  "Peak" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_Z66->InStr3=argv[i];
			para_Z66->TF=false;
		}
		else if (flag  == "help")
		{
			print_usage_Z66();return 0 ;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0 ;
		}
	}

	if  ((para_Z66->InStr1).empty()  || (para_Z66->InStr2).empty())
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0 ;
	}
	(para_Z66->InStr2)=add_Asuffix(para_Z66->InStr2) ;

	return 1 ;
}

//programme entry
///////// swimming in the sky and flying in the sea ////////////
//
//int main(int argc, char **argv)
int Other_Ztest_main(int argc, char **argv)
{
	In3str1v * para_Z66 = new In3str1v;
	para_Z66->InInt=4;
	if (parse_cmd_Z66(argc, argv , para_Z66 )==0)
	{
		delete para_Z66 ; 
		return 1;
	}
	ogzstream  OUT ((para_Z66->InStr2).c_str());
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<para_Z66->InStr2<<endl;
		return 1;
	}

	llong Count_Num=0;
	long  double  Sum_Num=0.0;
	long  double  Mean_Data=0.0;

	if (para_Z66->TF)
	{
		long  double this_count ;
		igzstream IN ((para_Z66->InStr1).c_str(),ifstream::in); 
		if(!IN.good())
		{
			cerr << "open IN File error: "<<(para_Z66->InStr1)<<endl;
			return 1;
		}
		while(!IN.eof())
		{
			string  line  ,tempsss;
			getline(IN,line);
			if ( (line.length()<=0)  ||  (line[0] == '#') )  { continue ;}
			istringstream  stream  (line,istringstream::in);
			for (int i=1 ; i<(para_Z66->InInt)  ; i++)
			{
				stream >> tempsss  ;
			}
			stream >> this_count ;
			Count_Num++;
			Sum_Num+= this_count ;
		}
		IN.close();
		Mean_Data=(Sum_Num/Count_Num);
	}
	else
	{
		Mean_Data=atof((para_Z66->InStr3).c_str());
	}


	long  double  Lsd=0.0 ;  llong L_count=0;
	long  double  Rsd=0.0 ;  llong R_count=0;

	long  double this_count=0.0 ;
	long  double diff=0.0 ;

	igzstream INB ((para_Z66->InStr1).c_str(),ifstream::in); 
	if(!INB.good())
	{
		cerr << "open IN File error: "<<(para_Z66->InStr1)<<endl;
		return 1;
	}
	while(!INB.eof())
	{
		string  line  ,tempsss;
		getline(INB,line);
		if ( (line.length()<=0)  ||  (line[0] == '#') )  { continue ;}
		istringstream  stream  (line,istringstream::in);
		for (int i=1 ; i<(para_Z66->InInt)  ; i++)
		{
			stream >> tempsss  ;
		}
		stream >> this_count ;
		diff=this_count-Mean_Data ;
		if  (diff>0)
		{
			R_count++;
			Rsd+=(diff*diff);
		}
		else if  (diff<0)
		{
			L_count++;
			Lsd+=(diff*diff);
		}
	}
	INB.close();
	
	Rsd=sqrt(Rsd/R_count);
	Lsd=sqrt(Lsd/L_count);

	OUT<<"##Add_three_row:\tZ-Score\tP-Value\tP-Value(scientific)"<<endl ;
	OUT<<"#MeanData:\t"<<Mean_Data<<"\n#Left SD:\t-"<<Lsd<<"\tcount:\t"<<L_count<<"\n#Right SD:\t+"<<Rsd<<"\tcount:\t"<<R_count<<endl;
	igzstream INC ((para_Z66->InStr1).c_str(),ifstream::in); 
	if(!INC.good())
	{
		cerr << "open IN File error: "<<(para_Z66->InStr1)<<endl;
		return 1;
	}
	while(!INC.eof())
	{
		string  line  ,tempsss;
		getline(INC,line);
		if (line.length()<=0)  { continue ; }
		if ( (line[0]=='#') )  { OUT<<line<<endl; }
		istringstream  stream  (line,istringstream::in);
		for (int i=1 ; i<(para_Z66->InInt)  ; i++)
		{
			stream >> tempsss  ;
		}
		stream >> this_count ;
		diff=this_count-Mean_Data ;
		double PValue=1.0;
		if  (diff>0)
		{
			PValue=(1-pnorm5(this_count, Mean_Data , Rsd  , 1 , 0 ));
			this_count=diff/Rsd;
		}
		else if  (diff<0)
		{
			PValue=(pnorm5(this_count, Mean_Data , Lsd  , 1 , 0 ));
			this_count=diff/Lsd;
		}
		else
		{
			this_count=0.0;
		}
		OUT<<line<<"\t"<<setprecision(4)<<setiosflags(ios::right)<<setiosflags(ios::fixed)<<this_count<<"\t"<<PValue<<"\t"<<setprecision(6)<<setiosflags(ios::scientific)<<setiosflags(ios::fixed)<<PValue<<endl;
	}
	INC.close();


	OUT.close();
	delete para_Z66 ;
	return 0;
}
#endif 
///////// swimming in the sky and flying in the sea ////////////

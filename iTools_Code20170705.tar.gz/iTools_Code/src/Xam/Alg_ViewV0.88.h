/*
 * DataClass.h
 *
 *  Created on: 2011-11-21
 *      Author: hewm@genomics.org.cn
 */

#ifndef ViewAlg_H_
#define ViewAlg_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cmath>
#include <iomanip>
#include <cassert>
#include <cstdlib>
#include <assert.h>
#include <ctype.h>
#include "../ALL/DataClass.h"
#include <ncurses.h>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include <algorithm>
#include <cctype>
#include "../ALL/comm.h"
#include "../Head/tools.h"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"
//string, cctype,algorithm

using namespace std;
typedef long long llong ;

#define TV_MIN_ALNROW 2
#define TV_MAX_GOTO  40
#define TV_LOW_MAPQ  10

#define TV_COLOR_MAPQ   0
#define TV_COLOR_BASEQ  1
#define TV_COLOR_NUCL   2
#define TV_COLOR_COL    3
#define TV_COLOR_COLQ   4

#define TV_BASE_NUCL 0
#define TV_BASE_COLOR_SPACE 1


#define Max_Input_Line 524286
//#define Max_Input_Line 1024286
///////////////// q_seq  for site ////////

class Para_A13 {
	public:
		string InPut ;
		string Ref ;
		int A ;
		char minBaseQ ;
		Para_A13()
		{
			InPut="";
			Ref="";
			A=0;
			minBaseQ='@';
		}

		//    string output_Afile ;
};




int  print_Ausage_A13()
{
	cout <<""
		"\n"
		"\tUsage: view  -InBam  <in.bam> -Ref <Ref.fa>\n"
		"\n"
		"\t\t-InBam      <str>   Input SortBamByChr\n"
		"\t\t-InSam      <str>   Input SortSamByChr\n"
		"\t\t-InSoap     <str>   Input SortSoapByChr\n"
		"\n"
		"\t\t-Ref        <str>   Input Ref Seq fa\n"
		"\t\t-MinBaseQ  <char>   The min Seq Quality ['@']\n"
		"\t\t-SamNoHead          if the file is Sam with NoHead\n"
		"\n"
		"\t\t-help               show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_A13(int argc, char **argv,Para_A13 * para_A13)
{
	if (argc <=2 ) {print_Ausage_A13();return 0 ;}

	int err_Aflag = 0;
	bool XFT=false ;
	for(int i = 1; i < argc || err_Aflag; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag == "InSoap")
		{
			if(i + 1 == argc)
			{cerr << "lack argument for '-InSoap'" <<endl;err_Aflag = 1; return 0;}
			i++;
			para_A13->InPut=argv[i];
			para_A13->A=1;
		}
		else if (flag == "InSam")
		{
			if(i + 1 == argc)
			{cerr << "lack argument for '-InSam'" <<endl;err_Aflag = 1; return 0;}
			i++;
			para_A13->InPut=argv[i];
			para_A13->A=2;
		}
		else if (flag == "InBam")
		{
			if(i + 1 == argc)
			{cerr << "lack argument for '-InBam'" <<endl;err_Aflag = 1; return 0;}
			i++;
			para_A13->InPut=argv[i];
			para_A13->A=3;
		}
		else if (flag == "MinBaseQ")
		{
			if(i + 1 == argc)
			{cerr << "lack argument for '-MinBaseQ'" <<endl;err_Aflag = 1; return 0;}
			i++;
			para_A13->minBaseQ=argv[i][0];
		}
		else if (flag == "Ref")
		{
			if(i + 1 == argc)
			{cerr << "lack argument for '-Ref'" <<endl;err_Aflag = 1; return 0;}
			i++;
			para_A13->Ref=argv[i];        
		}
		else if ( flag == "SamNoHead" )
		{
			XFT=true ;
		}
		else if (flag  == "help")
		{
			print_Ausage_A13();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_A13->InPut).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	if (XFT)
	{
		if ((para_A13->A)!=2)
		{
			cerr<<"since -SamNoHead should same with -Sam"<<endl;
			return 0;
		}
		else if ((para_A13->A)==2)
		{
			(para_A13->A)=4;
		}
	}
	else if ((para_A13->A)==2)
	{
		string line ,RID ;
		igzstream INSt ((para_A13->InPut).c_str(),ifstream::in);
		getline(INSt,line);
		istringstream isone (line,istringstream::in);
		isone>>RID;
		if (RID !="@SQ")
		{
			cerr<<"\t\tThe samFile "<<(para_A13->InPut)<<" may hadn't head"<<endl;
			cerr<<"\t\tyou can try  '-SamNoHead'"<<endl; 
			return 0;
		}
		INSt.close();
	}
	return 1 ;
}


class SoapFromat {

	public:
		string ID ;
		string seq ;
		string Qseq ;
		int Length ;
		llong start;

		SoapFromat()
		{
			ID="";
			seq="";
			Qseq="";
			Length=0;
			start=0;
		}

		void Init( string RID, string Rseq ,string RseqQ, int RL , llong RPosti , int hit  )
		{
			ID=RID;  seq=Rseq ; Qseq=RseqQ ; Length=RL ; start=RPosti ;
			if (hit!=1)
			{
				transform(seq.begin(),seq.end(),seq.begin(), ::tolower  ) ;
			}
		}

		llong GetReadEnd ()
		{
			return  (start+Length);
		}

		////////swimming in the sky and flying in the sea *///////////
};


class tview_t 
{
	public:
		int mrow, mcol ;
		WINDOW *wgoto, *whelp;
		SoapFromat Alg[Max_Input_Line] ;
		int AlgLine ;
		igzstream  SOAP ;
		TSamCtrl   SAM ;
		string RefSeq ;
		int row_shift ;   
		llong curr_left_pos , last_pos ;
		int color_for ;
		int is_dot ;
		string chr_now ;
		char Flag ;
		bool EndFile;
		int  minBaseQ ;
		vector <string> ChrRun ;
		//int ccol, last_pos, row_shift, base_for, color_for, is_dot, l_ref, ins, no_skip, show_name;

};

int BinSearchMax ( tview_t * tv, llong  pos )
{
	int low=1 ;
	int hight=(tv->AlgLine)-1 ;
	int mid ;
	if ( ((tv->Alg)[0]).start<=pos  &&  ((tv->Alg)[1].start)>=pos )  { return 1 ; }
	while (low<=hight)
	{
		mid=(low+hight)/2;
		if ( ((tv->Alg)[mid]).start >= pos && ((tv->Alg)[mid-1]).start <= pos )
		{
			return mid ;
		}
		else if ( (((tv->Alg)[mid-1]).start) >= pos )
		{
			hight=mid-1;
		}
		else
		{
			low=mid+1;
		}
	}
	return (-1) ;
}


void tv_destroy(tview_t *tv)
{
	if ((tv->color_for)==1  || (tv->color_for)==4 )
	{
		(tv->SOAP).close();
	}

	delwin(tv->wgoto); delwin(tv->whelp);
	endwin();
	free(tv);
}



int printLine(tview_t * tv , SoapFromat Line , int Row , llong pos ,Site cns[]) 
{
	int PringRow=Row-(tv->row_shift)+3 ;
	int Stat=Line.start-pos ;
	int x ;

	if ((tv->Flag) == '1' )
	{
		for(int ii=0 ; ii< Line.Length ; ii++ )
		{
			int key=Stat+ii ;
			if ( (key>-1)  &&  key<(tv->mcol) )
			{
				cns[key].Add_Quality(Line.seq[ii],Line.Qseq[ii] , 1);
				if (PringRow>1 && PringRow <=(tv->mrow))
				{
					int attr = 0;
					x=((Line.Qseq[ii]-(tv->minBaseQ))/10)+1; 
					if (toupper(Line.seq[ii]) == 'N'){ x=10; }
					else if (x>4) {x=4;}
					attr |= COLOR_PAIR(x);
					attron(attr);                
					mvaddch(PringRow , key, Line.seq[ii]);
					attroff(attr);
				}
			}
		}
	}
	else if ((tv->Flag) == '2' )
	{
		for(int ii=0 ; ii< Line.Length ; ii++ )
		{
			int key=Stat+ii ;
			if ( (key>-1)  &&  key<(tv->mcol) )
			{
				cns[key].Add_Quality(Line.seq[ii],Line.Qseq[ii] , 1);
				if (PringRow>1 && PringRow <=(tv->mrow))
				{
					int attr = 0;
					x=((Line.Qseq[ii]-(tv->minBaseQ))/10)+1;
					if (toupper(Line.seq[ii]) == 'N'){ x=10; }
					else if (x>4) {x=4;}
					attr |= COLOR_PAIR(x);
					attron(attr);
					mvaddch(PringRow , key, Line.Qseq[ii]);
					attroff(attr);
				}
			}
		}
	}
	else if ((tv->Flag) == '3' )
	{
		int ID_length= (Line.ID).length() ;
		for(int ii=0 ; ii< Line.Length ; ii++)
		{
			int key=Stat+ii ;
			if ( (key>-1)  &&  key<(tv->mcol) )
			{
				cns[key].Add_Quality(Line.seq[ii],Line.Qseq[ii] , 1);
				if (PringRow>1 && PringRow <=(tv->mrow) &&  ii< ID_length )
				{
					mvaddch(PringRow , key, Line.ID[ii]);
				}
			}
		}
	}
	if ((tv->Flag) == '4' ) 
	{
		if ((tv->RefSeq).empty())
		{

			for(int ii=0 ; ii< Line.Length ; ii++ )
			{
				int key=Stat+ii ;
				if ( (key>-1)  &&  key<(tv->mcol) )
				{
					cns[key].Add_Quality(Line.seq[ii],Line.Qseq[ii] , 1);
					if (PringRow>1 && PringRow <=(tv->mrow))
					{
						int attr = 0;
						x=12;
						char tmpB=toupper(Line.seq[ii]) ;
						if ( tmpB == 'N'){ x=10; }
						attr |= COLOR_PAIR(x);
						attron(attr);
						mvaddch(PringRow , key, Line.seq[ii]);
						attroff(attr);
					}
				}
			}

		}
		else
		{

			for(int ii=0 ; ii< Line.Length ; ii++ )
			{
				int key=Stat+ii ;
				if ( (key>-1)  &&  key<(tv->mcol) )
				{
					cns[key].Add_Quality(Line.seq[ii],Line.Qseq[ii] , 1);
					if (PringRow>1 && PringRow <=(tv->mrow))
					{
						int attr = 0;
						x=4;
						char tmpB=toupper(Line.seq[ii]) ;
						if ( tmpB == 'N'){ x=10; }
						else if (tmpB !=toupper((tv->RefSeq)[Line.start+ii-1]) )
						{
							x=11;
						}
						attr |= COLOR_PAIR(x);
						attron(attr);
						mvaddch(PringRow , key, Line.seq[ii]);
						attroff(attr);
					}
				}
			}

		}
	}

	return 1 ;
}


int raw_Agm ( vector <SoapFromat> Pr, int Line, tview_t * tv , llong pos , vector <llong> EndRead , Site cns[] )
{
	vector <llong> TmpV ;
	TmpV.push_back(EndRead[Line-1]);
	printLine( tv , Pr[Line-1], 0 , pos , cns ) ;

	for(int ii=Line-2 ; ii>-1 ; ii--)
	{
		int AD=TmpV.size();
		int Newrow=1;int jj =0;
		for ( jj=0 ; jj<AD ; jj++ )
		{
			//       cerr<<ii<<"\t"<<jj<<"\t"<<Pr[ii].start<<"\t"<<TmpV[jj]<<"\t"<<AD<<endl;
			if ((Pr[ii].start>TmpV[jj]))
			{
				printLine(tv , Pr[ii], jj ,pos ,cns ) ;
				TmpV[jj]=EndRead[ii];
				Newrow=0;
				break ;
			}
		}
		if (Newrow)
		{
			printLine( tv , Pr[ii], AD ,pos ,cns ) ;
			TmpV.push_back(EndRead[ii]) ;
		}
	}
	//       mvaddch(0,1,'e') ; refresh();  getch();
	return 1 ;
}

int tv_pl_func(llong  pos, tview_t  * tv )
{
	clear();
	llong End_pos=pos+(tv->mcol);
	int EndPrint=BinSearchMax( tv ,End_pos ) ;
	if (EndPrint==-1 )
	{
		tv_destroy(tv);
		return 1 ;
	}
	llong  Finanl_End=((tv->Alg)[(tv->AlgLine)-1]).GetReadEnd();
	llong  Finanl_Start=((tv->Alg)[0]).start;
	string ID=(tv->chr_now)+":"+Int2Str(pos)+"<-->"+Int2Str(End_pos)+"\t\t"+Int2Str(Finanl_Start)+"<-->"+Int2Str(Finanl_End);
	mvaddstr(0,0,ID.c_str());
	llong Start_pos=pos-200; 
	vector <SoapFromat>  PringSoapLine ;
	vector <llong> EndRead ;

	for (int ii=EndPrint ; ((tv->Alg)[ii]).start >Start_pos && ii>-1   ; ii--)
	{
		llong tmpReadEnd = ((tv->Alg)[ii]).GetReadEnd();  
		llong tmpReadStart = ((tv->Alg)[ii]).start ;  
		if (tmpReadEnd <pos ) { continue ;}
		if (tmpReadStart>End_pos) { continue ;}

		PringSoapLine.push_back((tv->Alg)[ii]);
		EndRead.push_back(tmpReadEnd);
	}
	int veLength=PringSoapLine.size();
	if  (veLength>0)
	{
		Site *cns = new Site[(tv->mcol)];
		raw_Agm(PringSoapLine , veLength, tv , pos , EndRead , cns ) ; 
		if ((tv->RefSeq).empty())
		{
			for (int ii=0  ; ii<(tv->mcol) ; ii++ )
			{
				int B_length=0 ;
				string A=cns[ii].Genotype(B_length,(tv->minBaseQ));
				char c=A[0];
				int attr = A_UNDERLINE;
				int i = 2  ;
				if (B_length)
				{
					i=3 ;
					if ( c == 'A' ||c == 'G' ||c == 'T' ||c == 'C'  || c == 'N' )
					{
						i=1 ;
					}
				}
				attr |= COLOR_PAIR(i);
				attron(attr);
				mvaddch(2, ii , c);
				attroff(attr);
				if (((ii+pos)%20)==0)
				{
					attr=COLOR_PAIR(8);                    
					attron(attr);
					mvaddch(1, ii , 'N');
					attroff(attr);
				}
				else
				{
					mvaddch(1, ii , 'N');
				}

			}
		}
		else
		{
			for (int ii=0  ; ii<(tv->mcol) ; ii++)
			{
				int  B_length=0 ;
				char Refbase=(tv->RefSeq)[ii+pos-1];
				string A=cns[ii].Genotype(B_length,(tv->minBaseQ),Refbase);
				char c=A[0];
				int attr = A_UNDERLINE;
				int i = 2  ;
				if (B_length)
				{
					i=1 ;
					if ( c !=Refbase )
					{
						i=3 ;
					}
				}
				attr |= COLOR_PAIR(i);
				attron(attr);
				mvaddch(2, ii , c);
				attroff(attr);
				if (((ii+pos)%20)==0)
				{
					attr=COLOR_PAIR(8); 
					attron(attr);
					mvaddch(1, ii , Refbase);
					attroff(attr);
				}
				else
				{
					mvaddch(1, ii , Refbase);
				}
			}
		}
		delete [] cns ;
	}
	else
	{
		if ((tv->RefSeq).empty())
		{
			for (int ii=0  ; ii<(tv->mcol) ; ii++ )
			{
				if (((ii+pos)%20)==0)
				{
					int attr=COLOR_PAIR(8); 
					attron(attr);
					mvaddch(1, ii , 'N');
					attroff(attr);
				}
				else
				{
					mvaddch(1, ii , 'N');
				}
				mvaddch(2, ii , 'N');
			}
		}
		else
		{
			for (int ii=0  ; ii<(tv->mcol) ; ii++)
			{
				char Refbase=(tv->RefSeq)[ii+pos-1];
				char c=Refbase;
				int attr = A_UNDERLINE;
				int i = 2  ;
				if ( c == 'A' ||c == 'G' ||c == 'T' ||c == 'C'  || c == 'N' )
				{
					i=1 ;
				}
				attr |= COLOR_PAIR(i);
				attron(attr);
				mvaddch(2, ii , c);
				attroff(attr);
				if (((ii+pos)%20)==0)
				{
					attr=COLOR_PAIR(8); 
					attron(attr);
					mvaddch(1, ii , Refbase);
					attroff(attr);
				}
				else
				{
					mvaddch(1, ii , Refbase);
				}
			}
		}
	}
	refresh();
	return 1 ;

}

int  ReadSoapVetor (tview_t * tv  , int Vecotr_L )
{
	string ID , seq ,Qseq ,ab , zf  ,Nowchr ;
	llong position ;
	int hit , Read_leng ;
	Nowchr=tv->chr_now ;
	if ( (tv->color_for)==1)
	{
		string  line ;
		while( (!(tv->SOAP).eof())  && ((tv->AlgLine)<Vecotr_L) )
		{
			getline(tv->SOAP,line);
			if (line.empty()){continue ;}
			istringstream isoneA (line,istringstream::in);
			isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
			if ( Nowchr  != (tv->chr_now) )
			{
				(tv->chr_now)=Nowchr ;
				return 1;
			}

			(tv->Alg[(tv->AlgLine)]).Init(ID,seq ,Qseq, Read_leng , position ,hit ) ;
			(tv->AlgLine)++;
		}
		if ((tv->SOAP).eof())
		{
			tv->EndFile=true ;
		}
	}
	else if ((tv->color_for)==4)
	{
		while( (!(tv->SOAP).eof())  && ((tv->AlgLine)<Vecotr_L) )
		{
			string line ;
			getline(tv->SOAP,line);
			if (line.empty()){continue ;}
			vector<string> inf;
			split(line,inf," \t");
			if ( inf[2]  != (tv->chr_now) )
			{
				(tv->chr_now)=inf[2] ;
				return 1;
			}

			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size(); 
			int vec_size=inf.size();
			hit = 1;
			for (int i = 11; i < vec_size; i++) {
				if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
			}
			(tv->Alg[(tv->AlgLine)]).Init(inf[0],inf[9],inf[10], Read_leng , position ,hit) ;
			(tv->AlgLine)++;
		}

		if ((tv->SOAP).eof())
		{
			tv->EndFile=true ;
		}
	}
	else
	{
		while(  ((tv->SAM).isOpened())   && ((tv->AlgLine)<Vecotr_L) )
		{
			string  line ;
			(tv->SAM).readline(line);
			if (line.empty()){continue ;}
			vector<string> inf;
			split(line,inf," \t");
			if ( inf[2]  != (tv->chr_now) )
			{
				(tv->chr_now)=inf[2] ;
				return 1;
			}

			Tcount_indel_len(inf[5],Read_leng,inf[9],inf[10]);
			position=atol(inf[3].c_str());
			Read_leng=inf[9].size(); 
			int vec_size=inf.size();
			hit = 1;
			for (int i = 11; i < vec_size; i++) {
				if (inf[i].find(HIT_COUNT_H0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				} else if (inf[i].find(HIT_COUNT_X0) != std::string::npos) {
					hit = atoi(inf[i].substr(5).c_str());
					break;
				}
			}
			(tv->Alg[(tv->AlgLine)]).Init(inf[0],inf[9],inf[10], Read_leng , position ,hit) ;
			(tv->AlgLine)++;
		}

		if (!((tv->SAM).isOpened()))
		{
			tv->EndFile=true ;
		}
	}
	return 1 ;    
}



int tv_init( Para_A13 * para_A13 , tview_t * tv  )
{
	tv->color_for=para_A13->A ;
	tv->minBaseQ=(para_A13->minBaseQ)+0 ;
	tv->EndFile=false ;
	if ( (tv->color_for)==1  ||  (tv->color_for)==4 )
	{
		(tv->SOAP).open((para_A13->InPut).c_str(),ifstream::in);
		if(!(tv->SOAP).good())
		{
			cerr << "open InputFile error: "<<(para_A13->InPut)<<endl;
			return 0 ;
		}
	}
	else 
	{
		char in_mode[5] ={ 0 };
		in_mode[0]='r';
		if ((tv->color_for)==3)
		{
			in_mode[1]='b';
		}
		(tv->SAM).open((para_A13->InPut).c_str(),in_mode);
	}
	initscr();
	keypad(stdscr, TRUE);
	clear();
	noecho();
	cbreak();
	tv->mrow = 24; tv->mcol = 80;
	getmaxyx(stdscr, tv->mrow, tv->mcol);
	tv->wgoto = newwin(3, TV_MAX_GOTO + 10, 10, 5);
	tv->whelp = newwin(25, 40, 5, 5);
	//  tv->color_for = TV_COLOR_MAPQ;
	tv->row_shift=0 ;
	tv->is_dot=0;
	(tv->Flag) = '1' ;
	string line ;

	if ((tv->color_for)==1)
	{
		getline((tv->SOAP),line);
	}
	else if ((tv->color_for)==4)
	{
		getline((tv->SOAP),line);
		if (line[0] == '@'  &&  line[0] == 'S'  &&  line[0] == 'Q')
		{
			cerr<<"the sam file had head, don't add -SamNoHead"<<endl;
			return 0;
		}
		line = Talignment_format(line);
	}
	else
	{
		while((tv->SAM).readline(line)!=-1)
		{
			//samhandle.readline(line);
			line = Talignment_format(line);
			if (line.compare(NOUSE_ALIGNMENT)==0) 
			{
				continue;
			}
			else
			{
				break ;
			}
		}
	}

	string ID , seq ,Qseq ,ab , zf  ,Nowchr ;
	llong position ;
	int hit , Read_leng ;
	istringstream isoneA (line,istringstream::in);
	isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

	tv->chr_now=Nowchr ;
	(tv->ChrRun).push_back(Nowchr) ;
	tv->curr_left_pos=position;
	tv->last_pos=position+(tv->mcol);
	tv->AlgLine=1;
	(tv->Alg[0]).Init(ID,seq ,Qseq, Read_leng , position , hit ) ;
	int Firstbin=Max_Input_Line/200;

	ReadSoapVetor ( tv  , Firstbin ) ;

	if (!(para_A13->Ref).empty())
	{
		gzFile fp;
		kseq_t *seq;
		int l;
		fp = gzopen((para_A13->Ref).c_str(), "r");
		seq = kseq_init(fp);
		while ((l = kseq_read(seq)) >= 0) 
		{
			if ((seq->name.s)==(tv->chr_now))
			{
				(tv->RefSeq)=(seq->seq.s);
				break ;
			}
		}
		kseq_destroy(seq);
		gzclose(fp);
	} 
	start_color();
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_WHITE, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(6, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_RED, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);
	tv_pl_func( (tv->curr_left_pos) , tv );
	ReadSoapVetor ( tv  , Max_Input_Line ) ;
	return 1;
}


static void tv_win_help(tview_t *tv) {
	int r = 1;
	WINDOW *win = tv->whelp;
	wborder(win, '|', '|', '-', '-', '+', '+', '+', '+');
	mvwprintw(win, r++, 2, "        -=-    Help    -=- ");
	r++;
	mvwprintw(win, r++, 2, "?          This window");
	mvwprintw(win, r++, 2, "Arrows     Small scroll movement");
	mvwprintw(win, r++, 2, "h,j,k,l    Small scroll movement");
	mvwprintw(win, r++, 2, "H,J,K,L    Large scroll movement");
	mvwprintw(win, r++, 2, "ctrl-H     Scroll 1k left");
	mvwprintw(win, r++, 2, "ctrl-L     Scroll 1k right");
	mvwprintw(win, r++, 2, "space      Scroll one screen");
	mvwprintw(win, r++, 2, "backspace  Scroll back one screen");
	mvwprintw(win, r++, 2, "g          Go to specific location");
	mvwprintw(win, r++, 2, "n          Color for nucleotide");
	mvwprintw(win, r++, 2, "b          Color for base quality");
	mvwprintw(win, r++, 2, "c          Color for cs color");
	//    mvwprintw(win, r++, 2, "z          Color for cs qual");
	//    mvwprintw(win, r++, 2, ".          Toggle on/off dot view");
	//    mvwprintw(win, r++, 2, "s          Toggle on/off ref skip");
	mvwprintw(win, r++, 2, "R          Toggle on rd name view");
	mvwprintw(win, r++, 2, "T          Turn on qual view");
	mvwprintw(win, r++, 2, "S          Turn on nucleotide view");
	mvwprintw(win, r++, 2, "D          Turn on DiffRefBase view");
	//mvwprintw(win, r++, 2, "C          Turn on cs view");
	//mvwprintw(win, r++, 2, "i          Toggle on/off ins");
	mvwprintw(win, r++, 2, "q          Exit");
	r++;
	//   mvwprintw(win, r++, 2, "Underline:      Secondary or orphan");
	mvwprintw(win, r++, 2, "UpperCase : UniqMapping ");
	mvwprintw(win, r++, 2, "Blue:    0-9    Green: 10-19");
	mvwprintw(win, r++, 2, "Yellow: 20-29   White: >=30");
	wrefresh(win);
	wgetch(win);
}

static void tv_win_goto(tview_t *tv, int & tid, llong  & pos)
{
	char str[256], *p;
	int i, l = 0;
	wborder(tv->wgoto, '|', '|', '-', '-', '+', '+', '+', '+');
	mvwprintw(tv->wgoto, 1, 2, "Goto: ");
	for (;;) {
		int c = wgetch(tv->wgoto);
		wrefresh(tv->wgoto);
		if (c == KEY_BACKSPACE || c == '\010' || c == '\177') {
			if (l>0){ --l;}
		}
		else if (c == KEY_ENTER || c == '\012' || c == '\015') 
		{
			int  _beg;
			if (str[0] == '=') {
				_beg = strtol(str+1, &p, 10) - 1;
				if (_beg > 0) {
					pos = _beg+1;
					return;
				}
			} else {
				int ii=0 ;
				for ( ii=0 ; ii<256 ; ii++)    
				{
					if (str[ii] == ':')
					{
						break ;
					}
				}
				int _beg = strtol(str+ii+1, &p, 10) - 1;
				if ( _beg >0 ) {pos = _beg+1;}
				return;
			}
		}
		else if (isgraph(c))
		{
			if (l < TV_MAX_GOTO) str[l++] = c;
		}
		else if (c == '\027') {l = 0;}
		else if (c == '\033') { return; }
		str[l] = '\0';
		for (i = 0; i < TV_MAX_GOTO; ++i) mvwaddch(tv->wgoto, 1, 8 + i, ' ');
		mvwprintw(tv->wgoto, 1, 8, "%s", str);
	}
}




void tv_loop(tview_t *tv)
{
	llong   pos;
	int tid =1 ;

	//    mvaddch(3,1,'B') ; refresh();  getch();
	//tid = tv->curr_tid;
	pos = (tv->curr_left_pos);
	while (1) {
		int c = getch();
		switch (c) {
			case '?': tv_win_help(tv); break;
			case '\033':
			case 'Q':
			case 'q': goto end_loop;
			case '/': 
			case 'g': tv_win_goto(tv, tid, pos); break;
			case 'T' :  (tv->Flag) = '2' ; break;
			case 'S' :  (tv->Flag) = '1' ; break;
			case 'R' :  (tv->Flag) = '3' ; break;
			case 'D' :  (tv->Flag) = '4' ; break;
						/*           case 'm': tv->color_for = TV_COLOR_MAPQ; break;
									 case 'b': tv->color_for = TV_COLOR_BASEQ; break;
									 case 'n': tv->color_for = TV_COLOR_NUCL; break;
									 case 'c': tv->color_for = TV_COLOR_COL; break;
									 case 'z': tv->color_for = TV_COLOR_COLQ; break;
									 case 's': tv->no_skip = !tv->no_skip; break;
						///*/////
			case KEY_LEFT:
			case 'h': --pos; break;
			case KEY_RIGHT:
			case 'l': ++pos; break;
			case KEY_SLEFT:
			case 'H': pos -= 20; break;
			case KEY_SRIGHT:
			case 'L': pos += 20; break;
			case '.': tv->is_dot = !tv->is_dot; break;
					  //          case 'N': tv->base_for = TV_BASE_NUCL; break;
					  //          case 'C': tv->base_for = TV_BASE_COLOR_SPACE; break;
					  //          case 'i': tv->ins = !tv->ins; break;
			case '\010': pos -= 1000; break;
			case '\014': pos += 1000; break;
			case ' ': pos += tv->mcol; break;
			case KEY_UP:
			case 'j': --tv->row_shift; break;
			case KEY_DOWN:
			case 'k': ++tv->row_shift; break;
			case KEY_BACKSPACE:
			case '\177': pos -= tv->mcol; break;
			case KEY_RESIZE: getmaxyx(stdscr, tv->mrow, tv->mcol); break;
			default: continue;
		}
		llong tmp=(((tv->Alg)[(tv->AlgLine)-1]).start-(tv->mcol));
		if ((pos>=(((tv->Alg)[0]).start)) && (pos<=tmp)){ ;} 
		else if (pos < (((tv->Alg)[0]).start) )
		{
			pos = (((tv->Alg)[0]).start) ;
		} 
		else if ( ( pos > tmp )  && (tv->EndFile) )
		{
			pos = tmp  ;
		}
		else if ( (pos > tmp) && (!(tv->EndFile)) )    
		{
			while (  (pos > tmp) && (!(tv->EndFile)) )
			{
				(tv->AlgLine)=0; 
				ReadSoapVetor ( tv , Max_Input_Line) ;
				tmp=(((tv->Alg)[(tv->AlgLine)-1]).start-(tv->mcol));
			}

			if (pos < (((tv->Alg)[0]).start) ) 
			{
				pos = (((tv->Alg)[0]).start) ;
			}
		}

		if (tv->row_shift < 0) {tv->row_shift = 0;}
		tv_pl_func( pos,  tv ) ;
	}
end_loop:
	return;
}




//int main(int argc, char *argv[])
int Alg_View_main(int argc, char *argv[])
{
	Para_A13 * para_A13 = new Para_A13;
	if (parse_Acmd_A13(argc, argv, para_A13 )==0)
	{
		delete para_A13 ;
		return 0;
	}

	tview_t * tv = new tview_t ;
	if (tv_init( para_A13 ,tv  ) ==0 )
	{
		tv_destroy(tv);
		delete para_A13 ;
		cerr<<"something wrong"<<endl;
		return 0;
	}
	else
	{
		tv_loop( tv );
		tv_destroy(tv);
		delete para_A13 ;
		return 0;
	}

	return 0;

}



#endif /* ViewAlg_H_ */


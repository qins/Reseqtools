#include <iostream>
#include<map>
#include <fstream>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string>
#include<float.h>
#include "glfRead.h"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
using namespace std ;



#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG 35
#endif

#define MAX_FILE_LIST_LEN 1024
#define MAX_LIST_NAME_LEN 1024
#define MAX_CHR_NAME_LEN 128

//const char decode[16] = {'N','A','C','N','G','N','N','N','T','N','N','N','N','N','N','N'};
//const int code[10] = {0,5,15,10,1,3,2,7,6,11};
//const int rev_code[16] = {0,4,6,5,4,1,8,7,6,8,3,9,5,7,9,2};


////////// heweiming //////////

int  print_usage_4()
{
	cout <<""
		"\n"
		"\tUsage: DepthGlf -InPut <in.glf> -OutPut <out.depth>\n"
		"\n"
		"\t\t-InPut      <str>   InPut the glf file\n"
		"\t\t-OutPut     <str>   OutPut of the depth dis\n"
		"\n"
		"\t\t-AllSite            Print every Site depth[NA]\n"
		"\n"
		"\t\t-help               show this help\n"
		"\n";
	return 1;
}



int parse_cmd_4(int argc, char **argv , In3str1v * para_4)
{
	if (argc <=2 ) {print_usage_4();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_4->InStr1=argv[i];
		}
		else if (flag  ==  "AllSite")
		{
			para_4->InInt=1;
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_4->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_4();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_4->InStr1).empty() ||  (para_4->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}




int depthglf_main(int argc,char *argv[])
{
	In3str1v * para_4 = new In3str1v;

	if( parse_cmd_4(argc, argv, para_4 )==0 )
	{
		delete  para_4 ;
		return 0;
	}
	if ((para_4->InInt)==1)
	{
		//double LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0} ;
		//double mean_hit=0.0 ;
		FILE  *GLFOpen;
		//int FLAG=0,start=0,end=0,i=0,j=0,k=0,N_indi=0,N_hap=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		int start=0,end=0,j=0,chrLen=-1,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		//int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
		char chrName[MAX_CHR_NAME_LEN];
		//char chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024];

		GLFOpen=fopen((para_4->InStr1).c_str(),"rb");
		//      output=fopen((para_4->InStr2).c_str(),"w");
		ofstream OUT ((para_4->InStr2).c_str());
		string outfile=(para_4->InStr2)+".depth.gz";
		ogzstream outDepth (outfile.c_str()); 
		if(!OUT.good())
		{
			cerr << "open OUT File error: "<<para_4->InStr2<<endl;
			return 1;
		}
		if(!outDepth.good())
		{
			cerr <<"open OUT File error: "<<outfile<<endl;
			return 1;
		}
		////////////////////////swimming in the sea & flying in the sky //////////////////
		int chrNum=-1;
		Read_header(GLFOpen,&chrNum);
		int finished = 0 ;
		total_depth =0 ;
		int total_cover =0 ;
		map <int,int> Depth ;
		Read_chr(GLFOpen,&chrLen,chrName);
		fprintf(stdout,"%s len=%d to run Depth\n",chrName,chrLen);
		outDepth<<">"<<chrName<<"\t" <<chrLen<<endl;
		end=chrLen;
		for(j=start;j<end;j++)
		{
			if(j>=chrLen)
			{
				break;
			}
			ref_index=Read_base(GLFOpen,&indi_CN,&indi_dep,LLR);
			outDepth<<indi_dep<<" ";
			finished++;
			total_depth+=indi_dep;
			Depth[indi_dep]++;
			if (indi_dep !=0)
			{
				total_cover++;
			}
			if (0 == finished % 100)
			{
				outDepth<<endl;
			}
		}
		fprintf(stdout,"%s len=%d mean Depth is %.2f,All_depth is %d\n",chrName,chrLen,(total_depth*1.0/end),total_depth);
		fprintf(stdout,"%s len=%d covage is %.2f,All_coverage is %d\n",chrName,chrLen,(total_cover*100.0/end),total_cover);
		//*// //   
		map  <int,int> ::const_iterator map_it=Depth.begin();
		OUT<<"#depth\tnumber\n";
		while(map_it!=Depth.end())
		{
			OUT<<map_it->first<<"\t"<<map_it->second<<endl;
			map_it++;
		}
		///*///
		fclose(GLFOpen);
		outDepth.close();
		OUT.close();
	}
	else
	{
		//double LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0} ;
		//double mean_hit=0.0 ;
		FILE  *GLFOpen;
		//int FLAG=0,start=0,end=0,j=0,k=0,N_indi=0,N_hap=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		int start=0,end=0,j=0,chrLen=-1,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		//        int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
		//char chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024];
		char chrName[MAX_CHR_NAME_LEN];


		GLFOpen=fopen((para_4->InStr1).c_str(),"rb");
		//      output=fopen((para_4->InStr2).c_str(),"w");
		ofstream OUT ((para_4->InStr2).c_str());
		if(!OUT.good())
		{
			cerr << "open OUT File error: "<<para_4->InStr2<<endl;
			return 1;
		}
		////////////////////////swimming in the sea & flying in the sky //////////////////
		int chrNum=-1;
		Read_header(GLFOpen,&chrNum);
		int finished = 0 ;
		total_depth =0 ;
		int total_cover =0 ;
		map <int,int> Depth ;
		Read_chr(GLFOpen,&chrLen,chrName);
		fprintf(stdout,"%s len=%d to run Depth\n",chrName,chrLen);
		end=chrLen;
		for(j=start;j<end;j++)
		{
			if(j>=chrLen)
			{
				break;
			}
			ref_index=Read_base(GLFOpen,&indi_CN,&indi_dep,LLR);
			finished++;
			total_depth+=indi_dep;
			Depth[indi_dep]++;
			if (indi_dep !=0)
			{
				total_cover++;
			}
		}
		fprintf(stdout,"%s len=%d mean Depth is %.2f,All_depth is %d\n",chrName,chrLen,(total_depth*1.0/end),total_depth);
		fprintf(stdout,"%s len=%d covage is %.2f,All_coverage is %d\n",chrName,chrLen,(total_cover*100.0/end),total_cover);
		//*// //   
		map  <int,int> ::const_iterator map_it=Depth.begin();
		OUT<<"#depth\tnumber\n";
		while(map_it!=Depth.end())
		{
			OUT<<map_it->first<<"\t"<<map_it->second<<endl;
			map_it++;
		}
		///*///
		fclose(GLFOpen);
		OUT.close();
	}
	delete para_4 ;
	return 0 ;
}
////////////////////////swimming in the sea & flying in the sky //////////////////

////////////////////////swimming in the sea & flying in the sky //////////////////



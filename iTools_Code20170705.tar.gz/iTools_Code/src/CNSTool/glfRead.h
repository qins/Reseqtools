#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cstdlib>
#include <math.h>

#ifndef glfRead_H_
#define glfRead_H_

/*
#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG 35
#endif

#define MAX_FILE_LIST_LEN 512
#define MAX_LIST_NAME_LEN 1024
#define MAX_CHR_NAME_LEN 128
*/
const char decode[16] = {'N','A','C','N','G','N','N','N','T','N','N','N','N','N','N','N'};
const int code[10] = {0,5,15,10,1,3,2,7,6,11};
const int rev_code[16] = {0,4,6,5,4,1,8,7,6,8,3,9,5,7,9,2};
const char abbv[17] = {'A','M','W','R','M','C','Y','S','W','Y','T','K','R','S','K','G','N'};

//*/

using namespace std;

/*
   string  get_int_of_str(string ab ,int &A ,int &B )
   {
   vector<string> Temp;
   vector<string> Temp2; // AC=12,3
   split(ab,Temp,"=");
   split(Temp[1],Temp2,",");
   A=(atoi(Temp2[0].c_str())) ;
   B=(atoi(Temp2[1].c_str())) ;
   return Temp[0] ;
   }
   */

void Factorial(int N_hap,double *log10_fact){
	//	int i=1;
	for(int i=1;i<=N_hap;i++){
		log10_fact[i]=log10_fact[i-1]+log10((double)i);
	}
}

void Choose(int N_hap,double *log10_fact,double *log10_choose){
	//	int i=1;
	for(int i=1;i<N_hap;i++){
		log10_choose[i]=log10_fact[N_hap]-log10_fact[i]-log10_fact[N_hap-i];
	}
}

void Prior_mat_gen(int N_hap,double *log10_prob){
	double *log10_fact=(double *)malloc(3*sizeof(double));
	double *log10_choose=(double *)malloc(3*sizeof(double));
	memset(log10_fact,0,3*sizeof(double));
	memset(log10_choose,0,3*sizeof(double));
	double freq=0.0;
	Factorial(2,log10_fact);
	Choose(2,log10_fact,log10_choose);
	int minor_count=0,i=0;
	for(minor_count=0;minor_count<=N_hap;minor_count++){
		if(minor_count==0){
			freq=0.1/N_hap;
		}else if(minor_count==N_hap){
			freq=1-0.1/N_hap;
		}else{
			freq=minor_count/(double)(N_hap);
		}
		for(i=0;i<=2;i++){
			*(log10_prob+minor_count*3+i)=log10_choose[i]+i*log10(freq)+(2-i)*log10(1.0-freq);
		}
	}
	free(log10_fact);
	free(log10_choose);
}

void Log2normal(double *power){
	//	int i=0;
	for(int i=0;i<=255;i++){
		power[i]=pow(10,-i/10.0);
	}
}

void Read_header(FILE *infile,int *chrNum){
	char header[4]={'\0'};
	int lineTypeNameLen=0;
	int dataLen=0,major_ver=0,minor_ver=0;
	char *lineTypeName=NULL;
	char *data=NULL;
	fread(header,sizeof(char),3,infile);
	header[3]='\0';
	if(strcmp(header,"glf")!=0){
		fprintf(stdout,"The file is not 'glf' format!\n");
		return ;
	}
	fread(&major_ver,sizeof(int),1,infile);
	fread(&minor_ver,sizeof(int),1,infile);
	while(1){
		fread(&lineTypeNameLen,sizeof(int),1,infile);
		lineTypeName=(char *)malloc((lineTypeNameLen+1)*sizeof(char));
		fread(lineTypeName,sizeof(char),lineTypeNameLen,infile);
		if(strcmp("CHROMOSOMES",lineTypeName)==0){
			break;
		}else{
			fread(&dataLen,sizeof(int),1,infile);
			data=(char *)malloc((dataLen+1)*sizeof(char));
			fread(data,sizeof(char),dataLen,infile);
		}
		printf(lineTypeName,data);
	}
	free(lineTypeName);
	free(data);
	fread(chrNum,sizeof(int),1,infile);
}

void Read_chr(FILE *infile,int *chrLen,char *chrName){
	int chrNameLen=0;
	fread(&chrNameLen,sizeof(int),1,infile);
	fread(chrName,sizeof(char),chrNameLen,infile);
	fread(chrLen,sizeof(int),1,infile);
	fprintf(stdout,"chrName: %s\tcharLen: %d\n",chrName,*chrLen);
}

int Read_base(FILE *infile,int *copyNum,int *depth,int *LLR){
	char tmp1='\0',tmp2='\0';
	char tmp='\0';
	//	int i=0;
	fread(&tmp1,sizeof(char),1,infile);
	fread(&tmp2,sizeof(char),1,infile);
	int ref=(((int)((unsigned char)tmp1))>>4)&0xF;
	*copyNum=((int)((unsigned char)tmp2))&0xF;
	*depth=((((int)((unsigned char)tmp1))&0xF)<<4)|((((int)((unsigned char)tmp2))>>4)&0xF);
	for(int i=0 ;i<10;i++){
		fread(&tmp,sizeof(char),1,infile);
		LLR[i]=(int)((unsigned char)tmp);
	}
	return ref;
}

#endif // glfRead_H_  ;

#include<iostream>
#include<fstream>
#include<map>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string>
#include <sstream>
#include<time.h>
#include<float.h>
#include "../include/gzstream/gzstream.h"
#include "glfRead.h"
#include "../ALL/comm.h"
using namespace std ;


#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG 35
#endif

#define MAX_FILE_LIST_LEN 512
#define MAX_LIST_NAME_LEN 1024
#define MAX_CHR_NAME_LEN 128


int  print_usage_13 ()
{
	cout <<""
		"Program:\n"
		"\n"
		"Usage: GLF2Geno  -GlfList <in.glflist> -OutPut <out.genotype>\n"
		"\t\t-GlfList       <str>   Glf List file input\n"
		"\t\t-OutPut        <str>   file name of output genotype\n"
		"\n"
		"\t\t-Start         <int>   the Start position to Run[0]\n"
		"\t\t-End           <int>   the End position to Run[chr_end]\n"
		"\t\t-DepthOUT              Print the infomation of Depth[NA]\n"
		"\n"
		"\t\t-help                  show this help\n" 
		"\n";
	return 1;
}

int parse_cmd_13(int argc, char **argv , ParaClass * para_13 )
{
	if (argc <=2  ) {print_usage_13();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "GlfList" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_13->InPut1=argv[i];
		}
		else if (flag  == "Start" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_13->InInt1=atoi(argv[i]);
		}
		else if (flag  == "End" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_13->InInt2=atoi(argv[i]);
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_13->OutPut1=argv[i];
		}
		else if (flag  == "DepthOUT")
		{
			para_13->InInt3=1;
		}
		else if (flag  == "help")
		{
			print_usage_13();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ( (para_13->OutPut1).empty() || (para_13->InPut1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}






////////////////////////swimming in the sea & flying in the sky //////////////////
int GLF2GPF_main(int argc,char *argv[])
{
	ParaClass * para_13 = new ParaClass;
	if ( parse_cmd_13(argc, argv, para_13)==0)
	{
		delete para_13;
		return 0;
	}

	if (para_13->InInt3==1)
	{
		clock_t start_time,finish_time;
		double time_cost=0.0,*log10_prob=NULL,power[256]={0.0},LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0},copyNum=0.0,indi_G_LL=0.0;
		FILE *GLFlist=NULL,*output=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
		int FLAG=0,end=0,i=0,j=0,k=0,N_indi=0,N_hap=0,minLLR=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
		char lo[4]={'\0'},hi[4]={'\0'},chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024]; 
		start_time=clock();

		////////////////////////swimming in the sea & flying in the sky //////////////////
		string file3=(para_13->OutPut1);
		//string suffix_temp=".genotype";
		string file4=file3+".genotype.gz" ;
		string file5=file3+".depth.gz" ;
		//ofstream out_fs(file3.c_str());
		ogzstream out_type(file4.c_str());
		ogzstream out_depth(file5.c_str());
		GLFlist=fopen((para_13->InPut1).c_str(),"r");
		while(1)
		{
			if(fgets(str_name,MAX_LIST_NAME_LEN-1,GLFlist)==NULL)
			{
				break;
			}
			else
			{
				if(str_name[strlen(str_name)-1]=='\n')
					str_name[strlen(str_name)-1]='\0';
				Files[FLAG]=fopen(str_name,"rb");
				FLAG++;
			}
		}

		N_indi=FLAG;
		N_hap=2*N_indi;
		//    map <int,map<int, int> > Depth ;
		if(MAX_FILE_LIST_LEN<N_indi)
		{
			cerr<<"GLFlist Number should not more than "<<(MAX_FILE_LIST_LEN-1)<<endl;
			//  fprintf(stdout,"GLFlist Number should not more than %d\n",MAX_FILE_LIST_LEN-1);
			return 0;
		}

		int chrNum=-1;
		int chrNum_new=-1;
		for(i=0;i<FLAG;i++)
		{
			if(-1==chrNum)
			{
				Read_header(Files[i],&chrNum);
			}
			else
			{
				Read_header(Files[i],&chrNum_new);
				if(chrNum!=chrNum_new)
				{
					cerr<<"Inconsistent number of chromosomes,only the first chromosome is called.\n";
				}
				chrNum=1;
			}
		}

		cout<<"Total chromosomes\t"<<chrNum<<endl;

		memset(chrName,'\0',MAX_CHR_NAME_LEN);

		chrLen=-1;
		for(j=0;j<FLAG;j++)
		{
			if(-1==chrLen)
			{
				Read_chr(Files[j],&chrLen,chrName);
			}
			else
			{
				Read_chr(Files[j],&chrLen_tmp,chrName_tmp);
				if(chrLen!=chrLen_tmp||strcmp(chrName,chrName_tmp)!=0)
				{
					cerr<<"ERROR:The files in GLFlist don't have the sanme ChrLen or ChrName!"<<endl;
					return 0;
				}
			}
			fseek(Files[j],12*(para_13->InInt1),1);
		}

		if ((para_13->InInt2)==0)  {  (para_13->InInt2)=chrLen ;} 
		int  finished = 0 ;
		int  prev_pos = para_13->InInt1 ;
		int  pos=prev_pos ;
		cout<<chrName<<"(len:"<<chrLen<<") for "<<FLAG<<" individuals in "<<(para_13->InInt2)-(para_13->InInt1)+1<<" SNP sites" <<endl;
		while(pos<(para_13->InInt2)) 
		{               
			if (pos>=chrLen)
			{
				cout<<"Warning!!! Your SNPs are located outside the chromosome!!! I am stopping!"<<endl ;
				break ;
			}
			//int type=map_it->second;
			//        out_fs<<chrName<<"\t"<<(pos+1)<<"\t"<<abbv[type];
			out_type<<chrName<<"\t"<<(pos+1)<<"\t"  ;
			out_depth<<chrName<<"\t"<<(pos+1)<<"\t" ;
			//        ref = 'N' ;
			int new_ref =0 ;
			int bewee_Two_SNP=12*(pos-prev_pos);
			if (bewee_Two_SNP<0)
			{
				cout<<"Warning!!Bad in sort SNP posi"<<endl;
				return 1;
			}
			indi_CN=0 ; indi_dep=0 ; 
			for(k=0;k<FLAG;k++)
			{
				fseek(Files[k],bewee_Two_SNP,1);
				ref_index=Read_base(Files[k],&indi_CN,&indi_dep,LLR);
				int best_genotype = 16 ;
				int second_genotype = 16 ;

				for (int glf_type=0 ; glf_type<10 ; glf_type++)
				{
					int genotype = code[glf_type] ;
					if( (genotype^type) == 0)
					{
					}
					else if( (((genotype^type)&3)== 0) or ((((genotype^type)>>2)&3) == 0) )
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) {  LLR[glf_type] += 0 ; }
						else  {  LLR[glf_type] += 27 ;  }
					}
					else
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) { LLR[glf_type] += 30 ; }
						else {   LLR[glf_type] += 54; }
					}

					if ( (best_genotype == 16) or (LLR[glf_type] < LLR[rev_code[best_genotype]])) {
						second_genotype = best_genotype ;    best_genotype = genotype ;
					}
					else if ( (second_genotype == 16 ) or (LLR[glf_type] < LLR[rev_code[second_genotype]])  )  {
						second_genotype = genotype ; }
					else
					{ 

					}        
				}
				int quelity_base=(LLR[rev_code[second_genotype]]-LLR[rev_code[best_genotype]]);
				out_depth<<indi_dep<<" ";
				if(quelity_base==0) { out_type<<"- ";  } 
				else { out_type<<abbv[best_genotype]<<" "; }
			}

			out_type<<endl; 
			out_depth<<endl;
			finished += 1 ;
			prev_pos=pos+1;
			if (0 == finished % 10000 )
			{
				cout<<finished<<" SNP size have done"<<endl;
			}
			//map_it++;
		}
		out_type.close();
		out_depth.close();
		cout<<"Finished\t"<<chrName<<"\tMission Complete!"<<endl;
	}
	else
	{


		clock_t start_time,finish_time;
		double time_cost=0.0,*log10_prob=NULL,power[256]={0.0},LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0},copyNum=0.0,indi_G_LL=0.0;
		FILE *GLFlist=NULL,*output=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
		int FLAG=0,end=0,i=0,j=0,k=0,N_indi=0,N_hap=0,minLLR=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
		char lo[4]={'\0'},hi[4]={'\0'},chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024]; 
		start_time=clock();

		////////////////////////swimming in the sea & flying in the sky //////////////////
		string file3=(para_13->OutPut1);
		//string suffix_temp=".genotype";
		string file4=file3+".genotype.gz" ;
		//ofstream out_fs(file3.c_str());
		ogzstream out_type(file4.c_str());
		GLFlist=fopen((para_13->InPut1).c_str(),"r");
		while(1)
		{
			if(fgets(str_name,MAX_LIST_NAME_LEN-1,GLFlist)==NULL)
			{
				break;
			}
			else
			{
				if(str_name[strlen(str_name)-1]=='\n')
					str_name[strlen(str_name)-1]='\0';
				Files[FLAG]=fopen(str_name,"rb");
				FLAG++;
			}
		}

		N_indi=FLAG;
		N_hap=2*N_indi;
		//    map <int,map<int, int> > Depth ;
		if(MAX_FILE_LIST_LEN<N_indi)
		{
			cerr<<"GLFlist Number should not more than "<<(MAX_FILE_LIST_LEN-1)<<endl;
			//  fprintf(stdout,"GLFlist Number should not more than %d\n",MAX_FILE_LIST_LEN-1);
			return 0;
		}

		int chrNum=-1;
		int chrNum_new=-1;
		for(i=0;i<FLAG;i++)
		{
			if(-1==chrNum)
			{
				Read_header(Files[i],&chrNum);
			}
			else
			{
				Read_header(Files[i],&chrNum_new);
				if(chrNum!=chrNum_new)
				{
					cerr<<"Inconsistent number of chromosomes,only the first chromosome is called.\n";
				}
				chrNum=1;
			}
		}

		cout<<"Total chromosomes\t"<<chrNum<<endl;

		memset(chrName,'\0',MAX_CHR_NAME_LEN);

		chrLen=-1;
		for(j=0;j<FLAG;j++)
		{
			if(-1==chrLen)
			{
				Read_chr(Files[j],&chrLen,chrName);
			}
			else
			{
				Read_chr(Files[j],&chrLen_tmp,chrName_tmp);
				if(chrLen!=chrLen_tmp||strcmp(chrName,chrName_tmp)!=0)
				{
					cerr<<"ERROR:The files in GLFlist don't have the sanme ChrLen or ChrName!"<<endl;
					return 0;
				}
			}
			fseek(Files[j],12*(para_13->InInt1),1);
		}

		if ((para_13->InInt2)==0)  {  (para_13->InInt2)=chrLen ;} 
		int  finished = 0 ;
		int  prev_pos = para_13->InInt1 ;
		int  pos=prev_pos ;
		cout<<chrName<<"(len:"<<chrLen<<") for "<<FLAG<<" individuals in "<<(para_13->InInt2)-(para_13->InInt1)+1<<" SNP sites" <<endl;
		while(pos<(para_13->InInt2)) 
		{               
			if (pos>=chrLen)
			{
				cout<<"Warning!!! Your SNPs are located outside the chromosome!!! I am stopping!"<<endl ;
				break ;
			}
			//          int type=map_it->second;
			//        out_fs<<chrName<<"\t"<<(pos+1)<<"\t"<<abbv[type];
			out_type<<chrName<<"\t"<<(pos+1)<<"\t"  ;
			int new_ref =0 ;
			int bewee_Two_SNP=12*(pos-prev_pos);
			if (bewee_Two_SNP<0)
			{
				cout<<"Warning!!Bad in sort SNP posi"<<endl;
				return 1;
			}
			indi_CN=0 ; indi_dep=0 ; 
			for(k=0;k<FLAG;k++)
			{
				fseek(Files[k],bewee_Two_SNP,1);
				ref_index=Read_base(Files[k],&indi_CN,&indi_dep,LLR);
				int best_genotype = 16 ;
				int second_genotype = 16 ;

				for (int glf_type=0 ; glf_type<10 ; glf_type++)
				{
					int genotype = code[glf_type] ;
					if( (genotype^type) == 0)
					{
					}
					else if( (((genotype^type)&3)== 0) or ((((genotype^type)>>2)&3) == 0) )
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) {  LLR[glf_type] += 0 ; }
						else  {  LLR[glf_type] += 27 ;  }
					}
					else
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) { LLR[glf_type] += 30 ; }
						else {   LLR[glf_type] += 54; }
					}

					if ( (best_genotype == 16) or (LLR[glf_type] < LLR[rev_code[best_genotype]])) {
						second_genotype = best_genotype ;    best_genotype = genotype ;
					}
					else if ( (second_genotype == 16 ) or (LLR[glf_type] < LLR[rev_code[second_genotype]])  )  {
						second_genotype = genotype ; }
					else
					{ 

					}        
				}
				int quelity_base=(LLR[rev_code[second_genotype]]-LLR[rev_code[best_genotype]]);
				if(quelity_base==0) { out_type<<"- ";  } 
				else { out_type<<abbv[best_genotype]<<" "; }
			}

			out_type<<endl; 
			finished += 1 ;
			prev_pos=pos+1;
			if (0 == finished % 10000 )
			{
				cout<<finished<<" SNP size have done"<<endl;
			}
			//map_it++;
		}
		out_type.close();
		cout<<"Finished\t"<<chrName<<"\tMission Complete!"<<endl;











	}



	delete para_13 ;

	return 0;
}



////////////////////////swimming in the sea & flying in the sky //////////////////
/////////////////////////swimming in the sea & flying in the sky /////////////////*/

///////// swimming in the sky and flying in the sea ////////////

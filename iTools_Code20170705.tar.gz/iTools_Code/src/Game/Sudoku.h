#include <curses.h>
#include <stdlib.h>

#ifndef  SudokuGame_H_
#define  SudokuGame_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <ncurses.h>
#include <ctime>
#include "LiangLianKan.h"
#include "../ALL/comm.h"
#include "Draw_comm.h"
#include "FindMine.h"

void magic(FindMine * tv)
{	
	int i,j,k;
	int row,col;
	int n=tv->Count;
	for(i = 0;i < n;++i)
		for(j = 0;j < n;++j)
			(tv->Arry[i][j]).Find = -1;
	row = 0;
	col = n / 2;
	k = 1;
	(tv->Arry[row][col]).Find = k;

	while(k != n * n)
	{	
		if(row == 0 && col != n - 1)
		{	row = n - 1;
			col ++;
			(tv->Arry[row][col]).Find = ++k;
		}
		else if(row != 0 && col != n - 1)
		{	
			if((tv->Arry[row - 1][col + 1]).Find == -1)
			{
				row --;
				col ++;
				(tv->Arry[row][col]).Find = ++k;
			}
			else
			{	
				row ++;
				(tv->Arry[row][col]).Find = ++k;
			}
		}
		else if(row != 0 && col == n - 1)
		{	
			row -- ;
			col = 0;
			(tv->Arry[row][col]).Find = ++k;
		}
		else if(row == 0 && col == n - 1)
		{	
			row ++;
			(tv->Arry[row][col]).Find = ++k;
		}
	}
	return;
}


void circumrotate ( FindMine * tv )
{
	int ** tmp ;
	int M=tv->Count;
	tmp  = new int *[M];
	tmp[0] = new int[M*M];

	for(int i = 1; i <M; i++)
	{
		tmp[i] = tmp[i-1]+M ;
	}

	for(int i=0;i<M;i++)
	{
		for(int j=0;j<M;j++)    
		{
			tmp[M-1-j][i]=(tv->Arry[i][j]).Find ;
		}
	}

	for(int k=0;k<M;k++)
	{
		for(int l=0;l<M;l++)
		{
			(tv->Arry[k][l]).Find=tmp[k][l];
		}
	}

	delete []  tmp[0] ;
	delete []  tmp ;    

}


///////////////////

bool Sudoku_tv_Draw (FindMine * tv )
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(7); attron(attr);
	mvaddstr(0,(tv->mcol/2)-15,"Welcome come, Sudoku Game");
	int HelpPosi=(tv->mcol)/2 ;
	mvaddstr(1,(tv->mcol/2)-15,"Love hewm@genomics.org.cn");
	mvaddstr(2,(tv->mcol/2)-15,"Make nondirectional sum Same ");
	mvaddstr(3,(tv->mcol/2)-25,"q : leave; n : next level; f :forward level; r : repeat" );
	string sore="level :" + Int2Str(tv->level)+"  k: See Result";
	mvaddstr(4,(tv->mcol/2)-10,sore.c_str());
	attroff(attr);
	attr = COLOR_PAIR(4);
	attron(attr);
	board(stdscr, tv->STARTY, tv->STARTX,  tv->ROW,  tv->COL, tv->WIDTH, tv->HEIGHT);
	attroff(attr);
	refresh();
	return true ;
}

bool Sudoku_check (  FindMine * tv  )
{
	for (int i = 0; i <(tv->COL); i++)
	{
		for (int j = 0; j <(tv->ROW); j++)
		{
			if ((tv->Arry[i][j]).P)
			{
				return false ;
			}
		}

	}

	return true ;
}


bool Sudoku_tv_Pair( FindMine * tv )
{
	int endy = tv->STARTY + tv->ROW * tv->HEIGHT;
	int endx = tv->STARTX + tv->COL * tv->WIDTH;
	int deltay = tv->HEIGHT / 2;
	int deltax = tv->WIDTH  / 2;
	MEVENT event;
	int x1=0 ,y1=0 ;
	int Right=0;
	int Flag=(tv->Count) ;

	move(endy+2,endx+2);
	refresh();

	string Input_str ;    
	int NowX=-2;
	int NowY=-2;
	int ArrX=-2 ;
	int ArrY=-2 ;
	while(true)
	{        
		if (Sudoku_check(tv))
		{
			return true ;
		}
		int  ch = getch();
		if(ch == KEY_MOUSE && (getmouse(&event) == OK ))
		{
			int x=(event.x- tv->STARTX)/(tv->WIDTH);
			int y=(event.y- tv->STARTY)/(tv->HEIGHT);

			if ( ( event.bstate & BUTTON1_PRESSED) )
			{
				if ( (-1<x && x<(tv->COL) ) && (-1<y && y<(tv->ROW) ))
				{ 
					if (ArrX!=-2 && Input_str.length()!=0 )
					{
						int TN=atoi(Input_str.c_str());
						if (Input_str.length()==1)
						{
							Input_str+=" ";
						}
						int  attr = COLOR_PAIR(6) ;   attron(attr);
						mvaddstr(NowY,NowX,Input_str.c_str());
						if ((tv->Arry[ArrX][ArrY]).Find==TN)
						{
							(tv->Arry[ArrX][ArrY]).P=false ;
						}
						Input_str="";
						refresh();
						attroff(attr);

					}

					if ((tv->Arry[x][y]).Open)
					{
						ArrX=x; ArrY=y;
						NowX=tv->STARTX+x*tv->WIDTH+deltax;
						NowY=tv->STARTY+y*tv->HEIGHT+deltay;
						move(NowY,NowX);
					}

				}
			}
		}
		else if (ch == 'q')
		{
			return false ;
			break ;
		}
		else if (ch == 'n')
		{
			return true ;
		}
		else if (ch == 'r')
		{
			tv->level--;
			return true ;
		}    
		else if  (ch == 'f')
		{
			tv->level-=2 ;
			if (tv->level<0)
			{
				tv->level=0;
			}
			return true ;
		}
		else if  (ch == 'k' || ch == 'K' )
		{
			int  attr = COLOR_PAIR(4) ;   attron(attr);
			for (int i = 0; i <(tv->COL); i++)
			{
				for (int j = 0; j <(tv->ROW); j++)
				{
					if ((tv->Arry[i][j].P))
					{
						int   Pvalue=(tv->Arry[i][j].Find) ;
						if (Pvalue>9)
						{
							mvprintw(tv->STARTY+j*tv->HEIGHT+deltay,tv->STARTX+i*tv->WIDTH+deltax, "%d",Pvalue);
						}
						else
						{
							string BB=Int2Str(Pvalue)+" ";
							mvaddstr(tv->STARTY+j*tv->HEIGHT+deltay,tv->STARTX+i*tv->WIDTH+deltax,BB.c_str());
						}
					}
				}

			}
			attroff(attr);
			return true ;
		}

		else if (  ArrX<0 || ArrX >=(tv->COL) || ArrY<0 || ArrY>=(tv->ROW) )
		{
			continue ;
		}
		else if ( ch == KEY_ENTER || ch == '\012' || ch == '\015' )
		{
			int TN=atoi(Input_str.c_str());
			if (Input_str.length()==1)
			{
				Input_str+=" ";
			}
			int  attr = COLOR_PAIR(2) ;   attron(attr);
			mvaddstr(NowY,NowX,Input_str.c_str());
			if ((tv->Arry[ArrX][ArrY]).Find==TN)
			{
				(tv->Arry[ArrX][ArrY]).P=false ;
			}

			Input_str="";
			move(endy+2,endx+2);
			refresh();
			attroff(attr);
			NowX=-2; NowY=-2;
			ArrX=-2; ArrY=-2;
		}
		else if ( ch >47 && ch<58 )
		{
			if (Input_str.length()<2)
			{
				Input_str+=ch;           
				int  attr = COLOR_PAIR(6) ;   attron(attr);
				mvaddstr(NowY,NowX,Input_str.c_str());
				refresh();
				attroff(attr);
			}
		}
		else if ( ch == KEY_BACKSPACE)
		{
			int Length=Input_str.length();
			int  attr = COLOR_PAIR(6) ;   attron(attr);
			if (Length==0)
			{
				move(NowY,NowX);
				continue ;
			}
			else if (Length==1)
			{
				Input_str="";
				mvaddstr(NowY,NowX," ");
				move(NowY,NowX);                
			}
			else
			{
				string aa=Input_str.substr(0,Length-1);
				Input_str=aa;
				aa=aa+" ";
				mvaddstr(NowY,NowX,aa.c_str());
				move(NowY,NowX+Length-1);
			}
			refresh();
			attroff(attr);
		}
	}
	return true ;
}

int Sudoku_tv_Run (FindMine * tv )
{

	while(true)    
	{
		tv->WIDTH=6 ;
		tv->HEIGHT=4;
		tv->ROW= (2*tv->level)+1 ;
		tv->COL= tv->ROW ;

		int XY=(tv->ROW)*(tv->COL) ;
		int Space_Count=XY/2;

		if (tv->level>3)
		{
			tv->WIDTH=5;
			tv->HEIGHT=3;
			tv->ROW= 9  ; 
			tv->COL= 9 ;
			XY=81  ;
			Space_Count=40+((tv->level)-4);
		}

		(tv->Count)=(tv->ROW) ;

		int    deltay = tv->HEIGHT / 2;
		int    deltax = tv->WIDTH  / 2;


		tv->STARTY = (tv->mrow - tv->ROW * tv->HEIGHT) / 2 ;
		tv->STARTX = (tv->mcol - tv->COL * tv->WIDTH) / 2 ;

		tv->Arry = new Mine *[(tv->COL)];
		tv->Arry[0] = new Mine[XY];

		for(int i = 1; i <(tv->COL); i++)
		{
			tv->Arry[i] = tv->Arry[i-1]+(tv->ROW);
		}

		magic(tv);

		srand((unsigned)time(NULL));
		int Rand=rand()%4;
		for(int i=0 ; i<Rand ; i++ )
		{
			circumrotate(tv);
		}

		Sudoku_tv_Draw(tv);

		int  attr = COLOR_PAIR(5) ;
		attron(attr);
		int BB=0;
		while(true)
		{
			int ii=rand()%(tv->COL);
			int jj=rand()%(tv->ROW);
			if (!(tv->Arry[ii][jj].P))
			{
				BB++;
				(tv->Arry[ii][jj].P)=true;
				(tv->Arry[ii][jj].Open)=true;
				if (BB==Space_Count)
				{
					break ;
				}
			}
		}


		for (int i = 0; i <(tv->COL); i++)
		{
			for (int j = 0; j <(tv->ROW); j++)
			{
				if (!(tv->Arry[i][j].P))
				{
					int   Pvalue=(tv->Arry[i][j].Find) ;
					mvprintw(tv->STARTY+j*tv->HEIGHT+deltay,tv->STARTX+i*tv->WIDTH+deltax, "%d",Pvalue);
				}
			}
		}

		attroff(attr);

		refresh() ;  

		time_t start_time = time(NULL);
		if (Sudoku_tv_Pair(tv))
		{
			tv->level++;
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;

			time_t end_time=time(NULL);
			int Time=int(end_time - start_time);
			string time="Used Time : "+Int2Str(Time);
			mvaddstr(tv->mrow/2-3,tv->mcol/2,time.c_str());
			mvaddstr(tv->mrow/2+1,tv->mcol/2,"AnyKey Continue");
			getch();
			getch();
			refresh();
			beep(); 
			flash();
		}
		else
		{
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;    
			int B=COLOR_PAIR(6); attron(B);
			mvaddstr(tv->mrow/2,tv->mcol/2,"Sudoku Game Over");
			mvaddstr(tv->mrow/2+2,tv->mcol/2,"Enter 'y' : Repeat");
			mvaddstr(tv->mrow/2+4,tv->mcol/2,"Enter 'q' : Leave");
			mvaddstr(tv->mrow/2+6,tv->mcol/2,"Welcome Again");
			mvaddstr(tv->mrow/2+8,tv->mcol/2,"hewm@genomics.org.cn");
			attroff(B);
			refresh();
			return 1 ;
		}
	}
	return 1;
}


int Game_Sudoku_main(int argc, char** argv)
{
	bool Game_Repeat=true ;
	int level=1;
	while(true)
	{
		FindMine  *game=new FindMine ;
		FindMine_tv_Init(game) ;
		curs_set(1);

		game->level=level;
		Sudoku_tv_Run(game);
		level=game->level;

		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		endwin();
		delete game ;
		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // SudokuGame_H_



#include <cstdio>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <signal.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "Tetris.h"
using namespace std;


// 清除屏幕
#define CLEAR()  printf("\033[2J")

// 上移光标
#define MOVEUP(x) printf("\033[%dA", (x))
// 下移光标
#define MOVEDOWN(x) printf("\033[%dB", (x))
// 左移光标
#define MOVELEFT(y) printf("\033[%dD", (y))
// 右移光标
#define MOVERIGHT(y) printf("\033[%dC",(y))

// 定位光标
#define MOVETO(x,y) printf("\033[%d;%dH", (x), (y))
// 光标复位
#define RESET_CURSOR() printf("\033[H")

// 隐藏光标
#define	HIDE_CURSOR() printf("\033[?25l")
// 显示光标
#define	SHOW_CURSOR() printf("\033[?25h")

// 画背景
#define DRAW_BLANK()  printf("\033[1;31;40m%s\033[0m",". " )
// 画阻挡
#define DRAW_BLOCK() printf("\033[7m\033[1;37;40m%s\033[0m", "[]" )
// 画活动方块
#define DRAW_ACTIVE_BLOCK() printf("\033[7m\033[1;%d;40m%s\033[0m",m_curcolor, "[]" )
// 画边界
#define DRAW_BORDER()  printf("\033[1;33;43m%s\033[0m", "||" )
// 随机获得一种颜色
#define GET_COLOR() (rand()%6 + 31)

const int Tetris::HEIGHT;
const int Tetris::WIDTH;
const int Tetris::SIZE;
const unsigned short Tetris::STYLE_MAX;
Tetris::Block Tetris::styles[STYLE_MAX][4];
const unsigned short Tetris::MAXLEVEL;
const unsigned short Tetris::bonus[5] = {0, 100, 300, 600, 1000};
const unsigned int Tetris::levels[MAXLEVEL+1] = {0, 200, 600, 1200, 2000, 3000, 4200,5600, 7200, 9000};
//const unsigned int Tetris::levels[MAXLEVEL+1] = {0, 2000, 6000, 12000, 20000, 30000, 42000,56000, 72000, 90000};

const unsigned short Tetris::_styles_[STYLE_MAX][4] = {
	{0x000f, 0x4444, 0x000f, 0x4444},
	{0x004e, 0x0464, 0x00e4, 0x04c4},
	{0x0462, 0x006c, 0x0462, 0x006c},
	{0x0264, 0x00c6, 0x0264, 0x00c6},
	{0x0622, 0x0017, 0x0223, 0x0074},
	{0x0644, 0x00e2, 0x044c, 0x008e},
	{0x0066, 0x0066, 0x0066, 0x0066},
};

int  AioHandler(int sig, siginfo_t *info, void * context) ;

unsigned short Tetris::GetLevel(unsigned int m_score )
{
	int low = 0, high = MAXLEVEL;
	int mid;

	while ( true )
	{
		mid = (low + high ) / 2;

		if ( m_score >= levels[mid])
		{
			if ( mid==MAXLEVEL || m_score < levels[mid+1])
				return mid;
			else
				low = mid + 1;
		}
		else//不可能是mid等级 
		{
			assert(mid>0);
			high = mid - 1;
		}
	}
}

Tetris::Tetris() : m_score(0), m_level(0), m_active(false), m_pause(false)
{
	memset(&m_cb, 0, sizeof(m_cb));
	InitStyles();
	InitBackground();
	HIDE_CURSOR();
	IF=1;
}

Tetris::~Tetris()
{
	SHOW_CURSOR();
}

void Tetris::InitStyles()
{
	for ( int i=0; i<STYLE_MAX; ++i)
	{
		for ( int j=0; j<4; ++j)
		{
			styles[i][j] = _styles_[i][j];
		}
	}
}

void Tetris::InitBackground()
{
	for ( int i=0; i<HEIGHT; ++i)
		for( int j=0; j<WIDTH; ++j)
		{
			if ( i==0 || j==0 || i==HEIGHT-1 || j==WIDTH-1)
				m_board[i][j] = TYPE_BORDER;
			else
				m_board[i][j] = TYPE_BLANK;
		}
}
void Tetris::Paint(int srcx, int dstx)
{
	if ( dstx > HEIGHT )
		dstx = HEIGHT-1;

	int m_curx = this->m_curx, m_cury = this->m_cury;

	for ( int i=srcx; i<dstx; ++i)
	{
		for ( int j=0; j<WIDTH; ++j)
		{
			if ( m_board[i][j] == TYPE_BORDER )
			{
				DRAW_BORDER();
				continue;
			}

			if ( m_active && i>=m_curx && i<m_curx+4 && j>=m_cury && j<m_cury+4 )
			{
				if ( m_board[i][j] == TYPE_BLANK && m_activeBlock[(i-m_curx)*4 + j-m_cury] == TYPE_BLANK )
					DRAW_BLANK();
				else 
					DRAW_ACTIVE_BLOCK();
			}
			else
			{
				if ( m_board[i][j] == TYPE_BLOCK )
					DRAW_BLOCK();
				else
					DRAW_BLANK();
			}
		}
		printf("\n");
	}
}

void Tetris::DrawScore()
{
	MOVETO(2, 2*WIDTH+2);
	printf("\033[7m\033[1;33;46m");
	printf("   hewm@genomics.org.cn  \n");
	printf("\033[7m\033[1;33;46m");
	printf("    SCORE: ");
	printf("\033[1;37;40m %-8u", m_score);
	printf("\033[0m");
}

void Tetris::DrawLevel()
{
	MOVETO(6, 2*WIDTH+2);

	printf("\033[7m\033[1;34;43m");
	printf("    LEVEL: ");
	printf("\033[1;31;42m %-8u", m_level+1);	//不显等级0
	printf("\033[0m");
}

void Tetris::DrawNext()
{
	MOVETO(11, 2*WIDTH+2);
	printf("\033[1;34;43m\tNEXT:\033[0m");
	MOVELEFT(5);
	MOVEDOWN(2);

	for ( int i=0; i<16; ++i)
	{
		if ( m_nextBlock[i] )
			DRAW_BLOCK();
		else
			DRAW_BLANK();

		if ( (i+1)%4 == 0 )
		{
			MOVELEFT(8);
			MOVEDOWN(1);
		}
	}


	MOVETO(19, 2*WIDTH+2);
	printf("\033[7m\033[1;36;48m");
	printf ("'a','s','d','w' :  for Move\n");
	MOVETO(20, 2*WIDTH+2);
	//    printf("\033[7m\033[1;36;48m");
	printf ("'p' for Stop; 'q' for leave\n");
	MOVETO(21, 2*WIDTH+2);
	//    printf("\033[7m\033[1;36;48m");
	printf ("arrow  for Move; Space fast\n");

}

bool Tetris::overgame()
{
	if (IF==0)
	{
		return true ;
	}
	else
	{
		int m_curx = this->m_curx, m_cury = this->m_cury;
		for ( int i=m_curx; i<m_curx+4; ++i)
			for ( int j=m_cury; j<m_cury+4; ++j)
				if ( m_board[i][j] && m_activeBlock[(i-m_curx) * 4 + j-m_cury]) 
					return true;

		return false;
	}
}

bool Tetris::IsCollide()
{
	int m_curx = this->m_curx, m_cury = this->m_cury;
	for ( int i=m_curx; i<m_curx+4; ++i)
		for ( int j=m_cury; j<m_cury+4; ++j)
			if ( m_board[i][j] && m_activeBlock[(i-m_curx) * 4 + j-m_cury]) 
				return true;

	return false;
}

bool Tetris::IsEmptyLine(int line)
{
	for ( int j=1; j<WIDTH-1; ++j)
		if ( m_board[line][j] != TYPE_BLANK )
			return false;
	return true;
}

int Tetris::RemoveLines()
{
	int nLines = 0 ;
	bool full;

	for ( int i=HEIGHT-2; i>0; --i)
	{
		full = true;
		for ( int j=1; j<WIDTH-1; ++j)
			if ( m_board[i][j] == TYPE_BLANK )
			{
				full = false;
				break;
			}

		if ( full )
		{
			++nLines;
			int k, m;
			for ( k=i-1; k>0 && !IsEmptyLine(k); --k)
				for ( m=1; m<WIDTH-1; ++m)
					m_board[k+1][m] = m_board[k][m];
			// 消行了，k行一定为空
			assert ( k>=0 && IsEmptyLine(k) );
			for ( m=1; m<WIDTH-1; ++m)
				m_board[k+1][m] = TYPE_BLANK;

			++i;
		}
	}

	return nLines;
}

void Tetris::Run()
{
	sigset_t mask;
	sigemptyset(&mask);
	sigaddset(&mask, SIGRTMAX);
	int ret = pthread_sigmask(SIG_BLOCK, &mask, NULL);
	assert( ret==0 && "pthread_mask failed!");

	struct sigaction st;
	sigemptyset(&st.sa_mask);
	st.sa_flags = SA_SIGINFO;    
	st.sa_handler = reinterpret_cast<void (*)(int)>(AioHandler);

	//    printf ("%d",sigaction(SIGRTMAX, &st, NULL)); 
	//MSleep(950);

	sigaction(SIGRTMAX, &st, NULL) ;	
	//    */
	//    printf ( st.sa_handle) ;
	//	if ( sigaction(SIGRTMAX, &st, NULL) == 1 )     {    return ;  }
	//printf ("%d",sigaction(SIGRTMAX, &st, NULL)); return  ;

	m_cb.aio_fildes = STDIN_FILENO;
	m_cb.aio_offset = 0;
	m_cb.aio_buf = m_inputBuf;
	m_cb.aio_nbytes = 16;
	m_cb.aio_sigevent.sigev_notify = SIGEV_SIGNAL;
	m_cb.aio_sigevent.sigev_signo = SIGRTMAX;
	m_cb.aio_sigevent.sigev_value.sival_ptr = (void *)this;

	ret = aio_read(&m_cb);
	assert ( ret==0 && "aio_read error!!!");

	CLEAR();
	RESET_CURSOR();
	Paint();
	DrawScore();
	DrawLevel();

	//预先产生一个方块
	int next = rand()%7;
	m_nextBlock = styles[next][0];

	unsigned int interval = 550;

	while ( true )
	{
		MSleep(interval);

		if ( m_pause )
			continue;

		if ( !m_active ) 
		{
			m_activeBlock = m_nextBlock;
			m_curstyle = next;
			m_curcolor = GET_COLOR();
			m_active = true;
			m_curpos = 0;

			next = rand()%7;
			m_nextBlock = styles[next][0];
			//画下一个方块
			DrawNext();
			m_curx = 1;
			m_cury = WIDTH/2 - 2;
			//          if ( IsCollide( ) )
			if (overgame())
			{
				return; //GAME OVER
			}
			MOVETO(m_curx+1, 0);
			Paint(m_curx, m_curx+4);
		}
		else
		{
			++m_curx;
			//            if ( !IsCollide() )
			if (!overgame())            
			{
				MOVETO(m_curx, 0);
				Paint(m_curx-1, m_curx+4 );
			}
			else
			{
				--m_curx;
				for ( int i=m_curx; i<m_curx+4; ++i)
					for( int j=m_cury; j<m_cury+4; ++j)
					{
						if ( m_activeBlock[(i-m_curx)*4 + j-m_cury] )
							m_board[i][j] = TYPE_BLOCK;
					}
				m_active = false;
				m_activeBlock = 0;
				//判断是否得分
				int n = RemoveLines();
				if ( n != 0 )
				{
					m_score += bonus[n];
					DrawScore();

					int newlevel = GetLevel(m_score);
					if ( newlevel > this->m_level)
					{
						this->m_level = newlevel;
						DrawLevel();
						interval = 550 - this->m_level * 50;
						if ( interval < 120 )
							interval = 120;
					}
					MOVETO(2,0);
					Paint(1, m_curx+4);
				}
				else
				{
					MOVETO(m_curx+1, 0);
					Paint(m_curx, m_curx+4 );
				}
			}
		}
	}
	return;
}

int  AioHandler(int sig, siginfo_t *info, void * context)
{
	Tetris * game = (Tetris *)info->si_value.sival_ptr;
	struct aiocb *pcb = &(game->m_cb);
	assert( !aio_error(pcb) && "aio_handler error" );

	int nbytes = aio_return(pcb);

	int nread = -1;

	enum
	{
		INVALID = -1,
		ESC = 27,
		QUOTE = 91,
	} dirFlag = INVALID;

	enum
	{
		UP = 0,
		DOWN,
		LEFT,
		RIGHT,
		SPACE,
		P,
		STOP,
	} operations[16];
	int idx = -1;

	if ( !game->m_active)
		goto end;

	// translate and store the operations
	while ( ++nread < nbytes  )
	{
		int ch = game->m_inputBuf[nread];
		switch(ch)
		{
			case ESC:
				if ( dirFlag == INVALID )
					dirFlag = ESC;
				break;

			case QUOTE:
				if ( dirFlag == ESC )
					dirFlag = QUOTE;
				break;
				///*//
			case 'q':
			case 'Q': 
			case 3: 
				operations[++idx] = STOP ;
				break ;
				////*///

			case 'a':
			case 68: // left may be D
				if ( ch == 68 )
				{
					if ( dirFlag == QUOTE )
						operations[++idx] = LEFT;
					else
						operations[++idx] = RIGHT; // just D
				}
				else if ( ch == 'a' || ch == 'A')
					operations[++idx] = LEFT;
				break;

			case 's':
			case 'S':
			case 66: // down
				if ( ch == 66 && dirFlag == QUOTE )
					operations[++idx] = DOWN;
				else if ( ch == 's' || ch == 's')
					operations[++idx] = DOWN;
				break;

			case 'd':
			case 67: // right
				if ( ch == 67 && dirFlag == QUOTE )
					operations[++idx] = RIGHT;
				else if ( ch == 'd' || ch == 'D')
					operations[++idx] = RIGHT;
				break;

			case 'w':
			case 'W': // up
			case 65: // maybe A
				if ( ch == 65 ) 
				{
					if ( dirFlag == QUOTE )
						operations[++idx] = UP;
					else
						operations[++idx] = LEFT; // A
				}
				else
					operations[++idx] = UP;
				break;

			case ' ':
				operations[++idx] = SPACE;
				break;

			case 'p':
			case 'P':
				operations[++idx] = P;
				break;

			default:
				break;
		}
	}

	// do operations
	for ( int i = 0; i <= idx; ++i)
	{
		switch(operations[i])
		{
			case LEFT:
				{
					if ( game-> m_pause )
						break;

					--game->m_cury;
					if ( game->IsCollide() )
						++game->m_cury;
					else
					{
						MOVETO(game->m_curx+1, 0);
						game->Paint(game->m_curx, game->m_curx+4);
					}
				}
				break;

			case DOWN:
				if ( game-> m_pause )
					break;

				++game->m_curx;
				if ( game->IsCollide( ) )
					--game->m_curx;
				else
				{
					MOVETO(game->m_curx, 0 );
					game->Paint(game->m_curx-1, game->m_curx+4 );
					break;
				}
				break;

			case RIGHT: 
				if ( game-> m_pause )
					break;

				++game->m_cury;
				if ( game->IsCollide( ) )
					--game->m_cury;
				else
				{
					MOVETO(game->m_curx+1, 0);
					game->Paint(game->m_curx, game->m_curx+4);
				}
				break;

			case UP:
				{
					if ( game-> m_pause )
						break;

					Tetris::Block saveblock = game->m_activeBlock;
					int savedpos = game->m_curpos;

					game->m_curpos = (game->m_curpos + 1) % 4;
					game->m_activeBlock = game->styles[game->m_curstyle][game->m_curpos];
					if ( game->IsCollide( ) )
					{
						game->m_curpos = savedpos;
						game->m_activeBlock = saveblock;
					}
					else
					{
						MOVETO(game->m_curx+1, 0);
						game->Paint(game->m_curx, game->m_curx+4);
					}
				}
				break;

			case SPACE:
				{
					if ( game-> m_pause )
						break;
					int oldx = game->m_curx;
					// 提高效率，一次移两行
					while ( !game->IsCollide() )
						game->m_curx += 2;

					if ( game->IsCollide() )
					{
						--game->m_curx;
						if ( game->IsCollide() )
							--game->m_curx;
					}

					if ( oldx == game->m_curx )
						break;

					if ( game->m_curx - oldx < 4)
					{
						MOVETO(oldx+1, 0);
						game->Paint(oldx, game->m_curx+4);
					}
					else
					{
						MOVETO(oldx+1, 0);
						game->Paint(oldx, oldx+4);
						MOVETO(game->m_curx+1, 0);
						game->Paint(game->m_curx, game->m_curx+4);
					}
				}
				break;

			case P:
				game->m_pause = !game->m_pause;
				break;
			case STOP:
				game->IF=0;
				//                goto end ;
				return 1 ;  
				break ;

			default:
				break;
		}
	}

end:
	int ret = aio_read(pcb);
	assert ( ret==0 && "aio_read error!!!");

	return  0 ;
}




#ifndef RefGffCDS_H_
#define RefGffCDS_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

using namespace std;
typedef long long  llong ;

int  Gff_CDSSNP_help()
{
	cout <<""
		"\n"
		"\tUsage: VarType -Ref <in.fa> -Gff <in.gff> -SNP <in.raw>\n"
		"\n"
		"\t\t-Ref      <str>   Input Ref fa\n"
		"\t\t-Gff      <str>   Input Ref gff\n"
		"\t\t-SNP      <str>   Input SNP File contact Format\n"
		"\n"
		"\t\t-OutDir   <str>   Output Dir Path [./]\n"
		"\t\t-Format   <str>   SNP Input Form (cns/raw/add_ref)[raw]\n"
		"\t\t-MAllele          Use main Allele as AncestorBase [ref]\n"
		"\t\t-help             show this help\n"
		"\n";
	return 1;
}


char different_base ( char  ref , char  yh ,  map <char,string > SNP_back_Allele ,string & status )
{
	char base=yh;
	string A=& base ;
	status="Hom"; 

	if (A.find_first_of("AaTtCcGg")!=string::npos )
	{
	}
	else if(A.find_first_of("MRWSYK")!=string::npos)
	{
		string BB=SNP_back_Allele[yh];
		status = "Het-one";
		if (BB[0]==ref)
		{
			base=BB[1];
		}
		else if (BB[1]==ref)
		{
			base=BB[0];
		}
		else
		{
			status = "Het-two";
		}
	}
	else
	{
		cerr<<"different_base & hom_het unknown complex character, please check the snp data"<<endl;
	}
	return base;
}


void  convert_codon(string codon, string ref_codon, map <char,string > Allele, int phase ,vector <string> & NewCodon  )
{
	char base = (codon.substr(phase,1))[0];
	string AA=Allele[base];
	int length=AA.size();
	for (int i=0 ; i<length ; i++)
	{
		string new_codon = ref_codon;
		new_codon[phase]=AA[i];
		NewCodon.push_back(new_codon);
	}
}

void Modify_nearby ( string ref_codon , string & yh_codon , int phase )
{

	for (int ii=0; ii<3 ; ii++)
	{
		if (ii == phase )
		{
			continue ;
		}
		else if (yh_codon[ii]!='A'  &&   yh_codon[ii]!='C'  && yh_codon[ii]!='G'  && yh_codon[ii]!='T'  )
		{
			yh_codon[ii]=ref_codon[ii];
		}
	}
}

int Gff_CDS_help01(int argc, char **argv , In3str1v * paraFA04 )
{
	if (argc <=2 ) {Gff_CDSSNP_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "Ref" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "SNP")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			string tmp=argv[i];
			(paraFA04->List).push_back(tmp) ;
		}
		else if (flag  ==  "Format")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			string tmp=argv[i];
			if (tmp == "cns")
			{
				paraFA04->InInt=1;
			}
			else if ( tmp == "raw" ||  tmp == "add_cn")
			{
				paraFA04->InInt=0; 
			}
			else if ( tmp == "genotype" ||  tmp == "add_ref" )
			{
				paraFA04->InInt=2;
			}
		}
		else if (flag  == "MAllele")
		{
			paraFA04->TF=true ;
		}
		else if (flag  == "help")
		{
			Gff_CDSSNP_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() ||  (paraFA04->InStr3).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}

int Gff_CDSSNP_main(int argc, char *argv[])
//int main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	paraFA04->TF=false ;
	if( Gff_CDS_help01(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	map <string,map <string ,bool> > GeneList;
	map <string,map <llong,llong> >  CDSList ;

	igzstream  MRG ((paraFA04->InStr3).c_str(),ifstream::in);
	if(!MRG.good())
	{
		cerr << "open InputFile error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return 0;
	}

	igzstream SNP ((paraFA04->InStr2).c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}
	int linecut= FaCutLine ((paraFA04->InStr1));

	string name = (paraFA04->InStr2).substr((paraFA04->InStr2).rfind('/')==string::npos ?((paraFA04->InStr2)).length():((paraFA04->InStr2)).rfind('/') + 1);
	if (name.empty())
	{
		name=(paraFA04->InStr2);
	}
	name=replace_all(name,".gz","");

	string outpath="./";
	if (!(paraFA04->List).empty())
	{
		outpath=(paraFA04->List)[0];
	}

	string outInfo=outpath+"/"+name+".info.gz";
	string outCDS=outpath+"/"+name+".cds.gz";
	ogzstream OUT ((outInfo).c_str());
	ogzstream CDS ((outCDS).c_str());

	if((!OUT.good())  || (!CDS.good()) )
	{
		cerr << "open OUT File error: "<<(outInfo)<<"\t"<<outCDS<<endl;
		delete  paraFA04 ; return  0;
	}

	//////// swimming in the sea & flying in the sky /////////////
	while(!MRG.eof())
	{
		string  line ;
		getline(MRG,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr , flag , CDS , ZhengFu ,geneID ;
		llong Start,End ;
		isone>>chr>>flag>>CDS ;
		if (CDS  != "CDS" )  { continue  ; }
		isone>>Start>>End>>flag>>ZhengFu>>flag>>geneID ;
		vector<string> inf;
		vector<string> Temp;
		split(geneID,inf,",;");
		split(inf[0],Temp,"=");
		string GeneID= Temp[Temp.size()-1] ;
		for ( int jk=1;  jk<inf.size() ; jk++)
		{
			vector<string> Temptmp2;
			split(inf[jk],Temptmp2,"=");
			if (Temptmp2[0] == "Parent")
			{
				GeneID= Temptmp2[Temptmp2.size()-1];
			}
		}

		map <string,map <llong,llong> >  :: iterator it=CDSList.find(GeneID);

		if (it == CDSList.end())
		{
			bool A=false ;
			if (ZhengFu == "-")
			{
				A=true;
			}
			map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
			if (X==GeneList.end())
			{
				map <string,bool> First;
				First[GeneID]=A;
				GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
			}
			else
			{
				(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
			}
			map <llong,llong> DD;
			DD[Start]=End ;
			CDSList.insert(map <string,map <llong,llong> > ::value_type(GeneID,DD));
		}
		else
		{
			(it->second).insert(map <llong,llong>  :: value_type(Start,End)) ;
		}
	}

	MRG.close();

	map <string ,char > SNP_Allele ;
	SNP_Allele["AC"]='M'; SNP_Allele["CA"]='M'; SNP_Allele["GT"]='K'; SNP_Allele["TG"]='K';
	SNP_Allele["CT"]='Y'; SNP_Allele["TC"]='Y'; SNP_Allele["AG"]='R'; SNP_Allele["GA"]='R';
	SNP_Allele["AT"]='W'; SNP_Allele["TA"]='W'; SNP_Allele["CG"]='S'; SNP_Allele["GC"]='S';
	SNP_Allele["AA"]='A'; SNP_Allele["TT"]='T'; SNP_Allele["CC"]='C'; SNP_Allele["GG"]='G';
	map <char,string > SNP_back_Allele ;
	SNP_back_Allele['M']="AC";SNP_back_Allele['K']="GT";SNP_back_Allele['Y']="CT";
	SNP_back_Allele['R']="AG";SNP_back_Allele['W']="AT";SNP_back_Allele['S']="CG";
	SNP_back_Allele['C']="C";SNP_back_Allele['G']="G";SNP_back_Allele['T']="T";
	SNP_back_Allele['A']="A"; 
	SNP_back_Allele['V']="ACG"; SNP_back_Allele['H']="ACT";SNP_back_Allele['D']="AGT";
	SNP_back_Allele['B']="CGT";
	SNP_back_Allele['X']="ACGT"; SNP_back_Allele['N']="ACGT";

	map <string,string> CODE ;

	CODE["GCA"]="A"; CODE["GCC"]="A"; CODE["GCG"]="A"; CODE["GCT"]="A";  // #Alanine
	CODE["TGC"]="C"; CODE["TGT"]="C";                                    // #Cysteine
	CODE["GAC"]="D"; CODE["GAT"]="D";                                    // #AsparticAcid
	CODE["GAA"]="E"; CODE["GAG"]="E";                                    // #GlutamicAcid
	CODE["TTC"]="F"; CODE["TTT"]="F";                                    // #Phenylalanine
	CODE["GGA"]="G"; CODE["GGC"]="G"; CODE["GGG"]="G"; CODE["GGT"]="G";  // #Glycine
	CODE["CAC"]="H"; CODE["CAT"]="H";                                    // #Histidine
	CODE["ATA"]="I"; CODE["ATC"]="I"; CODE["ATT"]="I";                   // #Isoleucine
	CODE["AAA"]="K"; CODE["AAG"]="K";                                    // #Lysine
	CODE["CTA"]="L"; CODE["CTC"]="L"; CODE["CTG"]="L"; CODE["CTT"]="L";
	CODE["TTA"]="L"; CODE["TTG"]="L";                                    // #Leucine
	CODE["ATG"]="M";                                                     // #Methionine
	CODE["AAC"]="N"; CODE["AAT"]="N";                                    // #Asparagine
	CODE["CCA"]="P"; CODE["CCC"]="P"; CODE["CCG"]="P"; CODE["CCT"]="P";  // #Proline
	CODE["CAA"]="Q"; CODE["CAG"]="Q";                                    // #Glutamine
	CODE["CGA"]="R"; CODE["CGC"]="R"; CODE["CGG"]="R"; CODE["CGT"]="R";
	CODE["AGA"]="R"; CODE["AGG"]="R";                                    // #Arginine
	CODE["TCA"]="S"; CODE["TCC"]="S"; CODE["TCG"]="S"; CODE["TCT"]="S";
	CODE["AGC"]="S"; CODE["AGT"]="S";                                    // #Serine
	CODE["ACA"]="T"; CODE["ACC"]="T"; CODE["ACG"]="T"; CODE["ACT"]="T";  // #Threonine
	CODE["GTA"]="V"; CODE["GTC"]="V"; CODE["GTG"]="V"; CODE["GTT"]="V";  // #Valine
	CODE["TGG"]="W";                                                     // #Tryptophan
	CODE["TAC"]="Y"; CODE["TAT"]="Y";                                    // #Tyrosine
	CODE["TAA"]="U"; CODE["TAG"]="U"; CODE["TGA"]="U";                   // #Stop
	CODE["NNN"]="X";                                                     // #NA_NA

	int sample_num=0;
	//  map  <string,map <llong,pair <char,char> > > SNPList ;

	map  <string,map <llong,pair <char,string> > > GenotypeList ;

	if ((paraFA04->InInt)==0)
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			string chr ,depth,cp ,allele1 , allele2 ,tmp1;
			llong position ; 
			char ref ,tmp2 ;
			int  NumA,NumB ;
			isone>>chr>>position>>ref>>depth>>cp>>allele1>>allele2>>NumA>>NumB;
			tmp1=allele1+allele2;
			tmp2=SNP_Allele[tmp1];
			if (tmp2 == ref )
			{
				cerr<<"NoSNP at "<<chr<<"\t"<<position<<"\t"<<ref<<endl;
				continue ;
			}
			pair <char,string> temp ;
			string BB=allele1+tmp2;
			if (NumB>NumA)
			{
				BB=allele2+tmp2;
			}
			temp=make_pair(ref,BB);
			map  <string,map <llong,pair <char,string> > >  :: iterator it=GenotypeList.find(chr);
			if (it != GenotypeList.end())
			{
				(it->second).insert(map <llong,pair <char,string> >  :: value_type(position,temp)) ;
			}
			else
			{
				map <llong,pair <char,string> > gene_cds_str;
				gene_cds_str[position]=temp;
				GenotypeList[chr]=gene_cds_str;
			}
		}
	}
	else if ((paraFA04->InInt)==1)
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			string chr ,allele1 ;
			llong position ;
			int Quality ;
			char ref ,tmp2  ;
			isone>>chr>>position>>ref>>tmp2>>Quality>>allele1 ;
			pair <char,string> temp ;
			if (tmp2 == ref )
			{
				cerr<<"NoSNP at "<<chr<<"\t"<<position<<"\t"<<ref<<endl;
				continue ;
			} 
			string BB=allele1+tmp2;
			temp=make_pair(ref,BB);
			map  <string,map <llong,pair <char,string> > >  :: iterator it=GenotypeList.find(chr);
			if (it != GenotypeList.end())
			{
				(it->second).insert(map <llong,pair <char,string> >  :: value_type(position,temp)) ;
			}
			else
			{
				map <llong,pair <char,string> > gene_cds_str;
				gene_cds_str[position]=temp;
				GenotypeList[chr]=gene_cds_str;
			}
		}
	}
	else if ((paraFA04->InInt)==2)
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			string chr ,string_genotype ,tmpp ;
			llong position ; 
			char ref ,tmp2 ;
			isone>>chr>>position>>ref ;
			map <char,int > UUU ;
			while(isone>>tmpp)
			{
				string_genotype+=tmpp;
				if (tmpp!="-" &&  tmpp!="N" )
				{
					string back=SNP_back_Allele[tmpp[0]];
					int CC=back.length();
					if (CC==1)
					{
						UUU[back[0]]+=2;
					}
					else
					{
						for (int kjk=0 ; kjk<CC ; kjk++)
						{
							UUU[back[kjk]]++;
						}
					}
				}
			}

			sample_num=max(sample_num, int(string_genotype.length()));
			char ancestor='N';
			int B=-1 ;
			map <char ,int  > :: iterator itpp ;
			for (itpp=UUU.begin();  itpp!=UUU.end() ;itpp++ )
			{
				if ((itpp->second)>B)
				{
					ancestor=itpp->first;
					B=itpp->second ;
				}
			}
			string_genotype=ancestor+string_genotype ;
			pair <char,string> temp ;            
			temp=make_pair(ref,string_genotype);
			map  <string,map <llong,pair <char,string> > >  :: iterator it=GenotypeList.find(chr);
			if (it != GenotypeList.end())
			{
				(it->second).insert(map <llong,pair <char,string> >  :: value_type(position,temp)) ;
			}
			else
			{
				map <llong,pair <char,string> > gene_cds_str;
				gene_cds_str[position]=temp;
				GenotypeList[chr]=gene_cds_str;
			}
		}
	}

	SNP.close();

	gzFile fp;
	kseq_t *seq;
	int l;

	fp = gzopen((paraFA04->InStr1).c_str(), "r");
	seq = kseq_init(fp);   

	map <char ,char >  Complement;
	Complement['A']='T'; Complement['C']='G';  Complement['T']='A'; Complement['G']='C'; Complement['N']='N';
	Complement['a']='t'; Complement['c']='g';  Complement['t']='a'; Complement['g']='c'; Complement['n']='n';
	Complement['M']='K'; Complement['R']='Y';  Complement['W']='W'; Complement['S']='S'; Complement['Y']='R';
	Complement['K']='M';

	if ((paraFA04->InInt)!=2)
	{

		while ((l = kseq_read(seq)) >= 0)
		{
			string chr=seq->name.s ;
			map <string,map <string,bool> > :: iterator it=GeneList.find(chr);
			if (it != GeneList.end())
			{
				string Ref= seq->seq.s ;
				transform(Ref.begin(),Ref.end(),Ref.begin(), ::toupper ) ;
				map <string,map <llong,pair <char,string> > > :: iterator snpit=GenotypeList.find(chr) ;
				if (snpit==GenotypeList.end())  {  continue ;  }

				map <string,bool> ::iterator  Y ;
				for(  Y=(it->second).begin() ; Y!= (it->second).end(); Y++ )
				{
					bool TF=Y->second;
					map  <string,map <llong,llong> > :: iterator mCDS=CDSList.find(Y->first);
					if  (mCDS==CDSList.end())   {   continue ;      }
					string gene_cds_str , ref_cds_str , axt_cds_str ;
					int mRNA_pos=1 , gene_cds_len=0 ;

					map <llong,llong> :: iterator PUPU ;
					for(  PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
					{
						llong START=(PUPU->first)-1 ;
						int Leng=(PUPU->second)-START;
						gene_cds_str=gene_cds_str+Ref.substr(START,Leng) ;
					}
					char strand='+';
					gene_cds_len=gene_cds_str.length();
					if (TF)
					{
						reverse(gene_cds_str.begin(), gene_cds_str.end());
						for (int i=0 ; i<gene_cds_len ; i++)
						{
							gene_cds_str[i]=Complement[gene_cds_str[i]];
						}
						strand='-';
					}

					transform(gene_cds_str.begin(),gene_cds_str.end(),gene_cds_str.begin(),::toupper) ;
					ref_cds_str = gene_cds_str;
					axt_cds_str = gene_cds_str;
					string ID=(Y->first)+"\t"+(it->first) ;
					Display( gene_cds_str , ID ,  CDS ,linecut  );

					for(  PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
					{
						for (llong kk=(PUPU->first) ; kk<=(PUPU->second)  ; kk++ )
						{
							map <llong,pair <char,string> > :: iterator SNPYY=(snpit->second).find(kk) ;
							if ( SNPYY !=(snpit->second).end())
							{
								string Ref_uc=(Ref.substr(kk-1,1));
								transform(Ref_uc.begin(),Ref_uc.end(),Ref_uc.begin(),::toupper) ;
								char ref_base_1 = Ref_uc[0];
								if ( ref_base_1 != (SNPYY->second).first )
								{
									cerr<<"same thing wrong "<<chr<<" "<<kk<<" "<<ref_base_1<<" "<<(SNPYY->second).first<<endl;
								}
								char SNP_base_1=((SNPYY->second).second)[1] ;
								char SNP_base_2=Complement[SNP_base_1];
								char ref_base_2=Complement[ref_base_1];
								int this_mRNA_pos=mRNA_pos;
								char this_yh_base=SNP_base_1 ;
								char this_ref_base=ref_base_1 ;
								char ancestor_base=((SNPYY->second).second)[0] ;
								if (TF)
								{
									this_mRNA_pos=gene_cds_len - mRNA_pos + 1;
									this_yh_base=SNP_base_2;
									this_ref_base=ref_base_2; 
									ancestor_base=Complement[ancestor_base];
								}
								if (paraFA04->TF)
								{
									ref_cds_str[this_mRNA_pos-1]=ancestor_base ;
								}
								gene_cds_str[this_mRNA_pos-1]=this_yh_base;
								string snp_status ;
								axt_cds_str[this_mRNA_pos-1]=different_base(this_ref_base,this_yh_base,SNP_back_Allele,  snp_status );
								int phase_num = (this_mRNA_pos-1)%3;
								int codon_num = (this_mRNA_pos-1-phase_num)/3 + 1;

								OUT<<chr<<"\t"<<kk<<"\t"<<ref_base_1<<"<->"<<SNP_base_1<<"\t"<<snp_status<<"\t"<<strand<<"\tGene\t";
								string ref_codon =ref_cds_str.substr(this_mRNA_pos-phase_num-1,3);
								string yh_codon =gene_cds_str.substr(this_mRNA_pos-phase_num-1,3);
								 Modify_nearby ( ref_codon , yh_codon  , phase_num );
								if(yh_codon.find_first_of("Nn")!=string::npos)
								{
									cerr<<yh_codon<<" has N, please check"<<chr<<"\t"<<kk<<"\t"<<ref_base_1<<endl;
								}
								string yh_codon1=yh_codon ,yh_codon2=yh_codon ;
								if ( snp_status.find("Het")!=string::npos)
								{
									vector <string>  NewCodon ;
									convert_codon(yh_codon,ref_codon, SNP_back_Allele,phase_num, NewCodon );
									yh_codon1=NewCodon[0];
									yh_codon2=NewCodon[1];
								}

								int  synonymous=0,nonsynonymous = 0;
								OUT<<Y->first<<"\tCDS\t"<<this_mRNA_pos<<":"<<phase_num<<"\t";
								string codon_mutate_str, aa_mutate_str ;
								if (ref_codon != yh_codon1)
								{
									if (CODE[ref_codon] ==  CODE[yh_codon1])
									{
										synonymous += 1;
									}
									else
									{
										nonsynonymous += 1;
									}
									codon_mutate_str += ref_codon+"<->"+yh_codon1+";";
									aa_mutate_str += CODE[ref_codon]+"<->"+CODE[yh_codon1]+";";
								}
								if (ref_codon !=  yh_codon2) 
								{
									if (CODE[ref_codon] == CODE[yh_codon2])
									{
										synonymous += 1;
									}
									else
									{
										nonsynonymous += 1;
									}
									if (yh_codon2 != yh_codon1 )
									{
										codon_mutate_str += ref_codon+"<->"+yh_codon2+";";
										aa_mutate_str += CODE[ref_codon]+"<->"+CODE[yh_codon2]+";";
									}
								}
								OUT<<codon_mutate_str<<"\t"<<aa_mutate_str<<"\t"<<synonymous<<"\t"<<nonsynonymous<<endl;
							}

							mRNA_pos++;
						}

					}

				}
			}
		}



	}

	else 
	{
		int *A =new int [sample_num] ;
		int *B =new int [sample_num] ;
		for (int i=0  ;  i<sample_num ; i++ )
		{
			A[i]=0;B[i]=0;
		}

		while ((l = kseq_read(seq)) >= 0)
		{
			string chr=seq->name.s ;
			map <string,map <string,bool> > :: iterator it=GeneList.find(chr);
			if (it != GeneList.end())
			{
				string Ref= seq->seq.s ;
				map <string,map <llong,pair <char,string> > > :: iterator snpit=GenotypeList.find(chr) ;
				if (snpit==GenotypeList.end())
				{
					continue ;
				}
				map <string,bool> ::iterator  Y ;
				for(  Y=(it->second).begin() ; Y!= (it->second).end(); Y++ )
				{
					bool TF=Y->second;
					map  <string,map <llong,llong> > :: iterator mCDS=CDSList.find(Y->first);
					if  (mCDS==CDSList.end())   {   continue ;   }
					string gene_cds_str , ref_cds_str  ;
					int mRNA_pos=1 , gene_cds_len=0 ;

					map <llong,llong> :: iterator PUPU ;
					for( PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
					{
						llong START=(PUPU->first)-1 ;
						int Leng=(PUPU->second)-START;
						gene_cds_str=gene_cds_str+Ref.substr(START,Leng) ;
					}
					char strand='+';
					gene_cds_len=gene_cds_str.length();
					if (TF)
					{
						reverse(gene_cds_str.begin(), gene_cds_str.end());
						for (int i=0 ; i<gene_cds_len ; i++)
						{
							gene_cds_str[i]=Complement[gene_cds_str[i]];
						}
						strand='-';
					}

					transform(gene_cds_str.begin(),gene_cds_str.end(),gene_cds_str.begin(),::toupper);
					ref_cds_str = gene_cds_str;
					string *axt_cds_str =new string [sample_num] ;
					string *samp_cds_str =new string [sample_num] ;

					for (int i=0  ;  i<sample_num ; i++ )
					{
						axt_cds_str[i]=gene_cds_str ;
						samp_cds_str[i]=gene_cds_str ;
					}

					string ID=(Y->first)+"\t"+(it->first) ;
					Display( gene_cds_str , ID ,  CDS ,linecut);
					for(  PUPU=(mCDS->second).begin() ; PUPU!= (mCDS->second).end(); PUPU++ )
					{
						for (llong kk=(PUPU->first) ; kk<=(PUPU->second)  ; kk++ )
						{
							map <llong,pair <char,string> > :: iterator SNPYY=(snpit->second).find(kk);

							if ( SNPYY !=(snpit->second).end())
							{
								string Ref_uc=(Ref.substr(kk-1,1));
								transform(Ref_uc.begin(),Ref_uc.end(),Ref_uc.begin(),::toupper) ;
								char ref_base_1 = Ref_uc[0];

								if ( ref_base_1 != (SNPYY->second).first )
								{
									cerr<<"same thing wrong "<<chr<<" "<<kk<<" "<<ref_base_1<<" "<<(SNPYY->second).first<<endl;
								}
								string Genotype=(SNPYY->second).second ;
								int sample_num=Genotype.length();
								char ref_base_2=Complement[ref_base_1];
								int this_mRNA_pos=mRNA_pos;
								char this_ref_base=ref_base_1 ;
								char ancestor_base=Genotype[0] ;
								if (TF)
								{
									this_mRNA_pos=gene_cds_len - mRNA_pos + 1;
									this_ref_base=ref_base_2; 
									ancestor_base=Complement[ancestor_base];
								}

								if (paraFA04->TF)
								{
									ref_cds_str[this_mRNA_pos-1]=ancestor_base ;
								}

								int phase_num = (this_mRNA_pos-1)%3;
								int codon_num = (this_mRNA_pos-1-phase_num)/3 + 1;
								OUT<<chr<<"\t"<<kk<<"\tGene\t";
								OUT<<Y->first<<"\t"<<strand<<"\tCDS\t"<<this_mRNA_pos<<":"<<phase_num;
								for (int ii=1; ii<sample_num ; ii++)
								{
									int sample=ii-1;
									char SNP_base_1=Genotype[ii];
									if  (SNP_base_1 =='-'  || SNP_base_1 =='N'  || SNP_base_1 =='n' ||SNP_base_1 =='X' )
									{
										OUT<<"\tNNN<->NNN;\tX<->X;\t.";
										continue ;
									}

									char SNP_base_2=Complement[SNP_base_1];
									char this_yh_base=SNP_base_1 ;
									if (TF)
									{
										this_yh_base=SNP_base_2;
									}

									samp_cds_str[sample][this_mRNA_pos-1]=this_yh_base;
									string snp_status ;
									axt_cds_str[sample][this_mRNA_pos-1]=different_base(this_ref_base,this_yh_base,SNP_back_Allele,  snp_status );
									string yh_codon =samp_cds_str[sample].substr(this_mRNA_pos-phase_num-1,3);
									string ref_codon =ref_cds_str.substr(this_mRNA_pos-phase_num-1,3);	
								 	Modify_nearby ( ref_codon , yh_codon  , phase_num );
									if  ( yh_codon==ref_codon )
									{
										OUT<<"\t"+yh_codon+"<->"+ref_codon+";\t"+CODE[ref_codon]+"<->"+CODE[ref_codon]+";\t=";
										continue ;
									}

									if(yh_codon.find_first_of("Nn")!=string::npos)
									{
										cerr<<yh_codon<<" has N, please check"<<chr<<"\t"<<kk<<"\t"<<ref_base_1<<endl;
									}

									string yh_codon1=yh_codon ,yh_codon2=yh_codon ;
									if ( snp_status.find("Het")!=string::npos)
									{
										vector <string>  NewCodon ;
										convert_codon(yh_codon,ref_codon, SNP_back_Allele,phase_num, NewCodon );
										yh_codon1=NewCodon[0];
										yh_codon2=NewCodon[1];
									}

									int  synonymous=0,nonsynonymous = 0;
									string codon_mutate_str, aa_mutate_str ;
									if (ref_codon != yh_codon1)
									{
										if (CODE[ref_codon] ==  CODE[yh_codon1])
										{
											synonymous += 1;
										}
										else
										{
											nonsynonymous += 1;
										}
										codon_mutate_str += ref_codon+"<->"+yh_codon1+";";
										aa_mutate_str += CODE[ref_codon]+"<->"+CODE[yh_codon1]+";";
									}
									if (ref_codon !=  yh_codon2) 
									{
										if (CODE[ref_codon] == CODE[yh_codon2])
										{
											synonymous += 1;
										}
										else
										{
											nonsynonymous += 1;
										}
										if (yh_codon2 != yh_codon1 )
										{
											codon_mutate_str += ref_codon+"<->"+yh_codon2+";";
											aa_mutate_str += CODE[ref_codon]+"<->"+CODE[yh_codon2]+";";
										}
									}
									int Flagsyn=0 ;
									if (synonymous!=0 && nonsynonymous!=0 )
									{
										A[sample]++;B[sample]++;
									}
									else if (synonymous!=0)
									{
										Flagsyn=synonymous ;
										A[sample]++;
									}
									else if (nonsynonymous!=0 )
									{
										Flagsyn=0-nonsynonymous ;
										B[sample]++;
									}
									OUT<<"\t"<<codon_mutate_str<<"\t"<<aa_mutate_str<<"\t"<<Flagsyn;
								}
								OUT<<endl;
							}

							mRNA_pos++;
						}
					}
					delete [] samp_cds_str ;
					delete [] axt_cds_str;

				}
			}
		}
		cout<<"#SampleID\tnonsynonymous\tsynonymous\tratio\n";
		for (int i=0  ;  i<sample_num ; i++ )
		{
			double ratio=0;
			if (A[i]!=0)
			{
				ratio=B[i]*1.0/A[i];
			}
			cout<<i+1<<"\t"<<B[i]<<"\t"<<A[i]<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<ratio<<endl;
		} 
		delete [] B ;
		delete [] A ;
	}

	OUT.close();
	CDS.close();
	kseq_destroy(seq);
	gzclose(fp);
	delete paraFA04 ;
	return 0;
}
#endif // RefGffCDS_H_ //
///////// swimming in the sky and flying in the sea ////////////


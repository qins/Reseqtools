#ifndef RefGffAno_H_
#define RefGffAno_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

using namespace std ;
typedef long long  llong ;

int  Gff_AnoAno_help()
{
	cout <<""
		"\n"
		"\tUsage: AnoVar -Gff <in.gff> -Var <in.snp> -OutPut <out.snp.info>\n"
		"\n"
		"\t\t-Var       <str>   InPut Var File Format (chr pos)\n"
		"\t\t-Gff       <str>   InPut Ref gff\n"
		"\t\t-OutPut    <str>   OutPut after annotation SNP\n"
		"\n"
		"\t\t-PrintNA           Print All Var pos [intergenic]\n"
		"\t\t-help              show this help\n"
		"\n";
	return 1;
}


int Gff_Ano_help01(int argc, char **argv , In3str1v * paraFA04 )
{
	if (argc <=2 ) {Gff_AnoAno_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "OutPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "Var")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  ==  "PrintNA")
		{
			paraFA04->TF=false;
		}
		else if (flag  == "help")
		{
			Gff_AnoAno_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() ||  (paraFA04->InStr3).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(paraFA04->InStr1)=add_Asuffix ( (paraFA04->InStr1) );

	return 1 ;
}

int Gff_SNPAno_main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if( Gff_Ano_help01(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	igzstream  GFF ((paraFA04->InStr3).c_str(),ifstream::in);
	if(!GFF.good())
	{
		cerr << "open InputFile error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return 0;
	}

	igzstream SNP ((paraFA04->InStr2).c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}


	ogzstream OUT (((paraFA04->InStr1)).c_str());

	if(OUT.fail())
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}

	map  <string,map <llong,bool> > SNPList ;
	while(!SNP.eof())
	{
		string  line ;
		getline(SNP,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr ;
		llong position ; 
		isone>>chr>>position  ;
		map  <string,map <llong,bool > >  :: iterator it=SNPList.find(chr);
		if (it != SNPList.end())
		{
			(it->second).insert(map <llong,bool >  :: value_type(position,true)) ;
		}
		else
		{
			map <llong,bool > gene_cds_str;
			gene_cds_str[position]=true;
			SNPList[chr]=gene_cds_str;
		}
	}
	SNP.close();

	map <string,map <string ,bool> > GeneList ;
	map <string,map <llong,llong> >  CDSList ;
	map <string,map <llong,pair <llong,string> > >  RNAList ;
	map <string,map <llong,pair <llong,string> > >  OtherList ;

	while(!GFF.eof())
	{
		string  line ;
		getline(GFF,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr , flag , CDS , ZhengFu ,geneID ;
		llong Start,End ;
		isone>>chr>>flag>>CDS ;

		if ( CDS == "gene"  || CDS == "chromosome" )
		{
			continue;
		}

		isone>>Start>>End>>flag>>ZhengFu>>flag>>geneID;
		vector<string> inf;
		vector<string> Temp;
		split(geneID,inf,";");
		split(inf[0],Temp,"=");
		string GeneID= Temp[Temp.size()-1];

		bool A=false ;
		if (ZhengFu == "-" )
		{
			A=true ;
		}

		pair <llong,string> ID_End;
		ID_End=make_pair(End,CDS);

		if (CDS  == "CDS" )
		{
			map  <string,map <llong,llong> >  :: iterator it=CDSList.find(GeneID);
			if (it == CDSList.end() )
			{
				map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
				if (X==GeneList.end())
				{
					map <string,bool> First;
					First[GeneID]=A;
					GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
				}
				else
				{
					(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
				}
				map <llong,llong> DD;
				DD[Start]=End ;
				CDSList.insert(map <string,map <llong,llong> > ::value_type(GeneID,DD));
			}
			else
			{
				(it->second).insert(map <llong,llong>  :: value_type(Start,End)) ;
			}
		}
		else if ( CDS.find("RNA")!=string::npos)
		{
			map  <string,map <llong,pair <llong,string> > >  :: iterator it=RNAList.find(GeneID);
			if (it == RNAList.end() )
			{
				map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
				if (X==GeneList.end())
				{
					map <string,bool> First;
					First[GeneID]=A;
					GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
				}
				else
				{
					(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
				}
				map <llong,pair <llong,string> > DD;
				DD[Start]=ID_End ;
				RNAList[GeneID]=DD;
				//RNAList.insert(map <string,map <llong,pair <llong, string > > :: value_type(GeneID,DD));
			}
			else
			{
				(it->second).insert(map <llong,pair <llong,string > >  :: value_type(Start,ID_End)) ;
			}
		}
		else
		{
			map  <string,map <llong,pair <llong,string> > >  :: iterator it=OtherList.find(GeneID);
			if (it == OtherList.end() )
			{
				map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
				if (X==GeneList.end())
				{
					map <string,bool> First;
					First[GeneID]=A;
					GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
				}
				else
				{
					(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
				}
				map <llong,pair <llong,string> > DD;
				DD[Start]=ID_End ;
				OtherList[GeneID]=DD;
				//OtherList.insert(map <string,map <llong,pair <llong,string> > ::value_type(GeneID,DD));
			}
			else
			{
				(it->second).insert(map <llong,pair <llong,string> >  :: value_type(Start,ID_End)) ;
			}
		}
	}
	GFF.close();


	map <string,map <string ,bool> > :: iterator X;

	for (X=GeneList.begin(); X!=GeneList.end() ;X++)
	{
		map <string,bool> ::iterator  Y ;
		map  <string,map <llong,bool> > :: iterator SNPX =SNPList.find(X->first) ;
		if ( SNPX!=SNPList.end())
		{
			for(  Y=(X->second).begin() ; Y!= (X->second).end(); Y++ )
			{
				bool TF=Y->second ;
				map  <string,map <llong,llong> > :: iterator mCDS=CDSList.find(Y->first) ;
				if (mCDS==CDSList.end()) { continue ; }
				int size_cds=(mCDS->second).size();
				map <llong,llong> :: iterator ZZ ;
				char A='+';
				int tmp_count=0;
				map <llong,bool>  :: iterator SNPY;
				string info_start="CDS_Start";
				string info_end="CDS_End";

				if (TF)
				{
					A='-';
					info_end="CDS_Start";
					info_start="CDS_End";
				}

				for(ZZ=(mCDS->second).begin() ; ZZ!= (mCDS->second).end(); ZZ++)
				{
					tmp_count++;
					llong kk=(ZZ->first) ;
					llong end=(ZZ->second) ;
					int split=0 ;
					llong Run_start=kk;
					llong Run_end=end;
					if (tmp_count==1)
					{
						for(int i=0 ; i<3 ; i++)
						{
							llong kkkk=kk+i ;
							SNPY= (SNPX->second).find(kkkk);
							if ( SNPY !=(SNPX->second).end())
							{
								OUT<<X->first<<"\t"<<kkkk<<"\t"<<Y->first<<"\t"<<info_start<<"\t"<<A<<endl;
								SNPY->second=false;
							}
						}
						split+=1;
						Run_start=Run_start+3;
					}

					if (tmp_count==size_cds)
					{
						for(int i=0 ; i<3 ; i++)
						{
							llong endkk=end-i;
							SNPY=(SNPX->second).find(endkk);
							if ( SNPY !=(SNPX->second).end())
							{
								OUT<<X->first<<"\t"<<endkk<<"\t"<<Y->first<<"\t"<<info_end<<"\t"<<A<<endl;
								SNPY->second=false;
							}
						}
						split+=4;
						Run_end=Run_end-3;
					}

					for (  ; Run_start<=Run_end; Run_start++ )
					{
						SNPY = (SNPX->second).find(Run_start);
						if ( SNPY!=(SNPX->second).end()  )
						{
							OUT<<(X->first)<<"\t"<<Run_start<<"\t"<<(Y->first)<<"\tCDS"<<"\t"<<A<<endl;
							SNPY->second=false;
						}
					}


					if (split==0)
					{
						for (int i=1 ; i<3 ; i++) 
						{
							llong YYtmp=kk-i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tIntron_Splice"<<"\t"<<A<<endl;
							}
							YYtmp=end+i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tIntron_Splice"<<"\t"<<A<<endl;
							}
						}
					}
					else if (split==1)
					{
						for (int i=1 ; i<3 ; i++) 
						{
							llong YYtmp=end+i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tIntron_Splice"<<"\t"<<A<<endl;
							}
						}
					}
					else if (split==4)
					{
						for (int i=1 ; i<3 ; i++) 
						{
							llong YYtmp=kk-i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tIntron_Splice"<<"\t"<<A<<endl;
							}
						}
					}
				}
			}
		}
	}





	for (X=GeneList.begin(); X!=GeneList.end() ;X++)
	{
		map <string,bool> ::iterator  Y ;
		map  <string,map <llong,bool> > :: iterator SNPX =SNPList.find(X->first) ;
		if ( SNPX!=SNPList.end())
		{
			for(  Y=(X->second).begin() ; Y != (X->second).end(); Y++ )
			{
				bool TF=Y->second;
				map  <string,map <llong,pair <llong,string> > > :: iterator mCDS=RNAList.find(Y->first);
				if (mCDS==RNAList.end()) { continue ; }
				int size_cds=(mCDS->second).size();
				map <llong, pair <llong,string> > :: iterator ZZ ;
				char A='+';
				map <llong,bool>  :: iterator SNPY ;
				if (TF)    {    A='-';  }                
				for(ZZ=(mCDS->second).begin() ; ZZ!= (mCDS->second).end(); ZZ++ )
				{
					llong kk=(ZZ->first) ;
					llong end=(ZZ->second).first ;
					for (  ; kk<=end; kk++ )
					{
						SNPY = (SNPX->second).find(kk);
						if ( SNPY!=(SNPX->second).end() && (SNPY->second) )
						{
							OUT<<(X->first)<<"\t"<<kk<<"\t"<<(Y->first)<<"\t"<<((ZZ->second).second)<<"\t"<<A<<endl;
							SNPY->second=false;
						}
						else if(SNPY!=(SNPX->second).end() && (!(SNPY->second)) )
						{
							OUT<<(X->first)<<"\t"<<kk<<"\t"<<(Y->first)<<"\t"<<((ZZ->second).second)<<"_CDS\t"<<A<<endl;
						}
					}
				}
			}
		}
	}





	for (X=GeneList.begin(); X!=GeneList.end() ;X++)
	{
		map <string,bool> ::iterator  Y ;
		map  <string,map <llong,bool> > :: iterator SNPX =SNPList.find(X->first) ;
		if (SNPX!=SNPList.end())
		{
			for(Y=(X->second).begin() ; Y!=(X->second).end(); Y++ )
			{
				bool TF=Y->second;
				map  <string,map <llong,pair <llong,string> > > :: iterator mCDS=OtherList.find(Y->first);
				if (mCDS==OtherList.end()) { continue ; }
				int size_cds=(mCDS->second).size();
				map <llong, pair <llong,string> > :: iterator ZZ ;
				char A='+';
				map <llong,bool>  :: iterator SNPY ;
				if (TF)    {    A='-'; }

				for(ZZ=(mCDS->second).begin() ; ZZ!= (mCDS->second).end(); ZZ++ )
				{
					llong kk=(ZZ->first) ;
					llong end=(ZZ->second).first ;
					for (  ; kk<=end; kk++ )
					{
						SNPY = (SNPX->second).find(kk);
						if ( SNPY != (SNPX->second).end() )
						{
							OUT<<(X->first)<<"\t"<<kk<<"\t"<<(Y->first)<<"\t"<<((ZZ->second).second)<<"\t"<<A<<endl ;
							SNPY->second=false;
						}
					}
				}
			}
		}
	}


	if (!(paraFA04->TF))
	{
		map  <string,map <llong,bool> > :: iterator SNPX ;
		for(SNPX=SNPList.begin() ; SNPX!=SNPList.end(); SNPX++)
		{
			map <llong,bool>  :: iterator SNPY ;
			for(SNPY=(SNPX->second).begin() ; SNPY!= (SNPX->second).end(); SNPY++ )
			{
				if ((SNPY->second))
				{
					OUT<<(SNPX->first)<<"\t"<<(SNPY->first)<<"\tNA\tintergenic\t.\t"<<endl;
				}
			}
		}
	}
	OUT.close();






	delete paraFA04 ;
	return 0;
}
#endif // RefGffAno_H_ //
///////// swimming in the sky and flying in the sea ////////////


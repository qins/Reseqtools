#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-21
echo Start Time : 
date
../bin/iTools	CNStools	FilterGeno	-InPut	../Gm01.genotype.gz	-OutPut	./Gm01.genotype	-Miss	0.5	-Het	0.5
../bin/iTools	CNStools	AddRef	-InPut	Gm01.genotype.gz	-Ref	../Soybean/reference_v2/Gm01 -OutPut	Gm01.add_ref
echo End Time : 
date

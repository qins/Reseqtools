#ifndef RefGffAno_H_
#define RefGffAno_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
//#include "../Soap/msort/msort_h.h"

using namespace std ;
typedef long long  llong ;

int  Gff_AnoAno_help()
{
	cout <<""
		"\n"
		"\tUsage: AnoVar -Gff <in.gff> -Var <in.snp> -OutPut <out.snp.info>\n"
		"\n"
		"\t\t-Var       <str>   InPut Var File Format (chr pos)\n"
		"\t\t-Gff       <str>   InPut Ref gff\n"
		"\t\t-OutPut    <str>   OutPut after annotation SNP\n"
		"\n"
		"\t\t-PrintNA           Print All Var pos [intergenic]\n"
		"\t\t-help              show this help\n"
		"\n";
	return 1;
}


int Gff_Ano_help01(int argc, char **argv , In3str1v * paraFA04 )
{
	if (argc <=2 ) {Gff_AnoAno_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "OutPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "Var")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  ==  "PrintNA")
		{
			paraFA04->TF=false;
		}
		else if (flag  == "help")
		{
			Gff_AnoAno_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() ||  (paraFA04->InStr3).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(paraFA04->InStr1)=add_Asuffix ( (paraFA04->InStr1) );

	return 1 ;
}


//int main(int argc, char *argv[])
int Gff_SNPAno_main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if( Gff_Ano_help01(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	igzstream  GFF ((paraFA04->InStr3).c_str(),ifstream::in);
	if(!GFF.good())
	{
		cerr << "open InputFile error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return 0;
	}

	igzstream SNP ((paraFA04->InStr2).c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}
	string OUTtmp1=(paraFA04->InStr1)+".tmp1.gz";
	string OUTtmp2=(paraFA04->InStr1)+".tmp2.gz";
	string OUTtmp3=(paraFA04->InStr1)+".tmp3.gz";

	ogzstream OUT1 (OUTtmp1.c_str());
	ogzstream OUT2 (OUTtmp2.c_str());
	ogzstream OUT  (OUTtmp3.c_str());

	if(OUT.fail())
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}

	map  <string,map <llong,bool> > SNPList ;
	while(!SNP.eof())
	{
		string  line ;
		getline(SNP,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr ;
		llong position ; 
		isone>>chr>>position  ;
		map  <string,map <llong,bool > >  :: iterator it=SNPList.find(chr);
		if (it != SNPList.end())
		{
			(it->second).insert(map <llong,bool >  :: value_type(position,true)) ;
		}
		else
		{
			map <llong,bool > gene_cds_str;
			gene_cds_str[position]=true;
			SNPList[chr]=gene_cds_str;
		}
	}
	SNP.close();

	map <string,map <string ,bool> > GeneList ;
	map <string,map <llong,llong> >  CDSList ;
	map <string,map <llong,pair <llong,string> > >  RNAList ;
	map <string,map <llong,pair <llong,string> > >  OtherList ;

	while(!GFF.eof())
	{
		string  line ;
		getline(GFF,line);
		if (line.length()<=0 || line[0] == '#' )  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr , flag , CDS , ZhengFu ,geneID ;
		llong Start,End ;
		isone>>chr>>flag>>CDS ;

		if ( CDS == "gene"  || CDS == "chromosome"  ||  CDS == "region")
		{
			continue;
		}

		isone>>Start>>End>>flag>>ZhengFu>>flag>>geneID;
		vector<string> inf;
		vector<string> Temp;
		split(geneID,inf,";");
		split(inf[0],Temp,"=");
		string GeneID= Temp[Temp.size()-1];
		for ( int jk=1;  jk<inf.size() ; jk++)
		{
			vector<string> Temptmp2;
			split(inf[jk],Temptmp2,"=");
			if ( (Temptmp2[0] == "Parent")  &&  (CDS != "mRNA") )
			{
				GeneID= Temptmp2[Temptmp2.size()-1];
			}
		}

		bool A=false ;
		if (ZhengFu == "-" )
		{
			A=true ;
		}

		pair <llong,string> ID_End;
		ID_End=make_pair(End,CDS);

		if (CDS  == "CDS" )
		{
			map  <string,map <llong,llong> >  :: iterator it=CDSList.find(GeneID);

			if (it == CDSList.end() )
			{
				map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
				if (X==GeneList.end())
				{
					map <string,bool> First;
					First[GeneID]=A;
					GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
				}
				else
				{
					(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
				}
				map <llong,llong> DD;
				DD[Start]=End ;
				CDSList.insert(map <string,map <llong,llong> > ::value_type(GeneID,DD));
			}
			else
			{
				(it->second).insert(map <llong,llong>  :: value_type(Start,End)) ;
			}
		}
		else if ( CDS.find("RNA")!=string::npos)
		{
			map  <string,map <llong,pair <llong,string> > >  :: iterator it=RNAList.find(GeneID);

			if (it == RNAList.end() )
			{
				map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
				if (X==GeneList.end())
				{
					map <string,bool> First;
					First[GeneID]=A;
					GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
				}
				else
				{
					(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
				}
				map <llong,pair <llong,string> > DD;
				DD[Start]=ID_End ;
				RNAList[GeneID]=DD;
				//RNAList.insert(map <string,map <llong,pair <llong, string > > :: value_type(GeneID,DD));
			}
			else
			{
				(it->second).insert(map <llong,pair <llong,string > >  :: value_type(Start,ID_End)) ;
			}
		}
		else
		{
			map  <string,map <llong,pair <llong,string> > >  :: iterator it=OtherList.find(GeneID);

			if (it == OtherList.end() )
			{
				map <string,map <string ,bool> > :: iterator X =GeneList.find(chr);
				if (X==GeneList.end())
				{
					map <string,bool> First;
					First[GeneID]=A;
					GeneList.insert(map <string,map <string ,bool> > :: value_type(chr,First));
				}
				else
				{
					(X->second).insert(map <string ,bool>  :: value_type(GeneID ,A ));
				}
				map <llong,pair <llong,string> > DD;
				DD[Start]=ID_End ;
				OtherList[GeneID]=DD;
				//OtherList.insert(map <string,map <llong,pair <llong,string> > ::value_type(GeneID,DD));
			}
			else
			{
				(it->second).insert(map <llong,pair <llong,string> >  :: value_type(Start,ID_End)) ;
			}
		}
	}
	GFF.close();


	map <string,map <string ,bool> > :: iterator X;

	for (X=GeneList.begin(); X!=GeneList.end() ;X++)
	{
		map <string,bool> ::iterator  Y ;
		map  <string,map <llong,bool> > :: iterator SNPX =SNPList.find(X->first) ;
		if ( SNPX!=SNPList.end())
		{
			for(  Y=(X->second).begin() ; Y!= (X->second).end(); Y++ )
			{
				bool TF=Y->second ;
				map  <string,map <llong,llong> > :: iterator mCDS=CDSList.find(Y->first) ;
				if (mCDS==CDSList.end()) { continue ; }
				int size_cds=(mCDS->second).size();
				map <llong,llong> :: iterator ZZ ;
				char A='+';
				int tmp_count=0;
				map <llong,bool>  :: iterator SNPY;
				string info_start="CDS_Start";
				string info_end="CDS_End";

				if (TF)
				{
					A='-';
					info_end="CDS_Start";
					info_start="CDS_End";
				}

				for(ZZ=(mCDS->second).begin() ; ZZ!= (mCDS->second).end(); ZZ++)
				{
					tmp_count++;
					llong kk=(ZZ->first) ;
					llong end=(ZZ->second) ;
					int split=0 ;
					llong Run_start=kk;
					llong Run_end=end;
					if (tmp_count==1)
					{
						for(int i=0 ; i<3 ; i++)
						{
							llong kkkk=kk+i ;
							SNPY= (SNPX->second).find(kkkk);
							if ( SNPY !=(SNPX->second).end())
							{
								OUT1<<X->first<<"\t"<<kkkk<<"\t"<<Y->first<<"\t"<<info_start<<"\t"<<A<<endl;
								SNPY->second=false;
							}
						}
						split+=1;
						Run_start=Run_start+3;
					}

					if (tmp_count==size_cds)
					{
						for(int i=0 ; i<3 ; i++)
						{
							llong endkk=end-i;
							SNPY=(SNPX->second).find(endkk);
							if ( SNPY !=(SNPX->second).end())
							{
								OUT1<<X->first<<"\t"<<endkk<<"\t"<<Y->first<<"\t"<<info_end<<"\t"<<A<<endl;
								SNPY->second=false;
							}
						}
						split+=4;
						Run_end=Run_end-3;
					}

					for (  ; Run_start<=Run_end; Run_start++ )
					{
						SNPY = (SNPX->second).find(Run_start);
						if ( SNPY!=(SNPX->second).end()  )
						{
							OUT1<<(X->first)<<"\t"<<Run_start<<"\t"<<(Y->first)<<"\tCDS"<<"\t"<<A<<endl;
							SNPY->second=false;
						}
					}


					if (split==0)
					{
						for (int i=1 ; i<3 ; i++) 
						{
							llong YYtmp=kk-i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT1<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tintron_splice"<<"\t"<<A<<endl;
							}
							YYtmp=end+i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT1<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tintron_splice"<<"\t"<<A<<endl;
							}
						}
					}
					else if (split==1)
					{
						for (int i=1 ; i<3 ; i++) 
						{
							llong YYtmp=end+i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT1<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tintron_splice"<<"\t"<<A<<endl;
							}
						}
					}
					else if (split==4)
					{
						for (int i=1 ; i<3 ; i++) 
						{
							llong YYtmp=kk-i;
							SNPY= (SNPX->second).find(YYtmp);
							if ( SNPY !=(SNPX->second).end() )
							{
								OUT1<<X->first<<"\t"<<YYtmp<<"\t"<<Y->first<<"\tintron_splice"<<"\t"<<A<<endl;
							}
						}
					}
				}
			}
		}
	}





	for (X=GeneList.begin(); X!=GeneList.end() ;X++)
	{
		map <string,bool> ::iterator  Y ;
		map  <string,map <llong,bool> > :: iterator SNPX =SNPList.find(X->first) ;
		if (SNPX!=SNPList.end())
		{
			for(Y=(X->second).begin() ; Y!=(X->second).end(); Y++ )
			{
				bool TF=Y->second;
				map  <string,map <llong,pair <llong,string> > > :: iterator mCDS=OtherList.find(Y->first);
				if (mCDS==OtherList.end()) { continue ; }
				int size_cds=(mCDS->second).size();
				map <llong, pair <llong,string> > :: iterator ZZ ;
				char A='+';
				map <llong,bool>  :: iterator SNPY ;
				if (TF)    {    A='-'; }

				for(ZZ=(mCDS->second).begin() ; ZZ!= (mCDS->second).end(); ZZ++ )
				{
					llong kk=(ZZ->first) ;
					llong end=(ZZ->second).first ;
					for (  ; kk<=end; kk++ )
					{
						SNPY = (SNPX->second).find(kk);
						if ( SNPY != (SNPX->second).end() )
						{
							OUT1<<(X->first)<<"\t"<<kk<<"\t"<<(Y->first)<<"\t"<<((ZZ->second).second)<<"\t"<<A<<endl ;
							SNPY->second=false;
						}
					}
				}
			}
		}
	}




	for (X=GeneList.begin(); X!=GeneList.end() ;X++)
	{
		map <string,bool> ::iterator  Y ;
		map  <string,map <llong,bool> > :: iterator SNPX =SNPList.find(X->first) ;
		if ( SNPX!=SNPList.end())
		{
			for(  Y=(X->second).begin() ; Y != (X->second).end(); Y++ )
			{
				bool TF=Y->second;
				map  <string,map <llong,pair <llong,string> > > :: iterator mCDS=RNAList.find(Y->first);
				if (mCDS==RNAList.end()) { continue ; }
				int size_cds=(mCDS->second).size();
				map <llong, pair <llong,string> > :: iterator ZZ ;
				char A='+';
				map <llong,bool>  :: iterator SNPY ;
				if (TF)    {    A='-';  }                
				for(ZZ=(mCDS->second).begin() ; ZZ!= (mCDS->second).end(); ZZ++ )
				{
					llong kk=(ZZ->first) ;
					llong end=(ZZ->second).first ;
					for (  ; kk<=end; kk++ )
					{
						SNPY = (SNPX->second).find(kk);
						if ( SNPY!=(SNPX->second).end() )
						{
							OUT2<<(X->first)<<"\t"<<kk<<"\t"<<(Y->first)<<"\t"<<((ZZ->second).second)<<"\t"<<A<<endl;
							SNPY->second=false;
						}
					}
				}
			}
		}
	}

	OUT1.close();
	OUT2.close();

	igzstream  INTmp1 (OUTtmp1.c_str(),ifstream::in);
	igzstream  INTmp2 (OUTtmp2.c_str(),ifstream::in);

	map <string,map<llong, string > >  AnoInfo ;
	while(!INTmp1.eof())
	{
		string  line ;
		getline(INTmp1,line);
		if (line.length()<=0)  { continue  ; }
		string chr ,GeneID,Flag ;
		llong position ; 
		char ZengFu;

		istringstream isone (line,istringstream::in);
		isone>>chr>>position>>GeneID>>Flag>>ZengFu ;

		string key1=chr+"\t"+GeneID+"\t"+ZengFu;

		map <string,map<llong, string > >   :: iterator it_key1=AnoInfo.find(key1);

		if ( it_key1 != AnoInfo.end())
		{	
			map<llong, string > :: iterator it_key2=(it_key1->second).find(position);
			if ( it_key2!=(it_key1->second).end())
			{
				(it_key2->second)=(it_key2->second)+"\t"+Flag;
			}
			else
			{
				(it_key1->second).insert(map <llong,string >  :: value_type(position,Flag));
			}
		}
		else
		{
			map <llong, string >  tmpAA;
			tmpAA[position]=Flag;
			AnoInfo.insert(map <string,map<llong, string > >   ::  value_type(key1,tmpAA) );
		}
	}
	INTmp1.close();

	map <string,map<llong, string > > :: iterator key1_it ;

	for (key1_it=AnoInfo.begin(); key1_it!=AnoInfo.end() ;key1_it++)
	{
		map<llong, string > :: iterator key2_it ;
		for (key2_it=(key1_it->second).begin(); key2_it!=(key1_it->second).end() ;key2_it++)
		{
			vector<string> Temp1;
			split(key1_it->first,Temp1," \t");
			vector<string> Temp2;
			split(key2_it->second,Temp2," \t");
			map  <string,bool> hash_Flag;
			for ( int ii_dd=0; ii_dd<Temp2.size() ; ii_dd++)
			{
				hash_Flag[Temp2[ii_dd]]=true;
			}
			if (hash_Flag.find("intron_splice")!=hash_Flag.end())
			{
				map  <string,bool> :: iterator l_it;
				l_it=hash_Flag.find("intron");
				if ( l_it!=hash_Flag.end())
				{
					hash_Flag.erase(l_it);
				}
			}

			map  <string,bool> :: iterator l_it=hash_Flag.begin();
			string Flag_new="";
			for (;l_it!=hash_Flag.end() ; l_it++)
			{
				OUT<<Temp1[0]<<"\t"<<key2_it->first<<"\t"<<Temp1[1]<<"\t"<<Temp1[2]<<"\t"<<l_it->first<<endl;
				if (Flag_new == "")
				{
					Flag_new=l_it->first;
				}
				else
				{
					Flag_new=Flag_new+":"+l_it->first;
				}
			}
			key2_it->second=Flag_new;
		}
	}


	while(!INTmp2.eof())
	{
		string  line ;
		getline(INTmp2,line);
		if (line.length()<=0)  { continue  ;}
		string chr ,GeneID,Flag ;
		llong position; 
		char ZengFu;

		istringstream isone (line,istringstream::in);
		isone>>chr>>position>>GeneID>>Flag>>ZengFu ;

		string key1=chr+"\t"+GeneID+"\t"+ZengFu;

		map <string,map<llong, string > >   :: iterator it_key1=AnoInfo.find(key1);

		if ( it_key1 != AnoInfo.end())
		{	
			map<llong, string > :: iterator it_key2=(it_key1->second).find(position);
			if ( it_key2!=(it_key1->second).end())
			{
				OUT<<chr<<"\t"<<position<<"\t"<<GeneID<<"\t"<<ZengFu<<"\t"<<Flag<<"_"<<it_key2->second<<endl;
			}
			else
			{
				OUT<<chr<<"\t"<<position<<"\t"<<GeneID<<"\t"<<ZengFu<<"\t"<<Flag<<endl;
			}
		}
		else
		{

			OUT<<chr<<"\t"<<position<<"\t"<<GeneID<<"\t"<<ZengFu<<"\t"<<Flag<<endl;
		}
	}
	INTmp2.close();


	if (!(paraFA04->TF))
	{
		map  <string,map <llong,bool> > :: iterator SNPX;
		for(SNPX=SNPList.begin() ; SNPX!=SNPList.end(); SNPX++)
		{
			map <llong,bool>  :: iterator SNPY ;
			for(SNPY=(SNPX->second).begin() ; SNPY!= (SNPX->second).end(); SNPY++ )
			{
				if ((SNPY->second))
				{
					OUT<<(SNPX->first)<<"\t"<<(SNPY->first)<<"\tNA\t.\tintergenic"<<endl;
				}
			}
		}
	}
	OUT.close();

	string  RM1="rm -rf "+OUTtmp1;		system(RM1.c_str());
	string  RM2="rm -rf "+OUTtmp2;		system(RM2.c_str());
	char * A=const_cast<char*> ((paraFA04->InStr1).c_str());
	char * B = const_cast<char*>((OUTtmp3).c_str());
	char * ssTmp[6]={"msort", "-k1", "-kn2 " ,B,"-o", A  };
	msort_main(6,ssTmp);
	string  RM3="rm -rf  "+OUTtmp3;   system(RM3.c_str());	
	delete paraFA04 ;
	return 0;
}
#endif // RefGffAno_H_ //
///////// swimming in the sky and flying in the sea ////////////


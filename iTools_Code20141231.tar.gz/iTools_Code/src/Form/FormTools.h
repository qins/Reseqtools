#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"

#include "soap2sam.h"
#include "xam2soap.h"
#include "Alg2Fq.h"
#include "Fq2Fa.h"
#include "Fa2Fq.h"
#include "gtf2gff.h"
#include "gff2gtf.h"
#include "maq2sam.h"
#include "VCF2Genotype.h"
#include "../FaDeal/CDS2Pep.h"
//KSEQ_INIT(gzFile, gzread)


using namespace std;

int Xam2Soap_main(int argc, char **argv);
int Xam2fq_main(int argc, char **argv);
int soap2sam_main(int argc, char *argv[]) ;
int Form_Fq2Fa_main(int argc, char *argv[]) ;
int FA_CDS2Pep_main(int argc, char *argv[]) ;
int Form_maq2sam_main(int argc, char *argv[]) ;
int GTF2GFF_main(int argc, char *argv[]) ;
int GFF2GTF_main(int argc, char *argv[]) ;
int Form_Fa2Fq_main(int argc, char *argv[]) ;
int VCF2GenotypeSNP_main(int argc, char *argv[]) ;
static int  FormTools_usage ()
{
	cerr<<""
		"\n"
		"\tForm Tools Usage:\n\n"
		"\t\tSoap2Sam     Soap --> Sam Format\n"
		"\t\tXam2Soap     Bam/Sam --> Soap Format\n"
		"\t\tAlg2Fq       Soap/Bam/Sam --> Fq Format\n"
		"\t\tMaq2Sam      Map  --> Sam Format\n"
		"\t\tCDS2Pep      CDS seq --> Pep Format\n"
		"\t\tFq2Fa        Fastq --> Fasta Format\n"
		"\t\tFa2Fq        Fasta --> Fastq Format\n"
		"\t\tGtf2Gff      GTF --> GFF Format\n"
		"\t\tGff2Gtf      GFF --> GTF Format\n"
		"\t\tVCF2Genotype GATK VCF --> Genotype Format\n"
		"\n"
		"\t\tHelp         Show this help\n"
		"\n";
	return 1;
}


int Form_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return FormTools_usage(); }
	else if (strcmp(argv[1], "Soap2Sam") == 0) { return soap2sam_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Xam2Soap") == 0) { return Xam2Soap_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Alg2Fq") == 0) { return   Xam2fq_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Fq2Fa") == 0) { return    Form_Fq2Fa_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Fa2Fq") == 0) { return    Form_Fa2Fq_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "CDS2Pep") == 0) { return  FA_CDS2Pep_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Maq2Sam") == 0) { return  Form_maq2sam_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Gtf2Gff") == 0) { return  GTF2GFF_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Gff2Gtf") == 0) { return  GFF2GTF_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "VCF2Genotype") == 0) { return  VCF2GenotypeSNP_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0)  {  FormTools_usage(); }
	else
	{
		cerr<<"Form Tools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;	
}



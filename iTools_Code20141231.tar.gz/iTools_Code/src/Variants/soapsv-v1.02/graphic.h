//header file graphic.h
#ifndef _SV_GRAPHIC_H_
#define _SV_GRAPHIC_H_
#include "include.h"
#include "common.h"

enum            emType{HISTOGRAM = 0, ARC, CURVE, PT};// HIS:Histogram   ARC:Arc     CURVE:Curve  POINT:Point.

template <class T0, class TI, class T2, class T>
void _drawbody(T0 t00, T0 t01, TI ti, T2 t2, T minX, T maxX, T minY, T maxY, emType type = HISTOGRAM, int bodyColor = 2);

template <class T>
class CGraphic
{
public:
	CGraphic(){m_type = HISTOGRAM;}
	CGraphic(const char* pName, const char* pType = "PNG", emType type = HISTOGRAM);
	~CGraphic();
	
	void 		AddImageItem(T x, T y, COLORREF clr = RGB(0, 0, 255));
	void 		AddImageItem(T*, T*, int, COLORREF clr = RGB(0, 0, 255));
	void		AddImageItem(vector<T>, vector<T>, COLORREF clr = RGB(0, 0, 255));
	void		ChangeType(emType type);
	void 		DrawImage(T x, T y, COLORREF clr = RGB(0, 0, 255));
	void		DrawImage(T*, T*, int, COLORREF clr = RGB(0, 0, 255));
	void		DrawImage(vector<T>, vector<T>, int, COLORREF clr = RGB(0, 0, 255));
	void		SaveImage();
	void 		SetDescription(const char*, bool bAuto = true, int cx = 120, int cy = 50, COLORREF clr = RGB(0, 0, 255));
	void		SetLineWidth(int nSize);
	void 		SetImageSize(int nx, int ny);
	void		SetAnotherSize(int nx, int ny);
	int			Height();
	int			Width();
	T 			MinX(){return m_minX;}
	T			MaxX(){return m_maxX;}
	T			MinY(){return m_minY;}
	T			MaxY(){return m_maxY;}
	emType		GetType(){return m_type;}
	
	struct XY
	{
		T       x;
		T       y;
	};
	typedef vector<XY>      VXY;
	gdImagePtr	m_pImage;
	
private:
	int 		AllocateColor(COLORREF clr);
	bool		Compare(XY a, XY b);
	void 		DrawBody(VXY& vxy, T minX, T maxX, T minY, T maxY);
	void		DrawCoordinate();
	void		DrawText(int, int, COLORREF clr = RGB(0, 0, 255));
	void 		DrawText(bool bColorAuto, COLORREF clr = RGB(0, 0, 255));// Auto arrange text position.
	void 		InitGraphic();
	void		InitCoordinate(T minX, T maxX, T minY, T maxY);
	void		MarkCoordinateArc(T minX, T maxX, T minY, T maxY);
	void		MarkCoordinateHis(T minX, T maxX, T minY, T maxY);
	void		OutputImage();
private:
	gdPoint*	m_pPoints;
	char*		m_pType;
	char* 		m_pName;
	int 		m_backColor;
	int 		m_foreColor;
	int			m_bodyColor;
	int			m_red;	
	
	int 		m_right;// For writing text in image. where text reached bu right.
	int 		m_bottom;// For writing text in image. where text reached by bottom.
	
	int			m_colorCount;
	int			m_nH;
	int			m_nW;

	bool		m_bAuto;	
	bool		m_bSaved;
	bool		m_bCoordinate;
	
	T			m_minX;
	T			m_maxX;
	T			m_minY;
    T			m_maxY;
	
	string		m_strDesc;// Discription of the image.	
	
	emType		m_type;

	map<unsigned long, int>	m_mclr;
	
private:
	friend struct XY;
};

///////////////////////////////////////////////////////////////
///////////////////// global functions ////////////////////////

template <class T0, class TI, class T2, class T>
void _drawbody(T0 t00, T0 t01, TI ti, T2 t2, T minX, T maxX, T minY, T maxY, emType type = HISTOGRAM, int bodyColor = 2)
{
	//	int bodyColor = Allocate(ti, R(clr), G(clr), B(clr));
	int  nH	= ti->Height();
	int  nW = ti->Width();
	int  ncy = (nH - 40)/55;
	int	 ncx = (nW - 40)/75;
	T	 spanX = maxX - minX;
	T	 spanY = maxY - minY;
	T	 spanXY = abs(maxY - minX);

	if(t2 <= 0)
		return;

	if (type == HISTOGRAM)
	{
		for (T2 i=0; i<t2; i++)
		{
			T  t0 = (t00[i]-minX)*ncx*75/spanX + 20;
			T  t1 = nH-(t01[i]-minY)*ncy*55/spanY-20;
			gdImageLine(ti->m_pImage, int(t0), nH-20, int(t0), int(t1), bodyColor);
		}
	}
	else if(type == ARC)
	{
		for (T2 i=0; i<t2; i++)
		{
			T	t0;
			T	t1;
			t0 = (t00[i]-minX>500000)?((t00[i]-minX)*ncx/spanXY)*75+20:((t00[i]-minX)*ncx*75/spanXY)+20;
			t1 = (t01[i]-minX>500000)?((t01[i]-minX)*ncx/spanXY)*75+20:((t01[i]-minX)*ncx*75/spanXY)+20;
			
			int		hei = int(log10(t1-t0)*double(150));
			//if(hei>400) hei = 400;
			gdImageArc(ti->m_pImage, int((t0+t1)/2), nH-20, int(t1-t0), hei, 180, 360, bodyColor);
		}
	}
	else if (type == CURVE)
	{
		if (t2 == 1)
		{
			gdImageSetPixel(ti->m_pImage, (int)t00[0], (int)t01[0], bodyColor);
		}
		else
		{
			for (T2 i=0; i<t2-1; i++)
			{
				gdImageLine(ti->m_pImage, int((t00[i]-minX)*ncx*75/spanX + 20), int(nH-(t01[i]-minY)*ncy*55/spanY-20),
					int((t00[i+1]-minX)*ncx*75/spanX + 20), int(nH-(t01[i+1]-minY)*ncy*55/spanY-20), bodyColor);
			}
		}
	}
}

template <class T>
void Swap(T &a, T &b)
{
	T	temp;
	temp = a;
	a = b;
	b= temp;
}
///////////////////////////////////////////////////////////////
///////////////////////// Member functions ////////////////////
template <class T>
CGraphic<T>::CGraphic(const char* pName, const char* pType /* =  */, emType type /* = HISTOGRAM */)
{
	m_pName = const_cast<char*>(pName);
	m_pType = const_cast<char*>(pType);
	m_pPoints = NULL;
	
	m_type = type;
	
	m_minX = 0;
	m_maxX = 0;
	m_minY = 0;
	m_maxY = 0;
	
	m_right = 120;
	m_bottom = 50;
	
	m_colorCount = 4;
	m_nH = 640;
	m_nW = 840;

	m_bAuto = false;// true=Set text postion and color automatly. 	false=Set by user.
	m_bSaved = false;
	m_bCoordinate = false;
	
	InitGraphic();
}

template <class T>
CGraphic<T>::~CGraphic()
{
	if(m_bSaved) return;
	OutputImage();
	Safe_DeleteVec(m_pPoints);
}

template <class T>
void CGraphic<T>::InitGraphic()
{
	m_pImage		= gdImageCreate(m_nW, m_nH);
	m_backColor 	= gdImageColorAllocate(m_pImage, 255, 255, 255);
	m_foreColor 	= gdImageColorAllocate(m_pImage, 0, 0, 0);
	m_bodyColor 	= gdImageColorAllocate(m_pImage, 0, 0, 255);
	m_red			= gdImageColorAllocate(m_pImage, 255, 0, 0);

	m_mclr[RGB(255, 255, 255)] = m_backColor;
	m_mclr[RGB(0, 0, 0)] = m_foreColor;
	m_mclr[RGB(0, 0, 255)] = m_bodyColor;
	m_mclr[RGB(255, 0, 0)] = m_red;
	
	DrawCoordinate();
}

template <class T>
void CGraphic<T>::ChangeType( emType type )
{
	m_type = type;
}

template <class T>
void CGraphic<T>::OutputImage()
{
	FILE*	p = fopen(m_pName, "wb");
	
	if (strcmp(m_pType, "PNG") == 0 || strcmp(m_pType, "png") == 0 )
	{
		gdImagePng(m_pImage, p);
	} 
	else if(strcmp(m_pType, "JPG") == 0 || strcmp(m_pType, "jpg") == 0 )
	{
		gdImageJpeg(m_pImage, p, -1);
	}
	else if (strcmp(m_pType, "gif") == 0 || strcmp(m_pType, "gif") == 0 )
	{
		gdImageGif(m_pImage, p);
	}
	
	fclose(p);
	
	gdImageDestroy(m_pImage);
}

template <class T>
bool CGraphic<T>::Compare( XY a, XY b )
{
	return a.x < b.x;
}

template <class T>
void CGraphic<T>::DrawBody( VXY& vxy, T minX, T maxX, T minY, T maxY )
{
	
}

template <class T>
void CGraphic<T>::DrawText( int cx, int cy, COLORREF clr /*= RGB(0, 0, 255)*/)
{
	if (m_strDesc.empty())
	{
		return;
	}
	
	int 		textColor = AllocateColor(clr);
	int		pos = m_strDesc.find('\n');
	int		last = 0;
	string str;
	while (pos != -1)
	{
		str = m_strDesc.substr(last, pos-last);
		gdImageString(m_pImage, gdFontGetLarge(), cx, cy, (unsigned char*)const_cast<char*>(str.c_str()), textColor);
		last = pos + 1;
		pos = m_strDesc.find('\n', last);
		cy += (gdFontGetSmall()->h + 2);
	}
	
	str = m_strDesc.substr(last, m_strDesc.length()-last);
	gdImageString(m_pImage, gdFontGetLarge(), cx, cy, (unsigned char*)const_cast<char*>(str.c_str()), textColor);
}

template <class T>
void CGraphic<T>::DrawText(bool bColorAuto, COLORREF clr /*= RGB(0, 0, 255)*/)
{
	int textColor;
	if(bColorAuto)
	{
		textColor = AllocateColor(RGB(rand()%256, rand()%256,rand()%256));
	}
	else 
		textColor = AllocateColor(clr);
	/////////////// write text ///////////////////
	int             pos = m_strDesc.find('\n');
	int             last = 0;
	string str;
	while (pos != -1)
	{
		str = m_strDesc.substr(last, pos-last);
		if( (int(m_right+str.length()*(gdFontGetLarge()->w)) ) >= m_nW)
		{
			m_right = 120;
			m_bottom += (gdFontGetLarge()->h + 2);
		}
		
		//                str = m_strDesc.substr(last, pos-last);
		gdImageString(m_pImage, gdFontGetLarge(), m_right, m_bottom, (unsigned char*)const_cast<char*>(str.c_str()), textColor);
		last = pos + 1;
		pos = m_strDesc.find('\n', last);
		m_right += (str.length()*gdFontGetLarge()->w + 10);
	}
	str = m_strDesc.substr(last, m_strDesc.length()-last);
	if( (int (m_right+str.length()*gdFontGetLarge()->w))>= m_nW)
	{
		m_right = 120;
		m_bottom += (gdFontGetLarge()->h + 2);
	}
	
	//        str = m_strDesc.substr(last, m_strDesc.length()-last);
	gdImageString(m_pImage, gdFontGetLarge(), m_right, m_bottom, (unsigned char*)const_cast<char*>(str.c_str()), textColor);
	
	m_right += (str.length()*gdFontGetLarge()->w + 10);
}

template <class T>
void CGraphic<T>::MarkCoordinateHis( T minX, T maxX, T minY, T maxY )
{
	int  ncy = (m_nH - 40)/55;
	int      ncx = (m_nW - 40)/75;
	T        spanX = maxX - minX;
	T        spanY = maxY - minY;
	
	for (int i=20; i<m_nW - 20; i+=75)
	{//Mark X
		char    mark[20];
		sprintf(mark, "%.2f", float(minX+float((i-20)*spanX)/float(ncx*75)));
		gdImageString(m_pImage, gdFontGetSmall(), i, m_nH-15, (unsigned char*)mark, m_red);
	}
	
	for (int i=20; i<m_nH-20; i+=55)
	{// Mark Y
		if(i == 20)
			continue;
		char    mark[20];
		sprintf(mark, "%.2f", float(minY+float((i-20)*spanY)/float(ncy*55)));
		gdImageString(m_pImage, gdFontGetSmall(), 25, m_nH-i, (unsigned char*)mark, m_red);
	}
	
	char mk[20];
	sprintf(mk, "X : %.2f", (float)spanX/ncx);
	gdImageString(m_pImage, gdFontGetSmall(), 120, 27-gdFontGetSmall()->h, (unsigned char*)mk, m_red);
	
	sprintf(mk, "Y : %.2f", (float)spanY/ncy);
	gdImageString(m_pImage, gdFontGetSmall(), 120, 47-gdFontGetSmall()->h, (unsigned char*)mk, m_red);
}

template <class T>
void CGraphic<T>::MarkCoordinateArc( T minX, T maxX, T minY, T maxY )
{
	int	 ncx = (m_nW - 40)/75;
	T	 spanXY = abs(maxY - minX);
	
	for (int i=20; i<m_nW - 20; i+=75)
	{
		char	mark[20];
		sprintf(mark, "%.2f", float(minX+float((float)spanXY/float(ncx*75))*(i-20)));
		gdImageString(m_pImage, gdFontGetSmall(), i, m_nH-15, (unsigned char*)mark, m_red);
	}
	
	char    mk[20];
	sprintf(mk, "X : %.2f", (float)spanXY/ncx);
	gdImageString(m_pImage, gdFontGetSmall(), 120, 27-gdFontGetSmall()->h, (unsigned char*)mk, m_red);
}

template <class T>
int CGraphic<T>::Width()
{
	return m_nW;
}

template <class T>
int CGraphic<T>::Height()
{
	return m_nH;
}

template <class T>
void CGraphic<T>::AddImageItem( vector<T> vX, vector<T> vY, COLORREF clr /*= RGB(0, 0, 255)*/ )
{
	int bodyColor = AllocateColor(clr);
	_drawbody(vX, vY, this, vX.size(), m_minX, m_maxX, m_minY, m_maxY, m_type, bodyColor);
}

template <class T>
void CGraphic<T>::AddImageItem( T* pX, T* pY, int _size, COLORREF clr /*= RGB(0, 0, 255)*/ )
{
	int bodyColor = AllocateColor(clr);
	_drawbody(pX, pY, this, _size, m_minX, m_maxX, m_minY, m_maxY, m_type, bodyColor);
}

template <class T>
void CGraphic<T>::AddImageItem( T x, T y, COLORREF clr /*= RGB(0, 0, 255)*/ )
{
	int bodyColor = AllocateColor(clr);
	_drawbody(&x, &y, this, 1, m_minX, m_maxX, m_minY, m_maxY, m_type, bodyColor);
}

template <class T>
int CGraphic<T>::AllocateColor(COLORREF clr)
{
	int ncolor;
	if(m_colorCount > 128)
	{
		ncolor = rand()%128;
	}
	else
	{
		if (m_mclr.find(clr) == m_mclr.end())
		{
			ncolor = gdImageColorAllocate(m_pImage, R(clr), G(clr), B(clr));
			m_colorCount++;
		}
		else
			ncolor = m_mclr[clr];
	}
	return ncolor;
}

template <class T>
void CGraphic<T>::SetImageSize( int nx, int ny )
{
	m_nW = nx;
	m_nH = ny;
	
	gdImageDestroy(m_pImage);
	InitGraphic();
}

template <class T>
void CGraphic<T>::SetAnotherSize( int nx, int ny )
{
	m_nW = nx;
	m_nH = ny;
}

template <class T>
void CGraphic<T>::SetLineWidth(int nSize)
{
	if(nSize <= 0)
		nSize = 1;
	gdImageSetThickness(m_pImage, nSize);
}

template <class T>
void CGraphic<T>::SetDescription( const char* desc, bool bAuto /*= true*/, int cx /*= 120*/, int cy /*= 50*/, COLORREF clr /*= RGB(0, 0, 255)*/ )
{// if bAuto is false, cx, cy, clr must be value.
	m_strDesc = desc;
	
	if(bAuto)
		DrawText(false, clr);
	else
		DrawText(cx, cy, clr);
}

//////////////////////////////////////////////////////////////////////////
//DrawImage(...)
template <class T>
void CGraphic<T>::DrawImage( T x, T y, COLORREF clr /*= RGB(0, 0, 255)*/ )
{
	m_minX = m_maxX = x;
	m_minY = m_maxY = y;

	InitCoordinate(m_minX, m_maxX, m_minY, m_maxY);
	int bodyColor = AllocateColor(clr);
	_drawbody(&x, &y, this, 1, m_minX, m_maxX, m_minY, m_maxY, m_type, bodyColor);
}

template <class T>
void CGraphic<T>::DrawImage( vector<T> vX, vector<T> vY, int _size, COLORREF clr /*= RGB(0, 0, 255)*/ )
{
	m_maxX = *(max_element(vX.begin(), vX.end()));
	m_minX = *(min_element(vX.begin(), vX.end()));
	m_maxY = *(max_element(vY.begin(), vY.end()));
	m_minY = *(min_element(vY.begin(), vY.end()));
	
	InitCoordinate(m_minX, m_maxX, m_minY, m_maxY);
	int bodyColor = AllocateColor(clr);
	_drawbody(vX, vY, this, vX.size(), m_minX, m_maxX, m_minY, m_maxY, m_type, bodyColor);
}

template <class T>
void CGraphic<T>::DrawImage( T* pX, T* pY, int _size, COLORREF clr /*= RGB(0, 0, 255)*/ )
{
	m_maxX = *(max_element(pX, pX+_size-1));
	m_minX = *(min_element(pX, pX+_size-1));
	m_maxY = *(max_element(pY, pY+_size-1));
	m_minY = *(min_element(pY, pY+_size-1));
	
	InitCoordinate(m_minX, m_maxX, m_minY, m_maxY);
	int bodyColor = AllocateColor(clr);
	_drawbody(pX, pY, this, _size, m_minX, m_maxX, m_minY, m_maxY, m_type, bodyColor);
}

template <class T>
void CGraphic<T>::InitCoordinate( T minX, T maxX, T minY, T maxY )
{
	if(m_bCoordinate)return;
	if (m_type == ARC)
	{
		MarkCoordinateArc(minX, maxX, minY, maxY);
	}
	else
	{
		MarkCoordinateHis(minX, maxX, minY, maxY);
	}
	m_bCoordinate = true;
}

template <class T>
void CGraphic<T>::DrawCoordinate()
{
	gdImageLine(m_pImage, 20, m_nH-20, m_nW-20, m_nH-20, m_foreColor); // X___
	gdImageLine(m_pImage, 20, m_nH-20, 20, 20, m_foreColor);// Y___
	gdImageLine(m_pImage, 20, 20, 15, 25, m_foreColor);
	gdImageLine(m_pImage, 20, 20, 25, 25, m_foreColor);
	gdImageLine(m_pImage, m_nW-20, m_nH-20, m_nW-25, m_nH-25, m_foreColor);
	gdImageLine(m_pImage, m_nW-20, m_nH-20, m_nW-25, m_nH-15, m_foreColor);
	
	for (int i=20; i<m_nW - 20; i+=75)
	{
		gdImageLine(m_pImage, i, m_nH-20, i, m_nH-25, m_foreColor);// X |
		for (int j=i; (j<i+75 && j<m_nW-40); j+=15)
		{
			gdImageLine(m_pImage, j, m_nH-20, j, m_nH-22, m_foreColor);// X |
		}
	}
	
	for (int i=m_nH-20; i>20; i-=55)
	{
		gdImageLine(m_pImage, 20, i, 25, i, m_foreColor);// Y |
		for (int j=i; (j>i-55 && j>40); j-=11)
		{
			gdImageLine(m_pImage, 20, j, 22, j, m_foreColor);// Y |
		}
	}
	// |_____________________|X
	gdImageLine(m_pImage, 40, 25, 115, 25, m_foreColor);
	gdImageLine(m_pImage, 40, 25, 40, 20, m_foreColor);
	gdImageLine(m_pImage, 115, 25, 115, 20, m_foreColor);

	if(m_type != ARC)
	{// |___________________|Y
		gdImageLine(m_pImage, 60, 45, 115, 45, m_foreColor);
		gdImageLine(m_pImage, 60, 45, 60, 40, m_foreColor);
		gdImageLine(m_pImage, 115, 45, 115, 40, m_foreColor);
	}
}

template <class T>
void CGraphic<T>::SaveImage()
{
	OutputImage();
	Safe_DeleteVec(m_pPoints);

	m_bSaved = true;
}
template class CGraphic<int>;
template class CGraphic<float>;
template class CGraphic<double>;
template class CGraphic<short>;
#endif //_GRAPHIC_H_

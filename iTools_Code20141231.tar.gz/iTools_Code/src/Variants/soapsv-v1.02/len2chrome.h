#ifndef _LEN2CHROME_H_
#define _LEN2CHROME_H_


#include "common.h"
#include "include.h"
#include "main.h"

//////////////////////////////////////////////////////////////////////////

struct ThreadParam
{
	string			sname;
	VString*		pVstr;
};
//////////////////////////////////////////////////////////////////////////


void* __len2chrome_process(void* param);
int	  getfilefromlist( const char* p, VString& vstr );

void  do_soap(igzstream& ifile, VString* pVstr, string& s);
//////////////////////////////////////////////////////////////////////////
map<string, FILE*>		g_mofile;
pthread_mutex_t				mutex_of = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t				mutex_chr = PTHREAD_MUTEX_INITIALIZER;
//////////////////////////////////////////////////////////////////////////
int main_len2chrome(int argc, char* argv[], void* pVoid)
{
#ifdef MODULE
	AfxGetOptions(argc, argv);
#endif
	if (AfxGetValue("-2")!=NULL || AfxGetValue("-3")!=NULL || AfxGetValue("-4")!=NULL)
		return 1;
	int t = time(0);
	cout<<"len2chrome......"<<endl;
	VString&	vstrout = ((global_param*)pVoid)->vstr;
	VString		vfilename;
	char *		pName = AfxGetValue("--i");
	if(pName == NULL)
		return 0;
	if(getfilefromlist(pName, vfilename) == 0)return 0;

	vector<pthread_t>       threadid(vfilename.size());
	vector<ThreadParam>		vtp(vfilename.size());

	char*   pcpu = AfxGetValue("-cpu");
	int	cpu = (pcpu==NULL) ? 4 : atoi(pcpu);

	CThreadManager		threadMgr(cpu);
	threadMgr.SetTimer(2);
	for (size_t i=0; i<vfilename.size(); i++)
	{
		vtp[i].sname	= vfilename[i];
		vtp[i].pVstr	= &vstrout;
 		threadMgr.AddThread(__len2chrome_process, (void*)&vtp[i]);
	}
	threadMgr.Run();

	for (map<string, FILE*>::iterator it=g_mofile.begin(); it!=g_mofile.end(); ++it)
	{
		fclose(it->second);
	}
	g_mofile.clear();
	return 1;
}

void* __len2chrome_process( void* param )
{
	ThreadParam*	pParam = (ThreadParam*)param;
	if (pParam->sname.empty())
		return NULL;

	igzstream	ifile(pParam->sname.c_str());
	string	s;
	char*	pdo = AfxGetValue("-o");
	if (pdo == NULL)
	{
		s = ".";
	}
	else 
	{
		s = pdo;
	}

	do_soap(ifile, pParam->pVstr, s);

	ifile.close();
}

int getfilefromlist( const char* p, VString& vstr )
{
	vstr.clear();
	igzstream		ifile(p);
	if(!ifile.good())return 0;
	string	str;
	while (getline(ifile, str))
	{
		vstr.push_back(str);
	}
	ifile.close();
	return vstr.size();
}

void do_soap(igzstream& ifile, VString* pVstr, string& s)
{
	char* pq = AfxGetValue("-Q");
	int nqual = (pq==NULL) ? 1 : atoi(pq);

	string		str;
	while(getline(ifile, str))
	{
		VString		vstr;
		_table_t::split(str, vstr, '\t');
		if (vstr.size() < 9)continue;
		if(vstr[1].empty())continue;
		if (vstr[7].empty())continue;
		if (g_mofile.find(vstr[7]) == g_mofile.end())
		{
			pthread_mutex_lock(&mutex_chr);
			char	tmp[512];
			sprintf(tmp, "%s/%s.soap", s.c_str(), vstr[7].c_str());
			FILE*	pofile = new FILE;
			pofile = fopen(tmp, "w+");
			if (pofile == NULL)
			{
				cerr<<"Can't open file : "<<tmp<<endl;
				pthread_mutex_unlock(&mutex_chr);
				continue;
			}
			g_mofile[vstr[7]] = pofile;
			fprintf(pofile, "%s\n", str.c_str());
			pVstr->push_back(tmp);
			pthread_mutex_unlock(&mutex_chr);
		}
		else
		{
			pthread_mutex_lock(&mutex_chr);
			fprintf(g_mofile[vstr[7]], "%s\n", str.c_str());
			pthread_mutex_unlock(&mutex_chr);
		}
	}
}

#endif //_LEN2CHROME_H_

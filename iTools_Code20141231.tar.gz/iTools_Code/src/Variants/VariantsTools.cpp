#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../zlib-1.2.5/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "Soapcnv-v1.08/SoapCNV_modify.h"
#include "soapInDel-v1.09/evaluation.h"
#include "SOAPsnp-v1.02/SoapSNPmain.h"
#include "soapsv-v1.02/Var_SV_main.h"
using namespace std;

int Var_SOAPSNP_main(int argc, char * argv[]) ;
int Var_SOAPIndel_main(int argc, char **argv) ;
int Var_SOAPSV_main(int argc, char* argv[]) ;
int Var_SospCNV_main(int argc, char *argv[]);

static int  Variants_usage ()
{
    cerr<<""
        "\n"
        "\tVarTools Usage:\n\n"
        "\t\tsoapSnp        Get consensus sequence\n"
        "\t\tSoapInDel      Get small Indel from soap with '-g'\n"
        "\t\tSoapSV         Get SV base the PE-read insert size\n"
        "\t\tSoapCNV        Get the CopyberNum Variant\n"
        "\n"
        "\t\tHelp           Show this help\n"
        "\n";
    return 1;
}


int main(int argc, char *argv[])
//int Var_Tools_main(int argc, char *argv[])
{
    if (argc < 2) {  return  Variants_usage(); }
    else if (strcmp(argv[1], "SoapSnp") == 0) { return Var_SOAPSNP_main(argc-1, argv+1); }
    else if (strcmp(argv[1], "SoapInDel") == 0) { return Var_SOAPIndel_main(argc-1, argv+1);}
    else if (strcmp(argv[1], "SoapSV") == 0) { return Var_SOAPSV_main(argc-1, argv+1);}
    else if (strcmp(argv[1], "SoapCNV") == 0) { return Var_SospCNV_main(argc-1, argv+1) ; }
    else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0)  { Variants_usage();}
    else
    {
        cerr<<"VarTools [main] unrecognized command "<<argv[1]<<endl;
        return 1;
    }
    return 0;	
}


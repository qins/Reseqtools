#ifndef FQ_Check_H_
#define FQ_Check_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <math.h>
#include "../include/zlib/zlib.h"
#include "FQ_Filter.h"

#define _A 0
#define _C 1
#define _G 2
#define _T 3
#define _N 4
#define MAX_L 512
#define MAX_Q 128
using namespace std;



int  print_usage_FqCheck()
{
	cout <<""
		"\n"
		"Usage:fqcheck  -InFq1 <in.fq>  -OutStat1 <out.stat>  [options]\n"
		"\n"
		"\t\t-InFq1        <str>   File name of InFq1 Input\n"
		"\t\t-OutStat1     <str>   File name of Fq Stat1\n"
		"\n"
		"\t\t-InFq2        <str>   File name of InFq2 Input\n"
		"\t\t-OutStat2     <str>   File name of Fq Stat2\n"
		"\n"
		"\t\t-ShiftQ       <int>   The Phred+33 or Phred+64 [64]\n"
		"\t\t-help                 show this help\n" 
		"\n";
	return 1;
}



int parse_cmd_FqCheck(int argc, char **argv , Para_A24 * para )
{
	if (argc <=4  ) {print_usage_FqCheck();return 0;}

	int err_flag = 0;
	for(int i = 1; i < argc || err_flag; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFq1" || flag  == "r" )
		{
			if(i + 1 == argc) { LogLackArg( flag ) ; return 0;}
			i++;
			para->InFq1=argv[i];
		}
		else if (flag  ==  "InFq2")
		{
			if(i + 1 == argc) { LogLackArg( flag ) ; return 0;}
			i++;
			para->InFq2=argv[i];
		}
		else if (flag  ==  "OutStat1" || flag  == "c" )
		{
			if(i + 1 == argc) { LogLackArg( flag ) ; return 0;}
			i++;
			para->OutFq1=argv[i];
		}
		else if (flag  ==  "OutStat2")
		{
			if(i + 1 == argc) { LogLackArg( flag ) ;return 0;}
			i++;
			para->OutFq2=argv[i];
		}
		else if (flag  ==  "ShiftQ" )
		{
			if(i + 1 == argc) {  LogLackArg( flag ) ; return 0;}
			i++;
			para->LowQint=atoi(argv[i]);
		}
		else if (flag  == "help")
		{
			print_usage_FqCheck();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}

	if ( (para->OutFq1).empty() || (para->InFq1).empty() )
	{
		cerr<< "-InFq1 -OutStat1 lack argument for the must"<<endl;
		return 0;
	}

	if  ((para->OutFq2).empty() &&  (para->InFq2).empty())
	{
		return 1 ;
	}
	else if ( (para->OutFq2).empty() || (para->InFq2).empty() )
	{
		cerr<< "-InFq2 -OutStat2 lack argument for the must"<<endl;
		return 0;
	}
	else
	{
		return  2 ;
	}
}




int RunSingleFq( string InFq, string OutStat,  Para_A24 * para  )
{

	static	long int base[5];//��¼ÿ�ּ��������
	static	long int qual[MAX_Q];//ÿ������ֵ����Ƶ��
	static	long int cycle_qual[MAX_L][MAX_Q];//ÿ��cycle�������ֲ�
	static	long int cycle_base[MAX_L][5];//ÿ��cycle�ļ���ֲ�
	static	double   q_err[MAX_Q];//��¼����Ϊq�ļ���Ĵ�����
	static	double   err = 0.;
	static	long int q20 = 0;
	static	long int q30 = 0;
	static	int read_num = 0 ;

	read_num = 0 ;
	q20 = 0;
	q30 = 0;
	err = 0.0;
	base[0]=0 ; base[1]=0 ; base[2]=0 ; base[3]=0 ; base[4]=0 ;

	for (int i=0 ; i<MAX_Q ; i++)
	{
		qual[i]=0;
		q_err[i]=0;
		for (int j=0 ; j<MAX_L ; j++)
		{
			cycle_qual[j][i]=0;
		}
	}

	for (int j=0 ; j<MAX_L ; j++)
	{
		cycle_base[j][0]=0;
		cycle_base[j][1]=0;
		cycle_base[j][2]=0;
		cycle_base[j][3]=0;
		cycle_base[j][4]=0;
	}

	//�������п��ܵ�����ֵ��err
	for(int q=0;q<MAX_Q;q++) {q_err[q]=1.0/(pow((double)10.0,(double)(q*0.1)));}
	{
		q_err[2]=0.121821900;
		q_err[3]=0.501187233;
		q_err[4]=0.398107170;
		q_err[5]=0.316227766;
		q_err[6]=0.251188643;
		q_err[7]=0.199526232;
		q_err[8]=0.158489319;
		q_err[9]=0.128647300;
		q_err[10]=0.10545720;
		q_err[11]=0.09508237;
		q_err[12]=0.07943282;
		q_err[13]=0.07539894;
		q_err[14]=0.03981071;
		q_err[15]=0.03162277;
		q_err[16]=0.02511886;
		q_err[17]=0.01995262;
		q_err[18]=0.01629471;
		q_err[19]=0.01584893;
		q_err[20]=0.01470216;
		q_err[21]=0.00910940;
		q_err[22]=0.00791782;
		q_err[23]=0.00601007;
		q_err[24]=0.00590479;
		q_err[25]=0.00559080;
		q_err[26]=0.00518726;
		q_err[27]=0.00437646;
		q_err[28]=0.00405721;
		q_err[29]=0.00393885;
		q_err[30]=0.00387256;
		q_err[31]=0.00341158;
		q_err[32]=0.00337891;
		q_err[33]=0.00296104;
		q_err[34]=0.00282249;
		q_err[35]=0.00261006;
		q_err[36]=0.00247926;
		q_err[37]=0.00227605;
		q_err[38]=0.00217025;
		q_err[39]=0.00215136;
		q_err[40]=0.00188753;
	}

	//input file
	char read_id[MAX_L], read_se[MAX_L], qual_id[MAX_L], qual_se[MAX_L];
	int read_len;

	gzFile read_fs;
	read_fs = gzopen (InFq.c_str(), "rb");
	if (read_fs==NULL)
	{
		cerr<<"Cann't open files\t"<<InFq<<endl;
		return 1;
	}

	gzgets(read_fs, read_id, MAX_L);
	gzgets(read_fs, read_se, MAX_L);
	string read = read_se;
	read_len = read.length()-1;
	gzrewind(read_fs);

	//output file
	fstream OUT_FqCheck;
	OUT_FqCheck.open (OutStat.c_str(), ios::out);
	if (OUT_FqCheck==NULL)
	{
		cout<<"Cann't open files\t"<<OutStat<<endl;
		return 1 ;
	}

	while (gzgets (read_fs, read_id, MAX_L)) 
	{
		gzgets (read_fs, read_se, MAX_L);
		gzgets (read_fs, qual_id, MAX_L);
		gzgets (read_fs, qual_se, MAX_L);
		++read_num;
		for (int c=0;c<read_len;c++) 
		{
			switch (read_se[c]) 
			{
				case 'A': ++cycle_base[c][_A];break;
				case 'C': ++cycle_base[c][_C];break;
				case 'G': ++cycle_base[c][_G];break;
				case 'T': ++cycle_base[c][_T];break;
				case 'N': ++cycle_base[c][_N];break;
			}
		}
		for (int c=0;c<read_len;c++) 
		{
			int q = qual_se[c]-(para->LowQint);
			if(q<0) {q=0;}
			++cycle_qual[c][q];
		}
	}
	gzclose(read_fs);

	long base_total = (long) read_len * read_num;
	for(int c=0;c<read_len;c++)
	{
		base[_A]+=cycle_base[c][_A];
		base[_C]+=cycle_base[c][_C];
		base[_G]+=cycle_base[c][_G];
		base[_T]+=cycle_base[c][_T];
		base[_N]+=cycle_base[c][_N];
	}

	for(int c=0;c<read_len;c++)
	{
		for(int q=0;q<=MAX_Q;q++) 
		{
			qual[q]+=cycle_qual[c][q];
		}
	}
	int qMAX=0;
	for(int q=0;q<MAX_Q;q++) 
	{
		if (qual[q]) 
		{
			qMAX=q;
			if (q>=30) q30+=qual[q];
			if (q>=20) q20+=qual[q];
			err+=q_err[q]*qual[q];
		}
	}

	OUT_FqCheck<<" the default quality shift value is: -"<<(para->LowQint)<<", "
		<<read_num<<" sequences, "
		<<base_total<<" total length, Max length:"
		<<read_len<<", average length:"
		<<setiosflags(ios::fixed)<<setprecision(2)<<(double)read_len<<endl;
	OUT_FqCheck<<"Standard deviations at 0.25:  total "<<100*(sqrt(0.25*(double)base_total)/base_total)
		<<"%, per base "<<100*(sqrt(0.25*(double)read_num)/read_num)
		<<"%"<<endl;
	OUT_FqCheck<<"             A     C     G     T     N ";

	for(int q=0;q<=qMAX;q++)
	{
		OUT_FqCheck<<setw(4)<<q<<' ';
	}

	OUT_FqCheck<<endl;
	OUT_FqCheck<<"Total    ";

	for(int b=_A;b<=_N;b++)  
	{
		OUT_FqCheck<<setw(5)<<setiosflags(ios::fixed)<<setprecision(1)<<100*(double)base[b]/base_total<<' ';
	}

	for(int q=0;q<=qMAX;q++) 
	{
		OUT_FqCheck<<setw(4)<<(int)(1000*((double)qual[q]/base_total))<<" ";
	}
	OUT_FqCheck<<endl;

	for(int c=0;c<read_len;c++)	
	{
		OUT_FqCheck<<"base "<<setw(3)<<c+1<<' ';
		for(int b=_A;b<=_N;b++)  {OUT_FqCheck<<setw(5)<<setiosflags(ios::fixed)<<setprecision(1)<<100*(double)cycle_base[c][b]/read_num<<' ';}
		for(int q=0;q<=qMAX;q++)
		{
			OUT_FqCheck<<setw(4)<<(int)(1000*((double)cycle_qual[c][q]/read_num))<<' ';
		}
		OUT_FqCheck<<endl;
	}

	OUT_FqCheck<<endl;
	OUT_FqCheck<<"Error Rate\t%GC\tQ20\tQ30"<<endl;
	OUT_FqCheck.precision(2);
	OUT_FqCheck<<(100.0*err)/(base_total)<<"\t"<<(100.0*(base[_C]+base[_G]))/(base_total-base[_N])<<"\t"<<(100.0*q20)/base_total<<"\t"<<(100.0*q30)/base_total<<endl;
	OUT_FqCheck.close();
	return 0;
}



int FQ_Check_main(int argc, char **argv) 
	//int main (int argc, char *argv[ ])
{

	Para_A24 * para_A24 = new Para_A24;
	para_A24->LowQint=64; 
	if( parse_cmd_FqCheck(argc, argv, para_A24 )==0)
	{
		delete  para_A24 ;
		return 0 ;
	}

	if ( !(para_A24->InFq1).empty() )
	{
		RunSingleFq(  (para_A24->InFq1) , (para_A24->OutFq1) , para_A24  );
	}
	if ( !(para_A24->InFq2).empty() )
	{
		RunSingleFq(  (para_A24->InFq2) , (para_A24->OutFq2) , para_A24  );
	}

	delete  para_A24 ;
	return(0);

}

#endif  // FQ_check_H_


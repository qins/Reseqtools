#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/zlib/zlib.h"
#include <iomanip>
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include "../ALL/rank_sum.cc"
#include "../include/gzstream/gzstream.h"
#ifndef genotype_H_
#define genotype_H_


//KSEQ_AINIT(gzFile, gzread) 
using namespace std;

typedef char Base;
typedef unsigned long long ubit64_t;
typedef long double  LDBL;



class Para_A11 {
	public:
		string InPut ;
		string Ref ;
		string OutPut;
		double HET ;
		char minSeqQ ;
		int haploid ; 
		Para_A11()
		{
			InPut="";
			Ref="";
			OutPut="";
			HET=0.0010 ;
			haploid=0 ;
			minSeqQ='@' ;
		}
};


int  print_usage_A11()
{
	cout <<""
		"\n"
		"\tUsage: genotype -InPut <In.soap> -Ref <Ref.fa> -OutPut <Out.geno>\n"
		"\n"
		"\t\t-InPut     <str>   InPut SortSoap file for Genotype\n"
		"\t\t-Ref       <str>   InPut Ref seq\n"  
		"\t\t-OutPut    <str>   OutPut genotype file\n"
		"\n"                
		"\t\t-MinBaseQ <char>   The minimum Seq base quality ['@']\n"
		"\t\t-HET     <float>   Novel HET prior probability [0.0010]\n"
		"\t\t-Haploid           If the specie is haploid or chrY [diploid]\n"
		"\n" 
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_A11(int argc, char **argv , Para_A11 * para_A11 )
{
	if (argc <=2 ) {print_usage_A11();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A11->InPut=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A11->OutPut=argv[i];
		}
		else if (flag  ==  "MinBaseQ")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A11->minSeqQ=(argv[i][0]) ;
		}
		else if (flag  ==  "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A11->Ref=argv[i];
		}
		else if (flag  == "Haploid")
		{
			para_A11->haploid=1;
		}
		else if (flag  == "help")
		{
			print_usage_A11();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if((para_A11->Ref).empty()||(para_A11->InPut).empty() ||(para_A11->OutPut).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}

	(para_A11->OutPut)=add_Asuffix(para_A11->OutPut) ;

	return 1 ;

}


/*
   int ReadFaSeq (string RefFile , map <string,ubit64_t> & ChrLeng , map <string,string> & Seq)
   {
   gzFile fp;
   kseq_t *seq;
   fp = gzopen(RefFile.c_str(), "r");
   seq = kseq_init(fp);
   int l=0, File_Acount=0 ;
   while ( (l = kseq_read(seq)) >= 0 )
   {
   string chr=seq->name.s;
   ubit64_t length_chr=ubit64_t(seq->seq.l);
   ChrLeng[chr]=length_chr;
   Seq[chr]=(seq->seq.s);
   File_Acount++;
   }
   kseq_destroy(seq);
   gzclose(fp);
   return  File_Acount ;
   }
   *///
///



//////////

int Genotype_Arg(ubit64_t Chr_Length , string ChrSeq ,  string & chr  ,igzstream & IN ,ogzstream & OUT , string & linesoap , Para_A11 * para_A11 )
{
	int WindosL=500000, maxReadLength=200;
	int bin=WindosL+3*maxReadLength;
	int windos_Alen=WindosL;
	int minQ=(para_A11->minSeqQ)+0;


	double *p_rank;
	p_rank=rank_table_gen();
	int *same_qual_count = new int [256];
	double *rank_array = new double [256];
	memset(same_qual_count,0,sizeof(int)*256);
	memset(rank_array,0,sizeof(double)*256);


	//  int windos_Amax=bin-1*maxReadLength ;
	ubit64_t  sliding_Acount=ubit64_t((Chr_Length)/(windos_Alen))+1 ;    
	Site *BaseSite= new Site[bin];
	string  Nowchr ;

	for (ubit64_t  ii = 0 ; ii < sliding_Acount  ; ii++ )
	{   
		ubit64_t Start_Ai=ii*windos_Alen ;
		ubit64_t End_Ai=Start_Ai+windos_Alen ;
		ubit64_t position=Start_Ai ;
		string ID , seq ,Qseq ,ab , zf  ;
		int hit , Read_leng ;

		istringstream isoneA (linesoap,istringstream::in);        
		isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

		while( (!IN.eof()) && position<=End_Ai  &&  Nowchr==chr ) 
		{
			istringstream isone (linesoap,istringstream::in);
			isone >>ID>>seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;
			int Stat_vetor=position - Start_Ai-1 ;
			if (Stat_vetor>windos_Alen) { break ;}
			for(int jj=0 ; jj<Read_leng ; jj++)
			{
				int key_depth= Stat_vetor  + jj  ;
				(BaseSite[key_depth]).Add_Quality (seq[jj],Qseq[jj] ,hit) ;
			}
			getline(IN, linesoap ) ;
		}

		if (End_Ai>(Chr_Length))
		{
			End_Ai=Chr_Length;
		}

		if ((para_A11->haploid)==0)
		{
			for (ubit64_t  Refposi = Start_Ai   ; Refposi < End_Ai ; Refposi++ )
			{
				int ie=Refposi-Start_Ai ;
				char RefBaseSite=ChrSeq[Refposi];
				char AltBase='N';
				int RefNum=((RefBaseSite>>1)&3);
				int Ref_length=0 ,  Alt_length=0 , SumDepth =0 ;
				double MeanHit=25.0 ;
				int AltNum=(BaseSite[ie]).get_Two_allele(RefNum ,AltBase , Ref_length ,Alt_length );
				MeanHit=(BaseSite[ie]).get_mean_hit(SumDepth) ;
				if (Alt_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<RefBaseSite<<"\t"<<SumDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<"N"<<endl; 
				}
				else if (Ref_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<AltBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<endl;
				}
				else
				{
					string FinalBase=(BaseSite[ie]).Genotype_Likelihood(RefNum ,AltNum,Ref_length ,  Alt_length ,minQ , para_A11->HET );
					double  RST=rank_test(BaseSite[ie], p_rank, same_qual_count, rank_array, para_A11->minSeqQ , RefNum,AltNum );
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<FinalBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t"<<setprecision(5)<<RST<<"\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<endl;
				}
				(BaseSite[ie]).Destory_Site();
			}
		}
		else
		{

			for (ubit64_t  Refposi = Start_Ai   ; Refposi < End_Ai ; Refposi++ )
			{
				int ie=Refposi-Start_Ai ;
				char RefBaseSite=ChrSeq[Refposi];
				char AltBase='N';
				int RefNum=((RefBaseSite>>1)&3);
				int Ref_length=0 ,  Alt_length=0 , SumDepth =0 ;
				double MeanHit=25.0 ;
				int AltNum=(BaseSite[ie]).get_Two_allele(RefNum ,AltBase , Ref_length ,Alt_length );
				MeanHit=(BaseSite[ie]).get_mean_hit(SumDepth) ;
				if (Alt_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<RefBaseSite<<"\t"<<SumDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<"N"<<endl; 
				}
				else if (Ref_length==0)
				{
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<AltBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t1.00000\t"<<RefBaseSite<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<endl;
				}
				else
				{
					string FinalBase=(BaseSite[ie]).Genotype_Likelihood(RefNum ,AltNum,Ref_length ,  Alt_length ,minQ );
					double  RST=rank_test(BaseSite[ie], p_rank, same_qual_count, rank_array, para_A11->minSeqQ , RefNum,AltNum );
					OUT<<chr<<"\t"<<Refposi+1<<"\t"<<FinalBase<<"\t"<<SumDepth<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanHit<<"\t"<<setprecision(5)<<RST<<"\t"<<RefBaseSite<<(BaseSite[ie]).get_q(RefNum)<<"\t"<<AltBase<<(BaseSite[ie]).get_q(AltNum)<<endl;
				}
				(BaseSite[ie]).Destory_Site();
			}
		}



		for( int ie=windos_Alen; ie<bin ; ie++ )
		{
			int tmpj=ie-windos_Alen;
			(BaseSite[tmpj]).CopySame((BaseSite[ie]));
			(BaseSite[ie]).Destory_Site();
		}

	} 

	delete [] BaseSite ;
	delete [] same_qual_count ;
	delete [] rank_array ;
	delete p_rank ;
	/// print out ///

	chr=Nowchr ;
	if ( (!IN.eof()) ) 
	{
		return 1 ;
	}
	else
	{
		return 0 ;
	}
}






int Soap_Genotype_main(int argc, char **argv) 
{
	Para_A11 * para_A11 = new Para_A11;
	if (parse_cmd_A11( argc, argv ,  para_A11 ) ==0 )
	{
		delete para_A11 ;
		return 0;
	}

	ogzstream OUT ((para_A11->OutPut).c_str());
	if(!OUT.good())
	{
		cerr << "open InputFile error: "<<(para_A11->OutPut)<<endl;
		return 1;
	}

	map <string,ubit64_t>  ChrLeng ;
	map <string,string>    ChrSeq ;   

	int chrNum=ReadFaSeq (para_A11->Ref , ChrLeng ,ChrSeq );

	igzstream SOAP ((para_A11->InPut).c_str(),ifstream::in);
	if(!SOAP.good())
	{
		cerr << "open InputFile error: "<<(para_A11->InPut)<<endl;
		return 1;
	} 

	string ID , seq ,Qseq ,ab , zf  ,soapline , Nowchr ;
	int hit , Read_leng ;
	ubit64_t position =0;
	getline(SOAP, soapline ) ;

	istringstream isoneA (soapline,istringstream::in);
	isoneA>>ID >> seq >> Qseq >> hit >> ab >> Read_leng >> zf >> Nowchr >> position ;

	///*///
	int run = Genotype_Arg(ChrLeng[Nowchr] , ChrSeq[Nowchr] , Nowchr  ,SOAP , OUT , soapline , para_A11 ) ;
	int tempC=1;
	while(run)
	{
		run = Genotype_Arg(ChrLeng[Nowchr] , ChrSeq[Nowchr] , Nowchr  ,SOAP , OUT , soapline , para_A11 ) ;
		tempC++;
		if (tempC>chrNum) { cerr<<"may Ref chr smaller than soap chr\n" ;}
	}
	////*////


	OUT.close();
	SOAP.close();
	delete para_A11 ;
	return 1 ;
}



//programme entry
///////// swimming in the sky and flying in the sea ////////////
#endif /* genotype_H_  */



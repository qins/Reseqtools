#ifndef  ELS_Eat_H_
#define  ELS_Eat_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include "../include/gzstream/gzstream.h"
#include "../include/gzstream/gzstream.h"
#include "../ALL/comm.h"
#include "../ALL/Thread.h"
#include <ncurses.h>
#include <ctime>

//#define MAX_OPr  255 ;
//#include <sys/select.h>
//#include <stdio.h>
//#include <conio.h>
typedef long long llong ;
using namespace std;
///////////////////

class ELS : public Thread
{
	public:
		int mrow ;
		int mcol ;
		vector <char> operations ;
		//        int Un_oper; 
		int **Arry ;
		int **ArryX ;
		//        WINDOW *whelp ;
		Thread *th1;
		Thread *th2;
		int score ;
		bool m_pause ;
		int leve;
		int P_A, P_S ,P_D, P_W; 
		int Col_Rand, T_X, T_Y;
		int RunX ,RunY ;
		int NextX ,NextY ;
		int NowX, NowY ;
		int model[7][4][4][4] ;
		bool Game_Over ;
		bool  New_one ;
		int Chang;
	public:
		unsigned int sleep_time ;
		int tv_Init();
		bool tv_Draw();
		void get_operations();
		int tv_Destroy();
		void response();
		bool Eat_one();
		int run_operations();
		virtual void run();
		int tv_Run();
		void get_score();
		//   int run () ; 
};

void ELS::get_score()
{
	int tmp_score=0;
	for ( int jj=P_S-1 ; jj>4 ;jj--)
	{
		bool DD=true;
		int A=0;
		for ( int ii=P_A+1; ii<P_D; ii++ )
		{        
			if (Arry[ii][jj]==0)
			{
				DD=false ;
				A++;
			}
		}
		if ( DD )
		{
			tmp_score++;
			score+=tmp_score;
			leve=score/5;
			if (leve<10)
			{
				sleep_time=450-3*leve;
			}
			else if (leve<20)
			{
				sleep_time=420-2*(leve-10);
			}
			else 
			{
				sleep_time=400-1*(leve-20);
			}
			for ( int Kjj=jj ; Kjj>4 ;Kjj--)
			{
				int tdd=Kjj-1;
				for ( int Kii=P_A+1; Kii<P_D; Kii++ )
				{
					Arry[Kii][Kjj]=Arry[Kii][tdd];
				}
			}
			jj++;
		}
	}
}

bool ELS::Eat_one()
{
	if(New_one)
	{
		for(int ii=0 ; ii< 4 ; ii++ )
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+T_X][jj+T_Y]=model[NextX][NextY][ii][jj] ;
				if ( ArryX[ii+T_X][jj+T_Y] * Arry[ii+T_X][jj+T_Y]!=0)
				{
					Game_Over=true ;
					return false ;
				}
			}
		}
		NowX=NextX;
		NowY=NextY;
		NextX=(rand()%7);
		NextY=(rand()%4);
		Col_Rand=(rand()%7);        
		New_one=false;
		RunX=T_X; RunY=T_Y;
	}
	for(int ii=0 ; ii< 4 ; ii++)
	{
		for ( int jj=0 ; jj< 4 ; jj++ )
		{
			ArryX[ii+RunX][jj+RunY]=0 ;
		}
	}
	RunY++;
	bool check =false ;
	for(int ii=0 ; ii< 4 ; ii++)
	{
		for ( int jj=0 ; jj< 4 ; jj++ )
		{
			ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
			if ( ArryX[ii+RunX][jj+RunY] * Arry[ii+RunX][jj+RunY]!=0)
			{
				check=true;
			}
		}
	}
	if (check)
	{
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++)
			{
				ArryX[ii+RunX][jj+RunY]=0;
			}
		}
		RunY--;
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++)
			{
				if (model[NowX][NowY][ii][jj]!=0)
				{
					Arry[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				}
			}
		}
		New_one=true ;
		get_score();
	}
	return true ;
}

void ELS::response()
{
	if ( Chang ==5 )
	{
		bool check=true ;
		while(check)
		{
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++ )
				{
					ArryX[ii+RunX][jj+RunY]=0 ;
				}
			}
			RunY++;
			check =true ;
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++ )
				{
					ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
					if ( (ArryX[ii+RunX][jj+RunY] * Arry[ii+RunX][jj+RunY])!=0 )
					{
						check=false;
					}
				}
			}
		}

		for(int ii=0 ; ii< 4 ; ii++ )
		{
			for ( int jj=0 ; jj< 4 ; jj++)
			{
				ArryX[ii+RunX][jj+RunY]=0 ;
			}
		}
		RunY-- ;
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
			}
		}
	}
	else if (Chang ==2)
	{
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+RunX][jj+RunY]=0 ;
			}
		}
		RunX++;
		bool check =false ;
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++)
			{
				ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				if ( ArryX[ii+RunX][jj+RunY] * Arry[ii+RunX][jj+RunY]!=0)
				{
					check=true;
				}
			}
		}
		if (check)
		{
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++)
				{
					ArryX[ii+RunX][jj+RunY]=0;
				}
			}
			RunX--;
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++)
				{
					ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				}
			}
		}
	}
	else if (Chang ==3)
	{          
		int Ttmp=NowY;
		NowY=(NowY+1)%4;
		bool check =false ;
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++)
			{
				ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				if ( ArryX[ii+RunX][jj+RunY] * Arry[ii+RunX][jj+RunY]!=0 )
				{
					check=true;
				}
			}
		}
		if (check)
		{
			NowY=Ttmp;
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++ )
				{
					ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				}
			}
		}
	}
	else if (Chang ==4)
	{
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+RunX][jj+RunY]=0 ;
			}
		}
		RunY++;
		bool check =false ;
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				if ( ArryX[ii+RunX][jj+RunY] * Arry[ii+RunX][jj+RunY]!=0 )
				{
					check=true;
				}
			}
		}
		if (check)
		{
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++)
				{
					ArryX[ii+RunX][jj+RunY]=0;
				}
			}
			RunY--;
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++ )
				{
					ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				}
			}
		}

	}
	else if (Chang ==1)
	{
		if (RunX-1<0)
		{
			return ;
		}
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+RunX][jj+RunY]=0 ;
			}
		}
		RunX--;
		bool check =false ;
		for(int ii=0 ; ii< 4 ; ii++)
		{
			for ( int jj=0 ; jj< 4 ; jj++ )
			{
				ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				if ( ArryX[ii+RunX][jj+RunY] * Arry[ii+RunX][jj+RunY]!=0 )
				{
					check=true;
				}
			}
		}
		if (check)
		{
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++)
				{
					ArryX[ii+RunX][jj+RunY]=0;
				}
			}
			RunX++;
			for(int ii=0 ; ii< 4 ; ii++)
			{
				for ( int jj=0 ; jj< 4 ; jj++ )
				{
					ArryX[ii+RunX][jj+RunY]=model[NowX][NowY][ii][jj];
				}
			}
		}
	}
	//return 0;
}

void ELS::get_operations()
{
	while(true)
	{
		if (Game_Over) { return ;}
		int c = getch();
		switch (c)
		{
			case 'h':
			case 'H':
			case '?': operations.push_back('h') ; break;
			case '\033':
			case 'Q':
			case 'q': operations.push_back('q') ; break;
			case KEY_LEFT:
			case 'a': operations.push_back('l') ; break;
			case KEY_RIGHT:
			case 'd': operations.push_back('r') ; break;
			case KEY_UP:
			case 'w': operations.push_back('u') ; break;
			case KEY_DOWN:
			case ' ':
			case KEY_F0: operations.push_back('S') ; break;
			case 's': operations.push_back('d') ; break;
			case 'p': 
			case 'P': m_pause=(!m_pause); break;
			case KEY_RESIZE: getmaxyx(stdscr, mrow, mcol); break;
			default: continue;
		}
	}
}

bool ELS::tv_Draw()
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(8); attron(attr);
	mvaddstr(0,(mcol/5),"Welcome come,ELS Game");
	int HelpPosi=40 ;
	mvaddstr(1,HelpPosi,"Love hewm");
	mvaddstr(3,HelpPosi,"Arrows : move");
	mvaddstr(5,HelpPosi,"a,s,w,d: move");
	mvaddstr(7,HelpPosi,"p   : Stop");
	mvaddstr(9,HelpPosi,"q   : leave");
	//P_D=mcol-10;
	attroff(attr);
	attr=0;
	attr = COLOR_PAIR(5);
	attron(attr);
	for(int ii=P_A ; ii< mcol ; ii++ )
	{
		for ( int jj=P_W ; jj< mrow ; jj++ )
		{
			if ( Arry[ii][jj]>0 )
			{
				mvaddch(jj-4,ii,'$');
			}
			else if ( Arry[ii][jj]<0 )
			{
				mvaddch(jj-4,ii,'+') ;
			}
		}
	}
	int timeAA=((sleep_time));    
	string Score="Score  :"+Int2Str(score);
	mvaddstr(15,HelpPosi,Score.c_str());
	Score="speed(time):"+Int2Str(timeAA);
	mvaddstr(17,HelpPosi,Score.c_str());
	Score="Level: "+Int2Str(leve);
	attroff(attr);
	attr=0;
	attr = COLOR_PAIR(Col_Rand);
	attron(attr);
	for(int ii=P_A ; ii< mcol ; ii++ )
	{
		for ( int jj=P_W ; jj< (mrow-1) ; jj++ )
		{
			if ( ArryX[ii][jj]>0 )
			{
				mvaddch(jj-4,ii,'$');
			}
		}
	}
	attroff(attr);
	attr=0;
	attr = COLOR_PAIR(6);
	attron(attr);
	HelpPosi=HelpPosi-15;
	int YY=4 ;
	mvaddstr(9,HelpPosi+3,Score.c_str());
	for(int ii=0 ; ii< 4 ; ii++ )
	{
		for ( int jj=0 ; jj< 4 ; jj++ )
		{
			if (model[NextX][NextY][ii][jj]!=0)
			{
				mvaddch(YY+jj,ii+HelpPosi,'$') ;
			}
		}
	}
	attroff(attr);
	refresh();
	return true;   
}

int ELS::tv_Init()
{
	initscr();keypad(stdscr, TRUE);
	clear();
	noecho();cbreak();
	curs_set(0);
	//    mrow = 18; mcol = 28;
	sleep_time =450 ;
	m_pause=false ;
	New_one=true ;
	Game_Over=false ;
	Col_Rand=3;
	leve=0;
	getmaxyx(stdscr, mrow, mcol) ;
	start_color();
	init_pair(0, COLOR_CYAN, COLOR_GREEN);
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_WHITE, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(6, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_RED, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);

	mrow = 25 ; mcol = 24;

	P_A=4;        P_S=mrow-1 ;
	P_D=mcol-1 ;    P_W=5 ;

	Arry  = new int *[mcol] ;
	Arry[0] = new int[mcol*mrow] ;

	ArryX  = new int *[mcol] ;
	ArryX[0] = new int[mcol*mrow] ;


	for(int i = 1; i < mcol; i++)
	{
		Arry[i] = Arry[i-1]+mrow;
		ArryX[i] = ArryX[i-1]+mrow;
	}

	for (int ii=0 ; ii< mcol ; ii++)
	{
		for (int jj=0 ; jj< mrow ; jj++)
		{
			Arry[ii][jj]=0;
			ArryX[ii][jj]=0;
		}
	}

	srand((unsigned)time(NULL));

	for(int ii=0 ; ii< mrow ; ii++)
	{        
		Arry[P_A][ii]=-1;
		Arry[P_D][ii]=-1;
	}

	for(int ii=0 ; ii < mcol ; ii++)
	{
		//      Arry[ii][P_W]=-1;
		Arry[ii][P_S]=-1;
	}

	T_X=(P_A+P_D)/2 ;
	T_Y=0;
	Chang=0 ;

	int modelD[7][4][4][4]={
		{ // .. 0
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				1,0,0,0,
				1,1,1,0
			},
			{ // .. 1
				0,0,0,0,
				1,1,0,0,
				1,0,0,0,
				1,0,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				1,1,1,0,
				0,0,1,0
			},
			{ // .. 3
				0,0,0,0,
				0,1,0,0,
				0,1,0,0,
				1,1,0,0
			}   
		},

		{ // .. 1
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				0,0,1,0,
				1,1,1,0
			},
			{ // .. 1
				0,0,0,0,
				1,0,0,0,
				1,0,0,0,
				1,1,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				1,1,1,0,
				1,0,0,0
			},
			{ // .. 3
				0,0,0,0,
				1,1,0,0,
				0,1,0,0,
				0,1,0,0
			}   
		},

		{ // .. 2
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				1,1,0,0,
				0,1,1,0
			},
			{ // .. 1
				0,0,0,0,
				0,1,0,0,
				1,1,0,0,
				1,0,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				1,1,0,0,
				0,1,1,0
			},
			{ // .. 3
				0,0,0,0,
				0,1,0,0,
				1,1,0,0,
				1,0,0,0
			}   
		},

		{ // .. 3
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				0,1,1,0,
				1,1,0,0
			},
			{ // .. 1
				0,0,0,0,
				1,0,0,0,
				1,1,0,0,
				0,1,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				0,1,1,0,
				1,1,0,0
			},
			{ // .. 3
				0,0,0,0,
				1,0,0,0,
				1,1,0,0,
				0,1,0,0
			}   
		},

		{ // .. 4
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				1,1,0,0,
				1,1,0,0
			},
			{ // .. 1
				0,0,0,0,
				0,0,0,0,
				1,1,0,0,
				1,1,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				1,1,0,0,
				1,1,0,0
			},
			{ // .. 3
				0,0,0,0,
				0,0,0,0,
				1,1,0,0,
				1,1,0,0
			}   
		},

		{ // .. 5
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				0,1,0,0,
				1,1,1,0
			},
			{ // .. 1
				0,0,0,0,
				1,0,0,0,
				1,1,0,0,
				1,0,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				1,1,1,0,
				0,1,0,0
			},
			{ // .. 3
				0,0,0,0,
				0,1,0,0,
				1,1,0,0,
				0,1,0,0
			}   
		},

		{ // .. 6
			{ // .. 0
				0,0,0,0,
				0,0,0,0,
				0,0,0,0,
				1,1,1,1
			},
			{ // .. 1
				1,0,0,0,
				1,0,0,0,
				1,0,0,0,
				1,0,0,0
			},
			{ // .. 2
				0,0,0,0,
				0,0,0,0,
				0,0,0,0,
				1,1,1,1
			},
			{ // .. 3
				1,0,0,0,
				1,0,0,0,
				1,0,0,0,
				1,0,0,0
			}   
		}
	};


	for (int A_1=0;A_1<7 ; A_1++)
	{
		for (int A_2=0;A_2<4 ; A_2++)
		{
			for (int A_3=0;A_3<4 ; A_3++)
			{
				for (int A_4=0;A_4<4 ; A_4++)
				{
					model[A_1][A_2][A_3][A_4]=modelD[A_1][A_2][A_3][A_4];
				}
			}
		}
	}
	score=0;
	NextX=(rand()%7);
	NextY=(rand()%4);
	tv_Draw();
	mvaddstr(mrow/2,mcol/2-4,"AnyKey Begin ");
	refresh();

	getch();
	return 1 ;
}


int ELS:: tv_Destroy()
{
	delete [] Arry[0] ;
	delete [] Arry ;
	delete [] ArryX[0] ;
	delete [] ArryX ;
	//    delwin(whelp);
	endwin();
	delete th1;
	delete th2;
	return 1;
}

int ELS::run_operations()
{
	while ( Eat_one() )
	{
		tv_Draw();
		usleep(sleep_time* 1000U );
		while(!operations.empty())
		{
			char c=operations[0];
			operations.erase(operations.begin());
			switch (c)
			{
				case 'h': ; break;
				case 'q':  goto End_Flag ; break;
				case 'l':  Chang=1 ;break;
				case 'r':  Chang=2 ; break;
				case 'u':  Chang=3 ; break;
				case 'd':  Chang=4 ; break;
				case 'S':  Chang=5 ; break;
				default: continue;
			}
			while (m_pause)
			{
				usleep(sleep_time*1000U);
				continue ;            
			}
			response();
			Chang=0;
			tv_Draw();
		}        
		while ( m_pause )
		{
			usleep(sleep_time*1000U);
			continue ;
		}
	}
End_Flag :
	int B=0;
	B |= COLOR_PAIR(8); attron(B);
	mvaddstr(mrow/2-2,mcol/2,"ELS Game Over");
	mvaddstr(mrow/2,mcol/2,"Enter 'yy' : Repeat");
	mvaddstr(mrow/2+2,mcol/2,"Enter 'nn' : Leave");
	mvaddstr(mrow/2+4,mcol/2,"Welcome Again");
	mvaddstr(mrow/2+6,mcol/2,"hewm@genomics.org.cn");
	attroff(B);
	refresh();
	Game_Over=true ;
	return 0 ;
}

int  ELS::tv_Run()
{
	th1 = new Thread(this);
	th2 = new Thread(this);
	start();
	th1->start();
	th2->start();
	th1->join();
	th2->join();
	return 1;
}

void ELS::run()
{
	if (Thread::isEquals(th1))
	{
		get_operations();
	}
	else if (Thread::isEquals(th2))
	{
		if(run_operations()==0)
		{
			return  ;
		}
	}
	else
	{
		return ;
	}
}

int Game_ELS_main(int argc, char** argv)
{
	bool Game_Repeat=true ;
	while(true)
	{
		ELS  game ;
		game.tv_Init() ;
		game.tv_Run();        
		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		game.tv_Destroy();
		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // ELS_Eat_H_
//

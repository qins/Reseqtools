
#include <ncurses.h>
#include <string.h>
int main()
{
	char mesg[]="Enter a string: "; /* ...........*/
	char str[80];
	int row,col; /* ...................*/
	initscr();/* ..curses ..*/
	getmaxyx(stdscr,row,col); /* ..stdscr ......*/
	mvprintw(row/2,(col-strlen(mesg))/2,"%s",mesg);  /* ...........mesg */
	scanw("%s",str); /* ...str ........*/
	mvprintw(2,0, "You Entered: %s", str);
	getch();
	endwin();
	return 0;
} 


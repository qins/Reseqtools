#ifndef  Draw_comm_H_
#define  Draw_comm_H_

#include <ncurses.h>        /* stdio.h is also included */ 
#include <stdlib.h>
#include "../ALL/comm.h"

int fill_rectangle(WINDOW *win, int starty, int startx,  int endy, int endx, chtype ch) 
{ 
	if (NULL == win || 
			starty < 0 || starty >= getmaxy(win) || 
			startx < 0 || startx >= getmaxx(win) || 
			endy < 0 || endy >= getmaxy(win) || 
			endx < 0 || endx >= getmaxx(win))     
	{
		return ERR; 
	}
	else
	{ 
		int          i; 
		if (endy < starty) Swap(endy, starty); 
		if (endx < startx) Swap(endx, startx); 
		for (i = starty; i <= endy; ++i) 
			mvwhline(win, i, startx, ch, endx-startx+1); 
		return OK; 
	} 
} 

int Box(WINDOW *win, int starty, int startx, int endy, int endx, int attrs) 
{ 
	if (NULL == win || 
			starty < 0 || starty >= getmaxy(win) || 
			startx < 0 || startx >= getmaxx(win) || 
			endy < 0 || endy >= getmaxy(win) || 
			endx < 0 || endx >= getmaxx(win) || 
			abs(startx - endx) < 2 || abs(starty - endy) < 2) 
		return ERR; 
	else { 
		mvwhline(win, starty, startx+1, ACS_HLINE | attrs, endx-startx-1); 
		mvwhline(win, endy, startx+1, ACS_HLINE | attrs, endx-startx-1); 
		mvwvline(win, starty+1, startx, ACS_VLINE | attrs, endy-starty-1); 
		mvwvline(win, starty+1, endx, ACS_VLINE | attrs, endy-starty-1); 
		mvwaddch(win, starty, startx, ACS_ULCORNER | attrs); 
		mvwaddch(win, starty, endx, ACS_URCORNER | attrs); 
		mvwaddch(win, endy, startx, ACS_LLCORNER | attrs); 
		mvwaddch(win, endy, endx, ACS_LRCORNER | attrs); 
		return OK; 
	} 
} 

int draw_3D_window(WINDOW *win, int starty, int startx, 
		int endy, int endx, int attrs) 
{ 
	if (NULL == win || 
			starty < 0 || starty >= getmaxy(win) - 1 || 
			startx < 0 || startx >= getmaxx(win) - 1 || 
			endy < 0 || endy >= getmaxy(win) - 1|| 
			endx < 0 || endx >= getmaxx(win) - 1) 
		return ERR; 
	else { 
		init_pair(4, COLOR_WHITE, COLOR_BLACK); 
		fill_rectangle(win, starty+1, startx+1, endy+1, endx+1, ' ' | COLOR_PAIR(4)); 
		fill_rectangle(win, starty, startx, endy, endx, ' ' | attrs); 
		return OK; 
	} 
}

void board(WINDOW *win, int starty, int startx, int lines, int cols,int tile_width, int tile_height)
{
	int endy, endx, i, j;

	endy = starty + lines * tile_height;
	endx = startx + cols  * tile_width;
	for( j = starty ; j <= endy; j += tile_height)
	{
		for(i = startx; i <= endx; ++i)
		{
			mvwaddch(win, j, i, ACS_HLINE);
		}
	}
	for(i = startx; i <= endx; i += tile_width)
		for(j = starty; j <= endy; ++j)
			mvwaddch(win, j, i, ACS_VLINE);
	mvwaddch(win, starty, startx, ACS_ULCORNER);
	mvwaddch(win, endy, startx, ACS_LLCORNER);
	mvwaddch(win, starty, endx, ACS_URCORNER);
	mvwaddch(win,   endy, endx, ACS_LRCORNER);
	for(j = starty + tile_height; j <= endy - tile_height; j += tile_height)
	{   mvwaddch(win, j, startx, ACS_LTEE);
		mvwaddch(win, j, endx, ACS_RTEE);
		for(i = startx + tile_width; i <= endx - tile_width; i += tile_width)
			mvwaddch(win, j, i, ACS_PLUS);
	}
	for(i = startx + tile_width; i <= endx - tile_width; i += tile_width)
	{   mvwaddch(win, starty, i, ACS_TTEE);
		mvwaddch(win, endy, i, ACS_BTEE);
	}
	wrefresh(win);
}


#endif // Draw_comm_H_ 



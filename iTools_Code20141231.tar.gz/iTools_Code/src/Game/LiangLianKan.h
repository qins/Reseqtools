#ifndef  LiangLianKan_H_
#define  LiangLianKan_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <ncurses.h>
#include <ctime>
#include "../ALL/comm.h"
#include "Draw_comm.h"

#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/bind.hpp>


typedef long long llong ;
using namespace std;
using namespace boost ;

///////////////////

class LiangLianKan
{
	public:
		int mrow ;
		int mcol ;
		int **Arry ;
		int level ;
		bool Game_Over ;
		int STARTX;
		int STARTY ;
		int WIDTH ;
		int HEIGHT ;
		int ROW;
		int ArryXY ;
		int score ;
};

bool IsLineConnection( LiangLianKan * tv  , int x1, int y1, int x2, int y2)
{
	int i,temp;

	if (!(x1 == x2 || y1 == y2))
	{
		return false;
	}

	temp=abs(x1+y1-x2-y2) ;
	if (temp==1)
	{
		return true ;
	}

	if(x1 == x2)   //ͬһ��
	{   
		if(y2 > y1)
		{
			for(i=1; i < temp; i++)
				if(tv->Arry[x1][y1+i] !=0  )
					return false;
		}
		else
		{
			for(i=1; i < temp; i++)
				if(tv->Arry[x1][y1-i] !=0 )
					return false;
		}
	}
	else if(y1 == y2) //ͬtv->Arry    {
	{
		if(x2 > x1)
		{
			for(i=1; i<temp; i++)
				if(tv->Arry[x1+i][y1] !=0 )
					return false;
		}
		else
		{
			for(i=1; i<temp; i++)
				if(tv->Arry[x1-i][y1] !=0 )
					return false;
		}
	}
	return true;
}

//    2)һת����ͨ�����
bool IsOneCornerConnection( LiangLianKan * tv ,int x1, int y1, int x2, int y2)
{    
	if( ( tv->Arry[x1][y2] == 0  ) && 
			IsLineConnection(tv,x1, y1 , x1, y2) &&
			IsLineConnection(tv,x2, y2 , x1, y2) 
	  )
		return true;

	if( (  tv->Arry[x2][y1] == 0 )&&
			IsLineConnection(tv,x1, y1 , x2, y1) &&
			IsLineConnection(tv,x2, y2 , x2, y1)
	  )
		return true;

	return false ;
}
//    3)��ת����ͨ�����
bool IsTwoCornerConnection( LiangLianKan * tv ,int x1, int y1, int x2, int y2)
{
	int i ; 
	//����ɨ��
	for(i=y1 -1; i>0; --i)
	{
		if(tv->Arry[x1][i]!= 0  )
		{
			break;
		}
		//�˵����(x2, y2)����һ��ת����ͨ
		//��(x1, y1)��(x2, y2)�ɾ�������ת����ͨ
		if (IsOneCornerConnection( tv ,x1, i , x2, y2))
		{   return true;}
	}
	//����ɨ��
	for(i = x1 - 1; i>0; --i)
	{
		if(tv->Arry[i][y1] != 0 )
		{  break ;}
		if(IsOneCornerConnection( tv , i, y1 ,x2, y2))
		{   return true; } 
	}
	//����ɨ��
	for(i = y1 + 1; i<(tv->ROW); ++i  )
	{
		if(tv->Arry[x1][i] !=0  )
		{break;}
		if(IsOneCornerConnection( tv ,x1, i , x2, y2))
		{ return true;}
	}
	//����ɨ��
	for( i = x1 + 1; i<(tv->ROW); ++i)
	{
		if(tv->Arry[i][y1] !=0   )
		{ break ;}
		if(IsOneCornerConnection(tv,i, y1 ,x2, y2))
		{ return true; }
	}
	return false;
}

/*
   void board(WINDOW *win, int starty, int startx, int lines, int cols,
   int tile_width, int tile_height)
   {   
   int endy, endx, i, j;

   endy = starty + lines * tile_height;
   endx = startx + cols  * tile_width;
   for( j = starty ; j <= endy; j += tile_height)
   {
   for(i = startx; i <= endx; ++i)
   {
   mvwaddch(win, j, i, ACS_HLINE);
   }
   }
   for(i = startx; i <= endx; i += tile_width)
   for(j = starty; j <= endy; ++j)
   mvwaddch(win, j, i, ACS_VLINE);
   mvwaddch(win, starty, startx, ACS_ULCORNER);
   mvwaddch(win, endy, startx, ACS_LLCORNER);
   mvwaddch(win, starty, endx, ACS_URCORNER);
   mvwaddch(win,   endy, endx, ACS_LRCORNER);
   for(j = starty + tile_height; j <= endy - tile_height; j += tile_height)
   {   mvwaddch(win, j, startx, ACS_LTEE);
   mvwaddch(win, j, endx, ACS_RTEE);
   for(i = startx + tile_width; i <= endx - tile_width; i += tile_width)
   mvwaddch(win, j, i, ACS_PLUS);
   }
   for(i = startx + tile_width; i <= endx - tile_width; i += tile_width)
   {   mvwaddch(win, starty, i, ACS_TTEE);
   mvwaddch(win, endy, i, ACS_BTEE);
   }
   wrefresh(win);
   }
   */



void magic_board( LiangLianKan * tv )
{ 
	int i,j, deltax, deltay;
	int startx, starty;
	int n=(tv->ROW)-4 ;
	starty = (tv->mrow - n * tv->HEIGHT) / 2;
	startx = (tv->mcol  - n * tv->WIDTH) / 2;
	int attr = COLOR_PAIR(8) ; 
	attron(attr);                       
	board(stdscr, starty, startx, n, n, tv->WIDTH, tv->HEIGHT);
	attroff(attr);
	deltay = tv->HEIGHT / 2;
	deltax = tv->WIDTH  / 2;
	attr = COLOR_PAIR(5) ;
	attron(attr);
	for(i = 0;i < n; ++i)
		for(j = 0; j < n; ++j)
		{
			if (tv->Arry[i+2][j+2]!=0)
			{
				mvprintw(starty + j * tv->HEIGHT + deltay,
						startx + i * tv->WIDTH  + deltax,
						"%d", tv->Arry[i+2][j+2]);
			}
		}
	attroff(attr);
}


bool LiangLianKan_tv_Draw(LiangLianKan * tv )
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(7); attron(attr);
	mvaddstr(0,(tv->mcol/2)-20,"Welcome come,LianLianKan Game");
	int HelpPosi=(tv->mcol)/2 ;
	mvaddstr(1,(tv->mcol/2)-20,"Love hewm@genomics.org.cn");
	mvaddstr(2,(tv->mcol/2)-20,"q  : leave");
	string sore="level :" + Int2Str(tv->score);
	mvaddstr(2,(tv->mcol/2),sore.c_str());
	attroff(attr);
	magic_board(tv);
	refresh();
	return true ;
}



bool  GetPath( LiangLianKan * tv , map <string,bool> & Good )
{
	int DD=2+tv->ArryXY;
	bool Paht=false ;
	Good.clear();
	for (int i = 2; i <DD; i++ )
	{
		for (int j = 2 ; j <(DD); j++)
		{
			for (int ii= 2 ; ii<(DD) ; ii++)
			{
				for (int jj = 2 ; jj <(DD); jj++)
				{
					if ( tv->Arry[ii][jj] !=  tv->Arry[i][j] )
					{
						continue ;
					}
					else if ( ii==i && jj==j )
					{

						continue ;
					}
					else if (  tv->Arry[ii][jj]==0 ||  tv->Arry[i][j]==0 )
					{
						continue ;
					}
					else if  (IsLineConnection (tv,i,j,ii,jj) ||  IsOneCornerConnection(tv,i,j,ii,jj)  || IsTwoCornerConnection(tv,i,j,ii,jj))
					{
						string aa=Int2Str(i)+" "+Int2Str(j)+" "+Int2Str(ii)+" "+Int2Str(jj) ;
						Good[aa]=true;
						Paht=true ;
					}
				}
			}
		}
	}
	return  Paht ;
}


bool LiangLianKan_tv_Pair( LiangLianKan * tv )
{
	map <string,bool>  Good  ;
	GetPath (tv ,Good );
	int n=(tv->ROW)-2 ;    
	int  startx = (tv->mcol  - n * tv->WIDTH) / 2;
	int  starty = (tv->mrow - n * tv->HEIGHT) / 2;
	int endy = starty + n * tv->HEIGHT;
	int endx = startx +  n * tv->WIDTH ;
	int deltay = tv->HEIGHT / 2;
	int deltax = tv->WIDTH  / 2;
	LiangLianKan_tv_Draw(tv);
	while(!Good.empty())
	{
		MEVENT event;
		int seletion_count=0;
		int x1=0 ,y1=0 ;
		while(true)
		{
			int  ch = getch();
			if(ch == KEY_MOUSE && (getmouse(&event) == OK )  &&  ( event.bstate & BUTTON1_PRESSED))
			{
				int x=(event.x-startx)/(tv->WIDTH)+1;
				int y=(event.y-starty)/(tv->HEIGHT)+1;

				if ( (1<x && x<n ) && (1<y && y<n ))
				{
					if (tv->Arry[x][y]==0)
					{
						continue ;
					}
					seletion_count++;
					int attr = COLOR_PAIR(12);
					attron(attr);
					if (seletion_count==1)
					{
						x1=x; y1=y ;
					}
					if (tv->Arry[x1][y1]!=0)
					{
						mvprintw(starty+(y1-1)*tv->HEIGHT+deltay,startx+(x1-1)*tv->WIDTH+deltax, "%d", tv->Arry[x1][y1]);
					}
					attroff(attr);
					refresh();
					if (seletion_count==2)
					{
						string aa=Int2Str(x1)+" "+Int2Str(y1)+" "+Int2Str(x)+" "+Int2Str(y) ;
						seletion_count=0;
						if (Good.find(aa)!=Good.end())
						{
							tv->Arry[x][y]=0;
							tv->Arry[x1][y1]=0;
							mvaddch (starty+(y1-1)*tv->HEIGHT+deltay,startx+(x1-1)*tv->WIDTH+deltax,' ');
							mvaddch (starty+(y-1)*tv->HEIGHT+deltay,startx+(x-1)*tv->WIDTH+deltax,' ');
							int attr = COLOR_PAIR(11) ; 
							attron(attr);
							mvaddstr(endy+2,endx+2,"Find Path") ;
							attroff(attr);
							refresh();
							GetPath (tv ,Good );
							break ;
						}
						else
						{
							if (tv->Arry[x][y1]!=0)
							{
								int attr = COLOR_PAIR(5) ;
								attron(attr);
								mvprintw(starty+(y1-1)*tv->HEIGHT+deltay,startx+(x1-1)*tv->WIDTH+deltax, "%d", tv->Arry[x1][y1]);
								attroff(attr);
							}
							attr = COLOR_PAIR(11) ;
							attron(attr);
							mvaddstr(endy+2,endx+2,"NO Path Fine") ;
							attroff(attr);
							refresh();
							break ;
						}
						break ;
					}
				}
			}
			else if (ch == 'q')
			{
				return false ;
				break ;
			}
		}
	}

	return true ;
}


int LiangLianKan_tv_Run (LiangLianKan * tv )
{
	while(true)
	{
		tv->ROW=tv->level+6 ;
		int DD=tv->ROW-2 ;

		tv->ArryXY = tv->ROW-4 ;
		tv->Arry = new int *[(tv->ROW)];        
		tv->Arry[0] = new int[(tv->ROW)*(tv->ROW)];

		for(int i = 1; i <(tv->ROW); i++)
		{
			tv->Arry[i] = tv->Arry[i-1]+(tv->ROW);
		}

		srand((unsigned)time(NULL));
		for (int i = 0; i <(tv->ROW); i++)
		{
			for (int j = 0; j <(tv->ROW); j++)
			{
				int b=rand()%(6)+1;
				tv->Arry[i][j]=b;
			}
		}


		for (int i=0 ; i< (tv->ROW); i++ )
		{
			tv->Arry[1][i]=0; 
			tv->Arry[(tv->ROW)-2][i]=0;
			tv->Arry[i][1]=0;
			tv->Arry[i][(tv->ROW)-2]=0;
		}

		for (int i=0 ; i< (tv->ROW); i++ )
		{
			tv->Arry[0][i]=2; 
			tv->Arry[(tv->ROW)-1][i]=2;
			tv->Arry[i][0]=2;
			tv->Arry[i][(tv->ROW)-1]=2;
		}

		//LiangLianKan_tv_Draw( tv ) ;
		if (LiangLianKan_tv_Pair(tv))
		{
			tv->level++;
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;
			if (tv->level>16)
			{
				tv->level=16;
			}
			else if  (tv->level>13)
			{
				tv->WIDTH =2;
				tv->HEIGHT=1;
			}
			else if (tv->level>10)
			{
				tv->WIDTH =3;
				tv->HEIGHT=2;
			}
			else if (tv->level>6 )
			{
				tv->WIDTH =4;
				tv->HEIGHT=2;
			}
			else if (tv->level>4 )
			{
				tv->WIDTH =5;
				tv->HEIGHT=3;
			}

			tv->score++;
			beep();
			flash();

		}
		else
		{
			delete []  tv->Arry[0] ;
			delete []  tv->Arry ;
			int B=0;
			B |= COLOR_PAIR(5); attron(B);
			mvaddstr(tv->mrow/2,tv->mcol/2,"LianLianKan Game Over");
			mvaddstr(tv->mrow/2+2,tv->mcol/2,"Enter 'y' : Repeat");
			mvaddstr(tv->mrow/2+4,tv->mcol/2,"Enter 'q' : Leave");
			mvaddstr(tv->mrow/2+6,tv->mcol/2,"Welcome Again");
			mvaddstr(tv->mrow/2+8,tv->mcol/2,"hewm@genomics.org.cn");
			attroff(B);
			refresh();

			break ;
		}
	}
	return 1 ;
}


int LiangLianKan_tv_Init( LiangLianKan * tv )
{
	initscr();
	noecho();
	cbreak();
	raw();
	curs_set(0);
	keypad(stdscr, TRUE);
	mousemask(ALL_MOUSE_EVENTS,NULL);
	mouseinterval(50);
	start_color();
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_WHITE, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(6, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_RED, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);
	init_pair(13, COLOR_CYAN, COLOR_GREEN);
	tv->level=1;
	tv->mrow=82 ;tv->mcol=42 ;    
	getmaxyx(stdscr, tv->mrow, tv->mcol);
	tv->STARTX=9;
	tv->STARTY=3;
	tv->WIDTH =6;
	tv->HEIGHT=4;
	tv->score=0;
	return 1 ;
}

void  tv_Destroy(LiangLianKan * tv )
{
	endwin();
	//return 1;
}

int Game_LLK_main(int argc, char** argv)
{
	bool Game_Repeat=true ;

	while(true)
	{
		LiangLianKan  *game=new LiangLianKan ;
		LiangLianKan_tv_Init(game) ;
		LiangLianKan_tv_Run(game);
		///        /*
		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		tv_Destroy(game);
		delete game ;
		if (Game_Repeat)
		{
			return 1 ;
		}
		///        */////
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // Snake_Eat_H_

//1)


#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <ext/hash_map>
#include "../include/gzstream/gzstream.h"
using namespace std;
using namespace __gnu_cxx;

typedef long long llong ;

///////////////////
string &  replace_all(string &  str,const   string&  old_value,const string&   new_value)      
{      
	while(true)   {      
		string::size_type   pos(0);      
		if(   (pos=str.find(old_value))!=string::npos   )      
			str.replace(pos,old_value.length(),new_value);      
		else   break;      
	}      
	return   str;      
}      

string &   replace_all_distinct(string&   str,const   string&   old_value,const   string&   new_value)      
{      
	for(string::size_type   pos(0);   pos!=string::npos;   pos+=new_value.length())   {      
		if(   (pos=str.find(old_value,pos))!=string::npos   )      
			str.replace(pos,old_value.length(),new_value);      
		else   break;      
	}      
	return   str;      
}      
void split(const string& str,vector<string>& tokens,  const string& delimiters = " ")
{
	string::size_type lastPos = str.find_first_not_of(delimiters, 0);
	string::size_type pos     = str.find_first_of(delimiters, lastPos);
	while (string::npos != pos || string::npos != lastPos)
	{
		tokens.push_back(str.substr(lastPos, pos - lastPos));
		lastPos = str.find_first_not_of(delimiters, pos);
		pos = str.find_first_of(delimiters, lastPos);
	}
}
///////////////////
void  changid ( string & str  , llong  id ,int sam_count )
{
	stringstream ss ;
	ss<<sam_count<<"-"<<id;
	str.replace(0,str.find("\t"),ss.str());
}

void  changid ( string & str1 , string & str2  , llong id  , int sam_count )
{
	stringstream ss ;
	ss<<sam_count<<"-"<<id;
	str1.replace(0,str1.find("\t"),ss.str());
	str2.replace(0,str2.find("\t"),ss.str());
}

int readSamlist (string soaplist  ,   vector <string> & Sam_Stat  )
{
	igzstream LIST (soaplist.c_str(),ifstream::in); // igzstream
	int soapfilecout=0 ;
	if (!LIST.good())
	{
		cerr << "open Samlist error: "<<soaplist<<endl;
		exit (1) ;
		return  soapfilecout ;
	}
	while(!LIST.eof())
	{
		string  line ;
		getline(LIST,line);
		if (line.length()<=0)  { continue  ; }
		Sam_Stat.push_back(line);
		soapfilecout++;
	}
	LIST.close();
	return  soapfilecout ;
}

int IDFind (string  str)
{
	int I=str.find("I");
	if (I!=-1)
	{
		return  I ;
	}
	else
	{
		I=str.find("D");
		return  I ;
	}
}


int  print_usage ()
{
	cout <<""
		"Program: Sam2InsertChr\n"
		"Version: 1.00\thewm@genomics.org.cn\t2011-09-02\n"
		"\n"
		"Usage:  [options]\n"
		"\t\t-ChrList      <str>   Input chrlist file\n"
		"\t\t-SamPE        <str>   Input Sam PE file\n"
		"\t\t-Insert       <str>   Output Insert Stat\n"
		"\t\t-OutDir       <str>   OutDir chr#.sam Output Dir\n"
		"\t\t-LandID       <int>   Land ID for this Land\n"
		"\n"
		"\t\t-OffIndel             don't print the I(nsert) D(ele) Reads\n"
		"\t\t-help                 show this help\n" 
		"\n";
	return 1;
}


int LandID = -1 ;
string InsertStat ;
string SamStat_Now ;
string OutDir ;
string ChrList  ;
int OffIndel =0 ; 

int parse_cmd(int argc, char **argv)
{
	if (argc <=8 ) {print_usage(); return 1;}

	int err_flag = 0;

	for(int i = 1; i < argc || err_flag; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 1;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "SamPE" )
		{
			if(i + 1 == argc) {cerr << "lack argument for '-SamPE'" <<endl;err_flag = 1;  return 1;}
			i++;
			SamStat_Now=argv[i];
		}
		else if (flag  ==  "OutDir")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-OutDir'" <<endl;err_flag = 1;  return 1;}
			i++;
			OutDir=argv[i];
			OutDir+="/";
		}
		else if (flag  ==  "ChrList")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-ChrList'" <<endl;err_flag = 1;  return 1;}
			i++;
			ChrList=argv[i];
		}
		else if (flag  ==  "Insert")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-Insert'" <<endl;err_flag = 1;  return 1;}
			i++;
			InsertStat=argv[i];
		}
		else if (flag  ==  "LandID")
		{
			if(i + 1 == argc) {cerr << "lack argument for '-LandID'" <<endl;err_flag = 1;  return 1;}
			i++;
			LandID=atoi(argv[i]);
		}

		else if (flag  == "help")
		{
			print_usage(); return 1;
		}
		else if (flag  == "OffIndel")
		{
			OffIndel=1;        
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 1;
		}    
	}

	if  (InsertStat.empty() ||  SamStat_Now.empty() || OutDir.empty() || ChrList.empty() || LandID==-1 )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 1;
	}
	return 1 ;
}

//////////////////
int main(int argc,char *argv[] )
{
	if( argc<8 )
	{
		print_usage () ;
		return 1 ;
	}
	parse_cmd( argc, argv) ;
	//  string InfoOut= argv[4];
	igzstream IN (ChrList.c_str(),ifstream::in); // igzstream 
	ofstream  Insert (InsertStat.c_str()) ;

	if(!IN.good())
	{
		cerr << "open ChrList error: "<<ChrList<<endl;
		return 1;
	}
	if(!Insert.good())
	{
		cerr << "open InsertStat error: "<<InsertStat<<endl;
		return 1;
	}

	vector <string> File ;
	vector <string> FileHead ;
	map <string,int>  Sam2Int ;
	int  chr_count=0 ;
	////////////////////////swimming in the sea & flying in the sky //////////////////   
	while(!IN.eof())
	{
		string  line ,chr ,headtemp;
		getline(IN,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		isone>>chr ;
		Sam2Int[chr]=chr_count;
		line=OutDir+chr+".sam";
		headtemp=OutDir+chr+".h";
		File.push_back(line);
		FileHead.push_back(headtemp);
		chr_count++;
	}
	IN.close();

	int File_count=File.size();
	if (File_count>168 || chr_count>168 )
	{
		cerr<<"Waining :chr num too much"<<endl ;
	}
	//ogzstream *Sam2Chr = new ogzstream[File_count] ;
	ofstream *Sam2Chr = new ofstream[File_count] ;
	ofstream *FileH  = new ofstream[File_count] ;

	for (int i=0; i<File_count ; i++)
	{
		Sam2Chr[i].open(File[i].c_str()) ;
		FileH[i].open(FileHead[i].c_str());
		if  (!Sam2Chr[i].good())
		{
			cerr<<"Can't open follow output:\n"<<File[i]<<endl;        
		}
		if  (!FileH[i].good())
		{
			cerr<<"Can't open follow output:\n"<<FileHead[i]<<endl;        
		}
	}

	igzstream IN_Sam (SamStat_Now.c_str(),ifstream::in); // igzstream
	llong Read_id=0;
	llong all_read=0 ;
	llong SE=0;
	llong PE=0;
	string line1 ,line2 ;

	string id1 , chr1 ;

	for (int jj=0 ; jj<File_count; jj++)
	{
		getline(IN_Sam,line1) ;
		istringstream isone (line1,istringstream::in);
		isone>>id1>>chr1 ;
		vector <string> tokens ;
		split(chr1, tokens, ":") ;
		chr1=tokens[tokens.size()-1];
		Sam2Chr[Sam2Int[chr1]]<<line1<<endl;
		FileH[Sam2Int[chr1]]<<line1<<endl;
		FileH[Sam2Int[chr1]].close();
	}
	getline(IN_Sam,line1) ;
	istringstream isone (line1,istringstream::in);
	isone>>id1 ;
	if ( id1 != "@PG" )
	{
		cerr<<"Waiming!!! chr count may be not the same \n"<<endl;
		cerr<<"the chrlist chr name count should be the same with the Sam head chr count"<<endl;
	}

	map <llong, llong > map_insert ;

	if (OffIndel==0)
	{
		while(getline(IN_Sam,line1))
		{   
			string id1 ,chr1 ;
			long flag1 ;
			istringstream isone (line1,istringstream::in);
			isone>>id1 >> flag1 >>chr1 ;
			getline(IN_Sam,line2) ;
			Read_id++;

			string id2 ,chr2 ;
			long flag2 ;
			istringstream isone2 (line2,istringstream::in);
			isone2 >>id2 >> flag2 >>chr2 ;
			bool FT_1 = !((flag1 & 0x004) || chr1 =="*" );
			bool FT_2 = !((flag2 & 0x004) || chr2 =="*" ) ;

			if ( FT_1 && FT_2 )
			{
				changid(line1 ,line2 , Read_id , LandID ) ;
				Sam2Chr[Sam2Int[chr1]]<<line1<<endl;
				Sam2Chr[Sam2Int[chr2]]<<line2<<endl;
				long insert_size=0;
				//   50719915        60      100M    =       50720290        475 
				isone>>id2 >> id2  >> id2  >> id2  >> id2  >> insert_size ;            
				insert_size=abs(insert_size);
				if (insert_size!=0)
				{
					map_insert[insert_size]++;
					PE++;
				}
				else
				{
					SE+=2 ;
				}
			}
			else if ( (!FT_1) && (!FT_2) )
			{
				continue ;
			}
			else if ( FT_1 )
			{
				changid(line1 , Read_id , LandID ) ;
				Sam2Chr[Sam2Int[chr1]]<<line1<<endl;
				SE++;
			}
			else
			{
				changid(line2 , Read_id , LandID ) ;
				Sam2Chr[Sam2Int[chr2]]<<line2<<endl;
				SE++;
			}
		}
		IN_Sam.close();
		IN_Sam.clear();   
	}
	else if (  OffIndel==1  )
	{
		//A8054YABXX:1:1:1464:1990#ATCACGAT       147     chr14   45387730        60      100M    =  
		while(getline(IN_Sam,line1))
		{   
			string id1 ,chr1, MapSeq1 ;
			long flag1 ,Q1 ;
			llong posi1 ;
			istringstream isone (line1,istringstream::in);
			isone>>id1 >> flag1 >>chr1 >> posi1 >> Q1 >> MapSeq1 ;
			getline(IN_Sam,line2) ;
			Read_id++;

			string id2 ,chr2 ,MapSeq2,temp ;
			long flag2 ,Q2;
			llong posi2 ;
			long insert_size=0;
			istringstream isone2 (line2,istringstream::in);
			isone2 >>id2 >> flag2 >>chr2 >> posi2 >> Q2 >> MapSeq2 ;

			bool FT_1 = !((flag1 & 0x004) || chr1 =="*" || IDFind(MapSeq1)!=-1 );
			bool FT_2 = !((flag2 & 0x004) || chr2 =="*" || IDFind(MapSeq2)!=-1 ) ;

			if ( (FT_1) && (FT_2) )
			{
				changid(line1 ,line2 , Read_id , LandID ) ;
				Sam2Chr[Sam2Int[chr1]]<<line1<<endl;
				Sam2Chr[Sam2Int[chr2]]<<line2<<endl;
				isone2>> temp >> temp >> insert_size  ;
				insert_size=abs(insert_size);
				if (insert_size!=0)
				{
					map_insert[insert_size]++;
					PE++;
				}
				else
				{
					SE+=2 ;
				}
			}
			else if ( (!FT_1) && (!FT_2) )
			{
				continue ;
			}
			else if ( FT_1 )
			{
				changid(line1 , Read_id , LandID ) ;
				Sam2Chr[Sam2Int[chr1]]<<line1<<endl;
				SE++;
			}
			else
			{
				changid(line2 , Read_id , LandID ) ;
				Sam2Chr[Sam2Int[chr2]]<<line2<<endl;
				SE++;
			}
		}
		IN_Sam.close();
		IN_Sam.clear();
	}
	//////////swimming in the sky and flying in the sea ///////////
	/////*/////

	for (int i=0; i<File_count ; i++)
	{
		Sam2Chr[i].close() ;
	}
	// insert size //
	llong max_x = 0 ;
	llong max_y = 0;
	llong total_uniq_low_pair = 0 ;
	llong total_uniq_normal_pair = 0 ;
	llong total_uniq_pair = 0 ;
	llong total_single = 0 ;

	map <llong, llong >  :: const_iterator map_it=map_insert.begin();

	while( map_it !=map_insert.end())
	{
		if (max_y  <= map_it->second )
		{
			max_y= map_it->second ;
			max_x= map_it->first ;
		}
		map_it++;
	}

	llong cutoff = max_y /1000;
	if (cutoff<3) {cutoff=3 ;}

	map_it=map_insert.begin();
	vector <llong> vectorInsert ;
	vector <llong> vectorCount ;
	vector <llong> vectorcumul ;

	while( map_it !=map_insert.end())
	{
		if  (  map_it->second < cutoff )
		{
			total_uniq_low_pair +=  map_it->second ;
		}
		else
		{
			total_uniq_normal_pair +=  map_it->second ;
			vectorInsert.push_back(map_it->first);
			vectorCount.push_back( map_it->second ) ;
			vectorcumul.push_back(total_uniq_normal_pair);
		}
		map_it++;
	}

	llong median = llong( max_x+0 );

	llong Lsd=0;  llong Rsd=0 ; llong Lc=0 ; llong Rc=0 ;

	for (long  i=0; i<vectorInsert.size(); i++)
	{
		llong diff =llong (llong(vectorInsert[i]+0) - median) ;
		if (diff < 0)
		{
			Lsd += vectorCount[i] * diff * diff ;
			Lc +=  vectorCount[i];
		}
		else if ( diff > 0)
		{
			Rsd += vectorCount[i] * diff * diff;
			Rc += vectorCount[i];
		}
	}


	if (Lc!=0)
	{
		Lsd = llong( sqrt(Lsd/Lc));
	}
	if (Rc!=0)
	{
		Rsd = llong (sqrt(Rsd/Rc));
	}
	Read_id=Read_id*2;
	PE=PE*2;
	llong total_map_reads=PE+SE ;
	total_uniq_pair = total_uniq_low_pair + total_uniq_normal_pair;
	total_single = SE ;

	Insert<< "#          Mapped reads: "<<total_map_reads<<endl;
	Insert<< "#          Single reads: "<<total_single<<endl;
	Insert<< "#    All original reads: "<<Read_id<<endl;
	Insert<< "#            Pair reads: "<<total_uniq_pair<<endl;
	Insert<< "#    low frequency pair: "<<total_uniq_low_pair<<endl;
	Insert<< "# normal frequency pair: "<<total_uniq_normal_pair<<endl;
	Insert<< "#                  Peak: "<<median<<endl;
	Insert<< "#                    SD: -"<<Lsd<<"/+"<<Rsd<<endl;

	for (long i=0; i<vectorInsert.size() ; i++)
	{
		Insert<<vectorInsert[i]<<"\t"<<vectorCount[i]<<endl;
	}
	Insert.close();

	return 0 ;

}



////////////////////////swimming in the sea & flying in the sky //////////////////



///////// swimming in the sky and flying in the sea ////////////

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../ALL/comm.h"
#include "../Soap/Soap_Merge.h"
#include "../ALL/DataClass.h"
#include "../Soap/xam2soap/TSamCtrl.h"
#include "../Soap/xam2soap/Ttools.h"
#include "../include/gzstream/gzstream.h"
using namespace std;

///////////////////

int  print_Xam02()
{
	cout <<""
		"\n"
		"\tUsage: merge -InList <sam.list> -OutPut <out.sam>\n"
		"\n"
		"\t\t-InList    <str>   Input sort sam,bam file list\n"
		"\t\t-OutPut    <str>   Output Sort file for merge sam\n"
		"\t\t\n"
		"\t\t-Bam               if the file is Bam format\n"
		"\t\t-SamNoHead         if the file is Sam with NoHead\n"
		"\t\t-Dict      <str>   Input Sam Head file\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}

int parse_Xam02(int argc, char **argv , In3str1v * para_Xam02 )
{
	if (argc <=2 ) {print_Xam02();return 0;}

	for(int i = 1; i < argc; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InList")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_Xam02->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam02->InStr2=argv[i];
		}
		else if (flag  ==  "Dict")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_Xam02->InStr3=argv[i];
		}
		else if (flag  == "Bam"  )
		{
			(para_Xam02->TF)=false ;
		}
		else if (flag  == "SamNoHead"  )
		{
			(para_Xam02->TF2)=false ;
		}
		else if (flag  == "help")
		{
			print_Xam02();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}

	}
	if  ( (para_Xam02->InStr1).empty() || ((para_Xam02->InStr2).empty()) )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para_Xam02->InStr2)=add_Asuffix(para_Xam02->InStr2) ;

	return 1 ;

}
////////////////////////////

int Xam_Merge_main(int argc,char *argv[])
{
	In3str1v  * para_Xam02 = new In3str1v ;
	if (parse_Xam02( argc, argv, para_Xam02)==0)
	{
		delete para_Xam02 ;
		return 0;
	}

	ogzstream OUT ((para_Xam02->InStr2).c_str());
	if(!OUT.good())
	{
		cerr << "open OutFile error: "<<(para_Xam02->InStr2)<<endl;
		return 0;
	}
	if (!(para_Xam02->InStr3).empty())
	{
		Write_Sam_head (para_Xam02->InStr3, OUT) ;
	}

	ReadList ( (para_Xam02->InStr1), (para_Xam02->List) );
	int File_count=(para_Xam02->List).size();

	if ((para_Xam02->TF))
	{
		igzstream *Sam = new  igzstream[File_count]     ;
		long *Posi =new long [File_count] ;
		string temp ,line ;
		long min_now  ;
		string *Pring =new string[File_count];
		string head1 ,head2 ;
		if(para_Xam02->TF2)
		{
			for (int i=0; i<File_count ; i++)
			{
				Sam[i].open((para_Xam02->List)[i].c_str(),ifstream::in) ;
				if  (Sam[i].good())
				{
					cout<<"Samfile\t"<<(para_Xam02->List)[i]<<endl;
					getline(Sam[i],head1);
					if (i!=0)
					{
						if (head2!=head1)
						{
							cerr<<"Warming!!!"<<endl;
							cerr<<(para_Xam02->List)[i]<<" header is diff the before!!"<<endl;
							cerr<<"please check it!!"<<endl;
						}
					}
					else
					{
						head2=head1;
					}
					getline(Sam[i],line);
					Pring[i]=line ;
					istringstream isone (line,istringstream::in);
					isone>>temp>>temp>>temp>>min_now;
					Posi[i]=min_now;
				}
				else
				{
					cerr<<(para_Xam02->List)[i]<<"\tcan't open"<<endl ;
					Pring[i]=line ;
					Posi[i]=-2 ;
				}
			}
			OUT<<head2<<endl;
		}
		else
		{
			for (int i=0; i<File_count ; i++)
			{
				Sam[i].open((para_Xam02->List)[i].c_str(),ifstream::in) ;
				if  (Sam[i].good())
				{
					cout<<"Samfile\t"<<(para_Xam02->List)[i]<<endl;
					getline(Sam[i],line);
					Pring[i]=line ;
					istringstream isone (line,istringstream::in);
					isone>>temp>>temp>>temp>>min_now;
					Posi[i]=min_now;
				}
				else
				{
					cerr<<(para_Xam02->List)[i]<<"\tcan't open"<<endl ;
					Pring[i]=line ;
					Posi[i]=-2 ;
				}
			}
		}
		int file_run_cout=chose_Afile(Posi , File_count) ;
		while( file_run_cout > -1 )
		{        
			run_Aread(Sam[file_run_cout],Posi[file_run_cout],OUT,Pring[file_run_cout] , 4 );
			file_run_cout=chose_Afile ( Posi, File_count ) ;
		}
		delete [] Sam ;
		delete [] Posi ;
		delete [] Pring ;
	}
	else
	{
		char in_mode[5] ={ 0 };
		in_mode[0]='r';in_mode[1]='b';
		TSamCtrl *Sam = new TSamCtrl[File_count] ;
		long *Posi =new long [File_count] ;
		string *Pring =new string[File_count];
		string temp ,line ;
		long min_now  ;
		for (int i=0; i<File_count ; i++)
		{
			Sam[i].open((para_Xam02->List)[i].c_str(),in_mode);
			Sam[i].readline(line);
			Pring[i]=line ;
			istringstream isone (line,istringstream::in);
			isone>>temp>>temp>>temp>>min_now;
			Posi[i]=min_now;
		}

		int file_run_cout=chose_Afile(Posi , File_count) ;
		while( file_run_cout > -1 )
		{        
			run_Aread(Sam[file_run_cout],Posi[file_run_cout],OUT,Pring[file_run_cout] , 4 );
			file_run_cout=chose_Afile ( Posi, File_count ) ;
		}

		delete [] Sam ;
		delete [] Posi ;
		delete [] Pring ;
	}

	OUT.close();
	delete para_Xam02 ;
	return 0 ;
}



////////////////////////swimming in the sea & flying in the sky //////////////////



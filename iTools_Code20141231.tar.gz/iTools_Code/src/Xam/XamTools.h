#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
//#include "../sam/bam_sort.c"

#include "SamSplit.h"
#include "XamMerge.h"
#include "Alg_View.h"
#include "XamRmDup.h"
#include "XamFilter.h"
#include "XamStat.h"
#include "SamAddHeader.h"
//KSEQ_INIT(gzFile, gzread)


using namespace std;

int Xam_split_main(int argc,char *argv[] ) ;
int Xam2Soap_main(int argc, char **argv);
int all_genetype_main(int argc, char **argv) ;
int Xam_Merge_main(int argc,char *argv[]) ;
int Alg_View_main(int argc, char *argv[]) ;
int Xam_RmDup_main(int argc, char *argv[]);
int Xam_Filter_main(int argc, char **argv) ;
int Xam_Stat_main(int argc, char **argv);
int Xam_SamHeader_main(int argc, char *argv[]);


static int  Xam_usage ()
{
	cerr<<""
		"\n"
		"\tXamtools Usage:\n\n"
		"\t\tsplit       split the sam,bam to chr_subFiles\n"
		"\t\tmsort       msort the sam with [-kn4]\n"
		"\t\tmerge       multi Sort sam,bam to a Sort Sam\n"
		"\t\trmdup       remove PCR duplicates of SortSam,Bam\n"
		"\t\tview        view the Alignment[Bam,Sam,Soap]\n"
		"\t\tstat        stat Sort Sam/Bam of [depth/coverage...]\n"
		"\t\tfilter      fiter/extract the Sam,Bam Read\n"
		"\t\tAlg2geno    estimate genotype bases soap,bam,sam\n"
		"\t\tAddHeader   Add the Header for the Sam File\n"
		"\n"        
		"\t\tXam2Soap    Sam,bam Format to Soap Format\n"
		"\t\tHelp        Show this help\n"
		"\n";
	return 1;
}


int Xam_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return Xam_usage(); }
	else if (strcmp(argv[1], "split") == 0) { return Xam_split_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "msort") == 0) { return msort_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "merge") == 0) { return Xam_Merge_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Alg2geno") == 0) { return all_genetype_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Xam2Soap") == 0) { return Xam2Soap_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "view") == 0) { return  Alg_View_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "rmdup") == 0) { return  Xam_RmDup_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "filter") == 0) { return Xam_Filter_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "stat") == 0) { return Xam_Stat_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "AddHeader") == 0) { return Xam_SamHeader_main(argc-1, argv+1) ; }
	//  else if (strcmp(argv[1], "sort") == 0) return bam_sort(argc-1, argv+1);

	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0)  {  Xam_usage(); }
	else
	{
		cerr<<"Xamtools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;	
}



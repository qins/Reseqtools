#include<iostream>
#include<fstream>
#include<map>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string>
#include <sstream>
#include<time.h>
#include<float.h>
#include "../include/gzstream/gzstream.h"
#include "glfRead.h"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
using namespace std ;

#ifndef DBL_MANT_DIG
#define DBL_MANT_DIG 35
#endif

#define MAX_FILE_LIST_LEN 1024
#define MAX_LIST_NAME_LEN 1024
#define MAX_CHR_NAME_LEN 128

int  print_usage_8 ()
{
	cout <<""
		"\n"
		"\tUsage: GLF2GPF -Indbsnp <in.dbdnp>  -GlfList <in.glflist> -OutPut <out.genotype>\n"
		"\t\t-Indbsnp    <str>   File name of InPut sort dbsnp file\n"
		"\t\t-GlfList    <str>   Glf List file InPut\n"
		"\t\t-OutPut     <str>   File name of OutPut genotype\n"
		"\n"
		"\t\t-DepthOUT           Print the Depth info of Site[NA]\n"         
		"\n"
		"\t\t-help               show this help\n" 
		"\n";
	return 1;
}

int parse_cmd_8(int argc, char **argv, In3str1v * para_8 )
{
	if (argc <=2  ) {print_usage_8();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "GlfList" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_8->InStr2=argv[i];
		}
		else if (flag  == "Indbsnp" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_8->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_8->InStr3=argv[i];
		}
		else if (flag  == "DepthOUT")
		{
			para_8->InInt=1;
		}
		else if (flag  == "help")
		{
			print_usage_8();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_8->InStr1).empty() ||  (para_8->InStr3).empty() || (para_8->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


////////////////////////swimming in the sea & flying in the sky //////////////////
int GLF2GPF_main(int argc,char *argv[])
{
	In3str1v * para_8 = new In3str1v;
	if (parse_cmd_8(argc, argv, para_8)==0)
	{
		delete para_8 ;
		return 0;
	}

	if (para_8->InInt==1)
	{
		//clock_t start_time,finish_time;
		//double time_cost=0.0,*log10_prob=NULL,power[256]={0.0},LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0},copyNum=0.0,indi_G_LL=0.0;
		//FILE *GLFlist=NULL,*output=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
		FILE *GLFlist=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
		//int FLAG=0,start=0,end=0,i=0,j=0,k=0,N_indi=0,N_hap=0,minLLR=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		int FLAG=0,i=0,j=0,k=0,N_indi=0,N_hap=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		//        int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
		//char lo[4]={'\0'},hi[4]={'\0'},chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024]; 
		char chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],str_name[1024]; 
		//start_time=clock();

		////////////////////////swimming in the sea & flying in the sky //////////////////
		string file1=para_8->InStr1 ;
		string file3=(para_8->InStr3);
		//string suffix_temp=".genotype";
		string file4=file3+".genotype.gz" ;
		string file5=file3+".depth.gz" ;
		igzstream dbsnp (file1.c_str(),ifstream::in);
		//ofstream out_fs(file3.c_str());
		ogzstream out_type(file4.c_str());
		ogzstream out_depth(file5.c_str());
		GLFlist=fopen((para_8->InStr2).c_str(),"r");
		while(1)
		{
			if(fgets(str_name,MAX_LIST_NAME_LEN-1,GLFlist)==NULL)
			{
				break;
			}
			else
			{
				if(str_name[strlen(str_name)-1]=='\n')
					str_name[strlen(str_name)-1]='\0';
				Files[FLAG]=fopen(str_name,"rb");
				FLAG++;
			}
		}

		N_indi=FLAG;
		N_hap=2*N_indi;
		//    map <int,map<int, int> > Depth ;
		if(MAX_FILE_LIST_LEN<N_indi)
		{
			cerr<<"GLFlist Number should not more than "<<(MAX_FILE_LIST_LEN-1)<<endl;
			//  fprintf(stdout,"GLFlist Number should not more than %d\n",MAX_FILE_LIST_LEN-1);
			return 0;
		}

		int chrNum=-1;
		int chrNum_new=-1;
		for(i=0;i<FLAG;i++)
		{
			if(-1==chrNum)
			{
				Read_header(Files[i],&chrNum);
			}
			else
			{
				Read_header(Files[i],&chrNum_new);
				if(chrNum!=chrNum_new)
				{
					cerr<<"Inconsistent number of chromosomes,only the first chromosome is called.\n";
				}
				chrNum=1;
			}
		}

		cout<<"Total chromosomes\t"<<chrNum<<endl;

		memset(chrName,'\0',MAX_CHR_NAME_LEN);

		chrLen=-1;
		for(j=0;j<FLAG;j++)
		{
			if(-1==chrLen)
			{
				Read_chr(Files[j],&chrLen,chrName);
			}
			else
			{
				Read_chr(Files[j],&chrLen_tmp,chrName_tmp);
				if(chrLen!=chrLen_tmp||strcmp(chrName,chrName_tmp)!=0)
				{
					cerr<<"ERROR:The files in GLFlist don't have the sanme ChrLen or ChrName!"<<endl;
					return 0;
				}
			}
			//    fseek(Files[j],12*start,1);
		}


		if(!dbsnp.good())
		{
			cout<< "File wrong\t" <<argv[1]<< endl;   
			return 0;
		}

		map <int,int> map_snp ;

		while(!dbsnp.eof())
		{
			string line;
			getline(dbsnp,line);      
			if(line.length() > 0 )
			{
				istringstream isone (line,istringstream::in);
				string  chr_name_temp ,last_snp ;
				int a_1=0,a_2=0,a_3=0;
				int position=0;
				double b_1=1 ; double b_2=0 ;  double b_3=0 ; double b_4=0 ;
				isone>>chr_name_temp>>position>>a_1>>a_2>>a_3>>b_1>>b_2>>b_3>>b_4>>last_snp;
				//#chr9  121463515       0       1       0       0.01    0.01    0       0       rs236 
				//ChrNew18        2228    1       0       0       0       0.5     0.5     0       00000004
				if(b_2==0) { b_2=1 ; } else { b_2=2; }
				if(b_3==0) { b_3=1; } else { b_3=3; }
				if(b_4==0) { b_4=1; } else { b_4=4; }
				int genotype=int(b_2*b_3*b_4-1);
				if (genotype == 5 )  { genotype=6;  }
				position--;
				if ( chr_name_temp!=chrName )
				{
					cout <<"Bad position\t"<<chr_name_temp<<":"<<position<<endl;
					continue ;
				}
				map_snp[position]=genotype;
				//   cout<<chr_name_temp<<"\t"<<position<<"\t"<<genotype<<"\t"<<abbv[genotype]<<endl;
			}
		}
		dbsnp.close();
		cout<<chrName<<" (len:"<<chrLen<<") for "<<FLAG<<" individuals in "<<map_snp.size()<<" SNP sites" <<endl;
		int  finished = 0 ;
		int  prev_pos = 0 ;
		map<int,int>::const_iterator map_it=map_snp.begin();
		while(map_it!=map_snp.end())
		{   
			int pos=map_it->first ;
			if (pos>=chrLen)
			{
				cout<<"Warning!!! Your SNPs are located outside the chromosome!!! I am stopping!"<<endl ;
				break ;
			}
			int type=map_it->second;
			//        out_fs<<chrName<<"\t"<<(pos+1)<<"\t"<<abbv[type];
			out_type<<chrName<<"\t"<<(pos+1)<<"\t"  ;
			out_depth<<chrName<<"\t"<<(pos+1)<<"\t" ;
			//        ref = 'N' ;
			// int new_ref =0 ;
			int bewee_Two_SNP=12*(pos-prev_pos);
			if (bewee_Two_SNP<0)
			{
				cout<<"Warning!!Bad in sort SNP posi"<<endl;
				return 1;
			}
			indi_CN=0 ; indi_dep=0 ; total_depth=0;
			for(k=0;k<FLAG;k++)
			{
				fseek(Files[k],bewee_Two_SNP,1);
				indi_dep=0;
				ref_index=Read_base(Files[k],&indi_CN,&indi_dep,LLR);
				int best_genotype = 16 ;
				int second_genotype = 16 ;

				for (int glf_type=0 ; glf_type<10 ; glf_type++)
				{
					int genotype = code[glf_type] ;
					if( (genotype^type) == 0)
					{
					}
					else if( (((genotype^type)&3)== 0) or ((((genotype^type)>>2)&3) == 0) )
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) {  LLR[glf_type] += 0 ; }
						else  {  LLR[glf_type] += 27 ;  }
					}
					else
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) { LLR[glf_type] += 30 ; }
						else {   LLR[glf_type] += 54; }
					}

					if ( (best_genotype == 16) or (LLR[glf_type] < LLR[rev_code[best_genotype]])) {
						second_genotype = best_genotype ;    best_genotype = genotype ;
					}
					else if ( (second_genotype == 16 ) or (LLR[glf_type] < LLR[rev_code[second_genotype]])  )  {
						second_genotype = genotype ; }
					else
					{ 
					}        
				}
				total_depth += indi_dep ;
				int quelity_base=(LLR[rev_code[second_genotype]]-LLR[rev_code[best_genotype]]);
				//       out_fs<<"\t"<<abbv[best_genotype]<<"\t"<<abbv[second_genotype]<<"\t"<<quelity_base ;
				out_depth<<indi_dep<<" ";
				if(quelity_base==0  || indi_dep==0 ) { out_type<<"- ";  } 
				else { out_type<<abbv[best_genotype]<<" "; }
			}
			//       out_fs<<"\t"<<total_depth<<endl; 
			out_type<<endl; 
			out_depth<<endl;
			finished += 1 ;
			prev_pos=pos+1;
			if (0 == finished % 10000 )
			{
				cout<<finished<<" SNP size have done"<<endl;
			}
			map_it++;
		}
		//out_fs.close();
		out_type.close();
		out_depth.close();
		cout<<"Finished\t"<<chrName<<"\tMission Complete!"<<endl;
	}
	else
	{

		//clock_t start_time,finish_time;
		//double time_cost=0.0,*log10_prob=NULL,power[256]={0.0},LLR_mat[MAX_FILE_LIST_LEN][10],count[4]={0.0},copyNum=0.0,indi_G_LL=0.0;
		//FILE *GLFlist=NULL,*output=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
		FILE *GLFlist=NULL,*Files[MAX_FILE_LIST_LEN]={NULL};
		//int FLAG=0,start=0,end=0,i=0,j=0,k=0,N_indi=0,N_hap=0,minLLR=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		int FLAG=0,i=0,j=0,k=0,N_indi=0,N_hap=0,chrLen=-1,chrLen_tmp=0,LLR[10],total_depth=0,indi_CN=0,indi_dep=0,ref_index=0;
		//int type=0,base=0,base1=-1,base2=-1,besttype[3],minor_count=0,est_G=0;
		//char lo[4]={'\0'},hi[4]={'\0'},chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],ref='N',str_name[1024],str_result[1024]; 
		char chrName[MAX_CHR_NAME_LEN],chrName_tmp[MAX_CHR_NAME_LEN],str_name[1024]; 
		//        start_time=clock();

		////////////////////////swimming in the sea & flying in the sky //////////////////
		string file1=para_8->InStr1 ;
		string file3=(para_8->InStr3);
		//string suffix_temp=".genotype";
		string file4=file3+".genotype.gz" ;
		igzstream dbsnp (file1.c_str(),ifstream::in);
		//ofstream out_fs(file3.c_str());
		ogzstream out_type(file4.c_str());
		GLFlist=fopen((para_8->InStr2).c_str(),"r");
		while(1)
		{
			if(fgets(str_name,MAX_LIST_NAME_LEN-1,GLFlist)==NULL)
			{
				break;
			}
			else
			{
				if(str_name[strlen(str_name)-1]=='\n')
					str_name[strlen(str_name)-1]='\0';
				Files[FLAG]=fopen(str_name,"rb");
				FLAG++;
			}
		}

		N_indi=FLAG;
		N_hap=2*N_indi;
		//    map <int,map<int, int> > Depth ;
		if(MAX_FILE_LIST_LEN<N_indi)
		{
			cerr<<"GLFlist Number should not more than "<<(MAX_FILE_LIST_LEN-1)<<endl;
			//  fprintf(stdout,"GLFlist Number should not more than %d\n",MAX_FILE_LIST_LEN-1);
			return 0;
		}

		int chrNum=-1;
		int chrNum_new=-1;
		for(i=0;i<FLAG;i++)
		{
			if(-1==chrNum)
			{
				Read_header(Files[i],&chrNum);
			}
			else
			{
				Read_header(Files[i],&chrNum_new);
				if(chrNum!=chrNum_new)
				{
					cerr<<"Inconsistent number of chromosomes,only the first chromosome is called.\n";
				}
				chrNum=1;
			}
		}

		cout<<"Total chromosomes\t"<<chrNum<<endl;

		memset(chrName,'\0',MAX_CHR_NAME_LEN);

		chrLen=-1;
		for(j=0;j<FLAG;j++)
		{
			if(-1==chrLen)
			{
				Read_chr(Files[j],&chrLen,chrName);
			}
			else
			{
				Read_chr(Files[j],&chrLen_tmp,chrName_tmp);
				if(chrLen!=chrLen_tmp||strcmp(chrName,chrName_tmp)!=0)
				{
					cerr<<"ERROR:The files in GLFlist don't have the sanme ChrLen or ChrName!"<<endl;
					return 0;
				}
			}
			//    fseek(Files[j],12*start,1);
		}


		if(!dbsnp.good())
		{
			cout<< "File wrong\t" <<argv[1]<< endl;   
			return 0;
		}

		map <int,int> map_snp ;

		while(!dbsnp.eof())
		{
			string line;
			getline(dbsnp,line);      
			if(line.length() > 0 )
			{
				istringstream isone (line,istringstream::in);
				string  chr_name_temp ,last_snp ;
				int a_1=0,a_2=0,a_3=0;
				int position=0;
				double b_1=1 ; double b_2=0 ;  double b_3=0 ; double b_4=0 ;
				isone>>chr_name_temp>>position>>a_1>>a_2>>a_3>>b_1>>b_2>>b_3>>b_4>>last_snp;
				//#chr9  121463515       0       1       0       0.01    0.01    0       0       rs236 
				//ChrNew18        2228    1       0       0       0       0.5     0.5     0       00000004
				if(b_2==0) { b_2=1 ; } else { b_2=2; }
				if(b_3==0) { b_3=1; } else { b_3=3; }
				if(b_4==0) { b_4=1; } else { b_4=4; }
				int genotype=int(b_2*b_3*b_4-1);
				if (genotype == 5 )  { genotype=6;  }
				position--;
				if ( chr_name_temp!=chrName )
				{
					cout <<"Bad position\t"<<chr_name_temp<<":"<<position<<endl;
					continue ;
				}
				map_snp[position]=genotype;
				//   cout<<chr_name_temp<<"\t"<<position<<"\t"<<genotype<<"\t"<<abbv[genotype]<<endl;
			}
		}
		dbsnp.close();
		cout<<chrName<<" (len:"<<chrLen<<") for "<<FLAG<<" individuals in "<<map_snp.size()<<" SNP sites" <<endl;
		int  finished = 0 ;
		int  prev_pos = 0 ;
		map<int,int>::const_iterator map_it=map_snp.begin();
		while(map_it!=map_snp.end())
		{   
			int pos=map_it->first ;
			if (pos>=chrLen)
			{
				cout<<"Warning!!! Your SNPs are located outside the chromosome!!! I am stopping!"<<endl ;
				break ;
			}
			int type=map_it->second;
			//        out_fs<<chrName<<"\t"<<(pos+1)<<"\t"<<abbv[type];
			out_type<<chrName<<"\t"<<(pos+1)<<"\t"  ;
			//        ref = 'N' ;
			//int new_ref =0 ;
			int bewee_Two_SNP=12*(pos-prev_pos);
			if (bewee_Two_SNP<0)
			{
				cout<<"Warning!!Bad in sort SNP posi"<<endl;
				return 1;
			}
			indi_CN=0 ; indi_dep=0 ; total_depth=0;
			for(k=0;k<FLAG;k++)
			{
				fseek(Files[k],bewee_Two_SNP,1);
				indi_dep=0;
				ref_index=Read_base(Files[k],&indi_CN,&indi_dep,LLR);
				int best_genotype = 16 ;
				int second_genotype = 16 ;

				for (int glf_type=0 ; glf_type<10 ; glf_type++)
				{
					int genotype = code[glf_type] ;
					if( (genotype^type) == 0)
					{
					}
					else if( (((genotype^type)&3)== 0) or ((((genotype^type)>>2)&3) == 0) )
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) {  LLR[glf_type] += 0 ; }
						else  {  LLR[glf_type] += 27 ;  }
					}
					else
					{
						if ( (genotype&3) == ((genotype>>2)&3) ) { LLR[glf_type] += 30 ; }
						else {   LLR[glf_type] += 54; }
					}

					if ( (best_genotype == 16) or (LLR[glf_type] < LLR[rev_code[best_genotype]])) {
						second_genotype = best_genotype ;    best_genotype = genotype ;
					}
					else if ( (second_genotype == 16 ) or (LLR[glf_type] < LLR[rev_code[second_genotype]])  )  {
						second_genotype = genotype ; }
					else
					{ 
					}        
				}
				total_depth += indi_dep ;
				int quelity_base=(LLR[rev_code[second_genotype]]-LLR[rev_code[best_genotype]]);
				if(quelity_base==0 || indi_dep==0) { out_type<<"- ";  } 
				else { out_type<<abbv[best_genotype]<<" "; }
			}
			out_type<<endl; 
			finished += 1 ;
			prev_pos=pos+1;
			if (0 == finished % 10000 )
			{
				cout<<finished<<" SNP size have done"<<endl;
			}
			map_it++;
		}
		out_type.close();
		cout<<"Finished\t"<<chrName<<"\tMission Complete!"<<endl;


	}




	delete para_8 ;
	return 0;
}



////////////////////////swimming in the sea & flying in the sky //////////////////
/////////////////////////swimming in the sea & flying in the sky /////////////////*/

///////// swimming in the sky and flying in the sea ////////////

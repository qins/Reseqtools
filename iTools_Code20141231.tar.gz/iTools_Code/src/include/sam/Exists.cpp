#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "khash.h"
using namespace std;

///////////////////
string &  replace_all(string &  str,const   string&  old_value,const string&   new_value)      
{      
    while(true)   {      
        string::size_type   pos(0);      
        if(   (pos=str.find(old_value))!=string::npos   )      
            str.replace(pos,old_value.length(),new_value);      
        else   break;      
    }      
    return   str;      
}      

string &   replace_all_distinct(string&   str,const   string&   old_value,const   string&   new_value)      
{      
    for(string::size_type   pos(0);   pos!=string::npos;   pos+=new_value.length())   {      
        if(   (pos=str.find(old_value,pos))!=string::npos   )      
            str.replace(pos,old_value.length(),new_value);      
        else   break;      
    }      
    return   str;      
}      
void split(const string& str,vector<string>& tokens,  const string& delimiters = " ")
{
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    string::size_type pos     = str.find_first_of(delimiters, lastPos);
    while (string::npos != pos || string::npos != lastPos)
    {
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        lastPos = str.find_first_not_of(delimiters, pos);
        pos = str.find_first_of(delimiters, lastPos);
    }
}
///////////////////

KHASH_MAP_INIT_STR(sm, string )


int main(int argc,char *argv[])
{

    if(argc!=3)
    {
        cout<<"\tVersion 1.0\thewm@genomics.org.cn\t2011-12-30\n";
        cout<<argv[0]<<"\tInPut1\tInPut2"<<endl;
        return 1 ;
    }
    string InputFile=argv[1] ;
    ifstream IN (argv[1],ifstream::in); // igzstream 
    if(!IN.good())
    {
        cerr << "open InputFile error: "<<InputFile<<endl;
         return 1;
    }
    khash_t(sm) *h = kh_init(sm);
    int ret ;
    khiter_t k ;
    ////////////////////////swimming in the sea & flying in the sky //////////////////   
    while(!IN.eof())
    {
        string  line ;
        getline(IN,line);
        if (line.length()<=0)  { continue  ; }
        istringstream isone (line,istringstream::in);
        string temp1  ;
        const char* ID ;
        isone>>temp1>>ID ;
        k = kh_put(sm, h, ID , &ret);
        kh_value(h, k) =  line ;
        
    }
    IN.close();

    return 0 ;
}
////////////////////////swimming in the sea & flying in the sky //////////////////



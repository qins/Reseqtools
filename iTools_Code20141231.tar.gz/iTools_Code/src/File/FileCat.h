#ifndef FileCat_H_
#define FileCat_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/zlib/zlib.h"
#include <iomanip>
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "../include/gzstream/gzstream.h"
#include "../ALL/DataClass.h"

using namespace std;

int  print_FileCat01()
{
	cout <<""
		"\n"
		"\tUsage: cat  *.raw\n"
		"\n"
		"\t\t-InFile     <str>   Input file for Cat\n"
		"\t\t-InList     <str>   Input file List for Cat\n"
		"\n"
		"\t\t-OutPut     <str>   Out file of Cat [STDOUT]\n"
		"\n"
		"\t\t-help               show this help\n" 
		"\n";
	return 1;
}


int parse_FileCat01(int argc, char **argv, In3str1v  * para_A10 )
{
	if (argc <2 ) {print_FileCat01();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFile" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			string tmp=argv[i];
			(para_A10->List).push_back(tmp);
		}
		else if (flag  == "InList" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			string tmp=argv[i];
			ReadList (tmp , para_A10->List);
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_A10->InStr1=argv[i];
		}
		else if (flag  == "help")
		{
			print_FileCat01();return 0;
		}
		else
		{
			string tmp=argv[i];
			(para_A10->List).push_back(tmp);
		}
	}

	if ( (para_A10->List).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	/*///
	  if (!(para_A10->InStr1).empty() )
	  {
	  (para_A10->InStr1)=add_Asuffix((para_A10->InStr1));
	  }
	///*///
	return 1 ;
}

int File_Cat_main(int argc,char *argv[])
{
	In3str1v  * para_A10 = new In3str1v ;    
	if( parse_FileCat01 ( argc, argv,para_A10 ) ==0 )
	{
		delete para_A10  ;
		return 0 ;
	}
	int File=(para_A10->List).size() ;
	if ((para_A10->InStr1).empty())
	{
		for (int ii=0 ; ii<File ; ii++)
		{      
			string path=(para_A10->List)[ii].c_str() ;
			string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
			if (ext=="gz")
			{                
				path="zcat "+path ;
				system(path.c_str()) ;
			}
			else
			{
				path="cat "+path ;
				system(path.c_str()) ;
			}
		}
	}
	else
	{

		for (int ii=0 ; ii<File ; ii++)
		{      
			string path=(para_A10->List)[ii].c_str() ;
			string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
			if (ext=="gz")
			{                
				path="zcat "+path+"  >>"+ (para_A10->InStr1) ;
				system(path.c_str()) ;
			}
			else
			{
				path="cat "+path+"  >>"+ (para_A10->InStr1)  ;
				system(path.c_str()) ;
			}
		}

		string gzip="gzip "+(para_A10->InStr1)  ;
		system(gzip.c_str()) ;


		/*
		   ogzstream OUT ((para_A10->InStr1).c_str());
		   if(OUT.fail())
		   {
		   cerr << "open InputFile error: "<<(para_A10->InStr1)<<endl;
		   return  0;
		   }
		   for (int ii=0 ; ii<File ; ii++)
		   {
		   igzstream  IN ((para_A10->List)[ii].c_str(),ifstream::in);
		   if(!IN.good())
		   {
		   cerr << "open InputFile error: "<<(para_A10->List)[ii]<<endl;
		   return  0;
		   }
		   while(!IN.eof())
		   {
		   string  line ;
		   getline(IN,line);
		   OUT<<line<<endl;
		   }
		   IN.close();
		   }
		   OUT.close();
		   */
	}
	return 1;
}
//programme entry
///////// swimming in the sky and flying in the sea ////////////
#endif /* FileCat_H_  */



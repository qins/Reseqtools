#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-29
echo Start Time : 
date
../bin/iTools	Gfftools	AnoVar	-Var	ALL.add_ref	-Gff	/ifs5/PC_PA_AP/USER/heweiming/soy31/ref/soybean.fa.gff3.gz	-OutPut	Gm.ano	
echo End Time : 
date

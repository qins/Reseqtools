#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-21
echo Start Time : 
date
../bin/iTools	CNStools	FilterRaw	-InAddcn	../../SoapSNP/Raw/Gm01.addcn.gz	-OutPut	../Gm01	-MinDepth	10	-MaxDepth	450	-Quality	15	-Name	soybean	-CpNumber	1.5
echo End Time : 
date

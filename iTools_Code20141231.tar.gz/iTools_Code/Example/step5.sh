#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-21
echo Start Time : 
date
../bin/iTools	CNStools	GLF2GPF	-Indbsnp	../Gm01.dbsnp	-GlfList	../../SoapSNP/list/Gm01.list	-OutPut	../Gm01	
echo End Time : 
date
